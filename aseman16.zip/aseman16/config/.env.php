<?php
if (!defined('ASEMAN_ROOT')) die('Access Denied');
putenv('ASEMAN_PG_HOST=' . '127.0.0.1');
putenv('ASEMAN_PG_PORT=' . '5432');
putenv('ASEMAN_PG_DB='   . 'aseman_library');
putenv('ASEMAN_PG_USER=' . 'adminaseman');
putenv('ASEMAN_PG_PASS=' . 'Parsa@1406');
