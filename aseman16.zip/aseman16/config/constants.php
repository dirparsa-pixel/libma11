<?php
// تنظیمات ثابت‌ها، فیلدهای ایران‌مارک، طیف‌های رنگی و سطوح دسترسی سامانه آسمان
if (!defined('ASEMAN_ROOT')) die('Access Denied');
@ini_set('memory_limit', '-1');
@set_time_limit(0);

$cms_defaults = array(
    'chart_source'        => 'by_loc',
    'chart_type'          => 'bar_v',
    'chart_palette'       => 'emerald',
    'chart_custom_color'  => '#0d7a8a',
    'chart_custom_color2' => '#c5a059',
    'chart_limit'         => '12',
    'chart_show_kpi'      => '1',
    'chart_allow_switch'  => '1',
    'slider_display_mode' => 'glass_backlight',
    'slider_effect'       => 'fade',
    'slider_height'       => '340',
    'slider_pause'        => '5000',
    'slider_opacity'      => '65',
    'slider_slides_json'  => '',
    'auto_bk_enabled'     => '0',
    'auto_bk_schedule'    => 'daily',
    'auto_bk_time'        => '02:00',
    'auto_bk_type'        => 'full',
    'auto_bk_local_dir'   => 'backups/auto',
    'auto_bk_remote_type' => 'none',
    'auto_bk_remote_url'  => '',
    'auto_bk_ftp_user'    => '',
    'auto_bk_ftp_pass'    => '',
        'smtp_host'           => '',
    'smtp_port'           => '587',
    'smtp_enc'            => 'tls',
    'smtp_user'           => '',
    'smtp_pass'           => '',
    'monitor_admin_email' => '',
    'monitor_tech_email'  => '',
    'monitor_alert_on'    => '1',
        'max_bulk_import' => '100000',
    'slider_active'   => '1',
    'slider_img1'     => '',
    'slider_title1'   => 'کتابخانه تخصصی و مرکز اسناد آسمان',
    'slider_sub1'     => 'پرتال جامع اطلاع‌رسانی، جستجوی منابع کتابشناختی (OPAC) و خدمات پژوهشی',
    'slider_link1'    => '?p=home&smode=simple',
    'slider_img2'     => '',
    'slider_title2'   => 'جستجوی پیشرفته و رزرو برخط منابع',
    'slider_sub2'     => 'امکان جستجو در کل مخازن، مشاهده موجودی لحظه‌ای و رزرو ۴۸ ساعته کتاب توسط اعضا',
    'slider_link2'    => '?p=home&smode=adv',
    'slider_img3'     => '',
    'slider_title3'   => 'پیشنهاد و سفارش خرید منابع جدید',
    'slider_sub3'     => 'منابع و کتاب‌های مورد نیاز خود را جهت تهیه به کتابخانه پیشنهاد دهید',
    'slider_link3'    => '?p=home&smode=order',
    'footer_cols'     => '3',
    'footer_col1_source' => 'about',
    'footer_col2_source' => 'menu',
    'footer_col3_source' => 'contact',
    'footer_col4_source' => 'stats',
    'footer_col4_title'  => 'آمار و خدمات',
    'stats_tabs_cfg'  => 'overview,locs,types',
    'site_title'      => 'کتابخانه تخصصی و مرکز اسناد آسمان',
    'site_sub'        => 'پرتال جامع اطلاع‌رسانی، جستجوی منابع کتابشناختی (OPAC) و خدمات پژوهشی',
    'font'            => 'Vazirmatn',
    'theme'           => 'itaihe_art',
    'portal_style'    => 'itaihe_art',
    'header_org_sub'  => 'پژوهشکده هنر و تمدن اسلامی | معاونت پژوهش و فناوری',
    'header_logo'     => '',
    'header_phone'    => '۰۵۱-۳۸۸۸۰۰۰۰',
    'header_hours'    => 'شنبه تا چهارشنبه ۸:۰۰ الی ۱۹:۳۰',
    'header_nav'      => "صفحه اصلی | ?p=home
جستجوی منابع (OPAC) | ?p=home&smode=simple
جستجوی پیشرفته | ?p=home&smode=adv
اخبار و اطلاعیه‌ها | ?p=news_list
پیشنهاد خرید کتاب | ?p=home&smode=order",
    'footer_about'    => 'کتابخانه تخصصی آسمان با هدف گردآوری، سازماندهی و اشاعه اطلاعات علمی، هنری و پژوهشی بر پایه استانداردهای نوین فهرست‌نویسی ایران‌مارک، خدمات خود را به پژوهشگران، اساتید و دانشجویان گرامی ارائه می‌نماید.',
    'footer_col2_title'=> 'دسترسی سریع پژوهشی',
    'footer_col2_links'=> "جستجوی ساده در مخزن | ?p=home&smode=simple
جستجوی پیشرفته منابع | ?p=home&smode=adv
سفارش و پیشنهاد خرید کتاب | ?p=home&smode=order
آرشیو اخبار و رویدادها | ?p=news_list",
    'footer_col3_title'=> 'اطلاعات تماس و نشانی',
    'footer_copyright'=> 'کلیه حقوق مادی و معنوی این پرتال متعلق به کتابخانه تخصصی می‌باشد.',
    'services'     => "امانت کتاب، مجلات و منابع دیجیتال\nسالن‌های مطالعه مجزا و آرام\nبخش کودک و نوجوان و نشست‌های کتاب‌خوان\nسفارش و پیشنهاد خرید منابع جدید توسط اعضا\nدسترسی به پایگاه‌های اطلاعاتی و پایان‌نامه‌ها",
    'news'         => "آغاز ثبت‌نام رایگان عضویت کتابخانه به مناسبت هفته کتاب | ۱۴۰۵/۰۸/۲۴ | به اطلاع کلیه علاقه‌مندان و پژوهشگران گرامی می‌رساند به مناسبت فرارسیدن هفته کتاب و کتابخوانی، ثبت‌نام و صدور کارت عضویت در تمامی بخش‌های کتابخانه آسمان به صورت کاملاً رایگان انجام می‌پذیرد.\nساعت کاری جدید کتابخانه: شنبه تا چهارشنبه ساعت ۸ الی ۲۰ | ۱۴۰۵/۰۸/۱۰ | اعضای محترم کتابخانه از این پس می‌توانند کتاب‌ها و منابع درخواستی خود را از طریق فرم سفارش منبع در صفحه اول پرتال ثبت نمایند تا در اولویت خرید بخش مربوطه قرار گیرد.\nتازه‌های نشر: بیش از ۲۰۰ عنوان کتاب جدید به مخزن اصلی اضافه شد | ۱۴۰۵/۰۷/۲۸ | فهرست کامل کتاب‌های جدید در حوزه هوش مصنوعی، ادبیات، تاریخ و علوم اسلامی فهرست‌نویسی شده و آماده امانت به اعضا می‌باشد.",
    'links'        => "نهاد کتابخانه‌های عمومی کشور | https://www.iranpl.ir\nسامانه مدیریت کتابخانه‌ها (سامان) | https://samanpl.ir\nسازمان اسناد و کتابخانه ملی ایران | https://opac.nlai.ir/opac-prod/search/searchBF.do",
    'about'        => '<p><b>کتابخانه آسمان</b> با هدف ارتقای فرهنگ مطالعه مفید، تسهیل دسترسی پژوهشگران و شهروندان به منابع معتبر علمی، فرهنگی و ادبی، و ارائه خدمات نوین کتابداری بر پایه استانداردهای ایران‌مارک فعالیت می‌نماید.</p>',
    'contact'      => '<p><b>آدرس:</b> مشهد مقدس، بلوار وکیل‌آباد، پلاک ۱۲۰<br><b>تلفن تماس:</b> ۰۵۱-۳۸۸۸۰۰۰۰<br><b>پست الکترونیک:</b> info@asemanlib.ir<br><b>ساعات فعالیت:</b> شنبه تا پنجشنبه ۸:۰۰ الی ۱۹:۳۰</p>',
    'locations'    => "مخزن اصلی|10\nبخش مرجع|11\nبخش کودک و نوجوان|12\nبخش نشریات و مقالات|13\nبخش پایان‌نامه‌ها|14",
    'growth_chart' => "فروردین|120\nاردیبهشت|185\nخرداد|240\nتیر|310\nمرداد|390\nشهریور|450\nمهر|530\nآبان|610\nآذر|680\nدی|740\nبهمن|820\nاسفند|950"
);

// ایجاد باکس‌های پیش‌فرض پرتال
$default_boxes = array(
    array('search', 'جستجو و سفارش منابع (OPAC)', 'system', '', 'main', 1, 1),
    array('news', 'اخبار و اطلاعیه‌های کتابخانه', 'system', '', 'main', 2, 1),
    array('chart', 'نمودار رشد منابع کتابخانه (ماه‌به‌ماه)', 'system', '', 'main', 3, 1),
    array('services_new', 'خدمات کتابخانه و تازه‌های نشر', 'system', '', 'main', 4, 1),
    array('about_contact', 'درباره ما و تماس با ما', 'system', '', 'main', 5, 1),
    array('login', 'ورود اعضا و کتابداران (ثبت‌نام عضویت)', 'system', '', 'side', 1, 1),
    array('stats', 'آمار مجموعه و اعضا', 'system', '', 'side', 2, 1),
    array('gallery', 'گالری تصاویر کتابخانه', 'system', '', 'side', 3, 1),
    array('links', 'پیوندهای مفید', 'system', '', 'side', 4, 1)
);

$F = array(
    'f010'  => 'شابک / شاپا (010 $a)',
    'f101'  => 'زبان اثر (101 $a)',
    'f200a' => 'عنوان اصلی (200 $a)',
    'f200e' => 'عنوان فرعی (200 $e)',
    'f200f' => 'نخستین پدیدآور / مسئولیت (200 $f)',
    'f205'  => 'وضعیت ویراست (205 $a)',
    'f210a' => 'محل نشر (210 $a)',
    'f210c' => 'نام ناشر / دانشگاه (210 $c)',
    'f210d' => 'سال نشر (210 $d)',
    'f215'  => 'تعداد صفحات / مشخصات ظاهری (215 $a)',
    'f225'  => 'عنوان مجموعه / فروست (225 $a)',
    'f300'  => 'یادداشت کلی / کتابنامه (300 $a)',
    'f606'  => 'موضوعات (606 $a)',
    'f676'  => 'شماره رده دیویی (676 $a)',
    'f686'  => 'شماره رده کنگره (680/686 $a)',
    'f700'  => 'پدیدآوران شخصی (700/701 $a)',
    'f710'  => 'پدیدآور سازمانی (710 $a)'
);
$RTypes = array('book'=>'کتاب', 'article'=>'مقاله', 'thesis'=>'پایان‌نامه', 'other'=>'سایر منابع');

// ۲۰ طیف رنگی (۱۰ تم پررنگ و ۱۰ تم کم‌رنگ پاستلی)
$Themes = array(
    'itaihe_art'     => array('name'=>'۰. فیروزه‌ای و طلایی هنر اسلامی (الهام‌گرفته از کتابخانه تخصصی هنر)', 'navy'=>'#0c3b47', 'navy2'=>'#135d66', 'blue'=>'#0d7a8a', 'sky'=>'#e3f4f4', 'ice'=>'#f9f8f4', 'line'=>'#c8dede'),
    'royal_dark'     => array('name'=>'۱. آبی سلطنتی پررنگ', 'navy'=>'#07193d', 'navy2'=>'#12316b', 'blue'=>'#2563eb', 'sky'=>'#dbeafe', 'ice'=>'#f0f6ff', 'line'=>'#bfdbfe'),
    'emerald_dark'   => array('name'=>'۲. سبز زمردی پررنگ', 'navy'=>'#052e20', 'navy2'=>'#0a4f37', 'blue'=>'#059669', 'sky'=>'#d1fae5', 'ice'=>'#ecfdf5', 'line'=>'#a7f3d0'),
    'crimson_dark'   => array('name'=>'۳. زرشکی و یاقوتی پررنگ', 'navy'=>'#3d0814', 'navy2'=>'#691224', 'blue'=>'#dc2626', 'sky'=>'#fee2e2', 'ice'=>'#fef2f2', 'line'=>'#fecaca'),
    'purple_dark'    => array('name'=>'۴. بنفش آمیتیست پررنگ', 'navy'=>'#230b42', 'navy2'=>'#3f1673', 'blue'=>'#7c3aed', 'sky'=>'#ede9fe', 'ice'=>'#f5f3ff', 'line'=>'#ddd6fe'),
    'teal_dark'      => array('name'=>'۵. فیروزه‌ای اقیانوسی پررنگ', 'navy'=>'#082f38', 'navy2'=>'#0f5261', 'blue'=>'#0891b2', 'sky'=>'#cffafe', 'ice'=>'#ecfeff', 'line'=>'#a5f3fc'),
    'amber_dark'     => array('name'=>'۶. کهربایی و طلایی پررنگ', 'navy'=>'#3b1d06', 'navy2'=>'#66340c', 'blue'=>'#d97706', 'sky'=>'#fef3c7', 'ice'=>'#fffbeb', 'line'=>'#fde68a'),
    'indigo_dark'    => array('name'=>'۷. سرمه‌ای نیلی پررنگ', 'navy'=>'#14153d', 'navy2'=>'#25276b', 'blue'=>'#4f46e5', 'sky'=>'#e0e7ff', 'ice'=>'#eef2ff', 'line'=>'#c7d2fe'),
    'rose_dark'      => array('name'=>'۸. ارغوانی رز پررنگ', 'navy'=>'#3b0720', 'navy2'=>'#69103a', 'blue'=>'#e11d48', 'sky'=>'#ffe4e6', 'ice'=>'#fff1f2', 'line'=>'#fecdd3'),
    'forest_dark'    => array('name'=>'۹. سبز جنگلی پررنگ', 'navy'=>'#112a15', 'navy2'=>'#1e4a25', 'blue'=>'#16a34a', 'sky'=>'#dcfce7', 'ice'=>'#f0fdf4', 'line'=>'#bbf7d0'),
    'slate_dark'     => array('name'=>'۱۰. ذغالی و نقره‌ای مدرن پررنگ', 'navy'=>'#0f172a', 'navy2'=>'#1e293b', 'blue'=>'#475569', 'sky'=>'#e2e8f0', 'ice'=>'#f8fafc', 'line'=>'#cbd5e1'),
    'sky_light'      => array('name'=>'۱۱. آبی آسمانی کم‌رنگ (ملایم)', 'navy'=>'#1e3a5f', 'navy2'=>'#2b547e', 'blue'=>'#38bdf8', 'sky'=>'#e0f2fe', 'ice'=>'#f8fcff', 'line'=>'#bae6fd'),
    'mint_light'     => array('name'=>'۱۲. سبز نعنایی کم‌رنگ (ملایم)', 'navy'=>'#1b4332', 'navy2'=>'#2d6a4f', 'blue'=>'#34d399', 'sky'=>'#d8f3dc', 'ice'=>'#f7fff9', 'line'=>'#b7e4c7'),
    'lavender_light' => array('name'=>'۱۳. یاسی و اسطوخودوس کم‌رنگ', 'navy'=>'#3c1e5f', 'navy2'=>'#583187', 'blue'=>'#a78bfa', 'sky'=>'#f3e8ff', 'ice'=>'#fcfaff', 'line'=>'#e9d5ff'),
    'peach_light'    => array('name'=>'۱۴. هلویی و مرجانی کم‌رنگ', 'navy'=>'#5c2415', 'navy2'=>'#7c3622', 'blue'=>'#fb923c', 'sky'=>'#ffedd5', 'ice'=>'#fffaf5', 'line'=>'#fed7aa'),
    'pink_light'     => array('name'=>'۱۵. صورتی شکوفه‌ای کم‌رنگ', 'navy'=>'#591936', 'navy2'=>'#7a254b', 'blue'=>'#f472b6', 'sky'=>'#fce7f3', 'ice'=>'#fff8fc', 'line'=>'#fbcfe8'),
    'aqua_light'     => array('name'=>'۱۶. فیروزه‌ای یخی کم‌رنگ', 'navy'=>'#134e4a', 'navy2'=>'#115e59', 'blue'=>'#2dd4bf', 'sky'=>'#ccfbf1', 'ice'=>'#f5fffe', 'line'=>'#99f6e4'),
    'lemon_light'    => array('name'=>'۱۷. لیمویی و کرم روشن', 'navy'=>'#42360c', 'navy2'=>'#635114', 'blue'=>'#eab308', 'sky'=>'#fef9c3', 'ice'=>'#fffff7', 'line'=>'#fef08a'),
    'lilac_light'    => array('name'=>'۱۸. بنفش یاقوتی روشن', 'navy'=>'#4a154b', 'navy2'=>'#682169', 'blue'=>'#e879f9', 'sky'=>'#fae8ff', 'ice'=>'#fffaff', 'line'=>'#f5d0fe'),
    'pistachio_light'=> array('name'=>'۱۹. سبز پسته‌ای کم‌رنگ', 'navy'=>'#2a3d12', 'navy2'=>'#3f5c1c', 'blue'=>'#84cc16', 'sky'=>'#ecfccb', 'ice'=>'#fafff5', 'line'=>'#d9f99d'),
    'pearl_light'    => array('name'=>'۲۰. مرواریدی و آبی نقره‌ای کم‌رنگ', 'navy'=>'#273444', 'navy2'=>'#3c4d63', 'blue'=>'#60a5fa', 'sky'=>'#eff6ff', 'ice'=>'#fafcff', 'line'=>'#dbeafe')
);

$AllPerms = array(
    'dash'       => 'پیشخوان مدیریت',
    'rec'        => 'جستجوی منابع و ثبت امانت',
    'form'       => 'ثبت و ویرایش منابع',
    'org'        => 'سرویس سازماندهی و چاپ برچسب',
    'imp_exp'    => 'سرویس تبادل فراداده',
    'mem'        => 'مدیریت اعضای کتابخانه',
    'loan'       => 'فهرست منابع در امانت',
    'orders'     => 'فهرست سفارش منابع',
    'authority'  => 'سرویس مستندات استاندارد',
    'tickets'    => 'سرویس تیکت و پشتیبانی',
    'stats'      => 'پیشخوان آمار',
    'bulk'       => 'سرویس کنترل گروهی',
    'rep'        => 'سرویس گزارش ساز',
    'backup'     => 'سرویس پشتیبان و بازیابی',
    'users'      => 'مدیریت کاربران',
    'locs'       => 'مدیریت کتابخانه‌ها',
    'cms'        => 'مدیریت پرتال',
    'settings'   => 'مدیریت مجوز بهره‌برداری',
    'monitoring' => 'سیستم مانیتورینگ سامانه'
);

function h($s) {
    return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
}
