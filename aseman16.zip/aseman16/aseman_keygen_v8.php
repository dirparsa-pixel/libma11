<?php
/**
 * اسکریپت مستقل تولید کد فعال‌سازی لایسنس نرم‌افزار کتابخانه‌ای آسمان (ویژه سیستم فروشنده)
 * بدون نیاز به دیتابیس — تولیدکننده کلیدهای استاندارد ASM2-...
 */
session_start();
date_default_timezone_set('Asia/Tehran');

define('ASEMAN_VENDOR_SECRET', 'AsemanLib#2026$VendorSecretKey!987654321');
define('VENDOR_PIN', 'Parsa@1406');

function h($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
function en_num($s) {
    return str_replace(
        array('۰','۱','۲','۳','۴','۵','۶','۷','۸','۹','٠','١','٢','٣','٤','٥','٦','٧','٨','٩'),
        array('0','1','2','3','4','5','6','7','8','9','0','1','2','3','4','5','6','7','8','9'),
        (string)$s
    );
}

$AllModules = array(
    'mod_dash'      => '📊 پیشخوان مدیریت (الزامی)',
    'mod_rec'       => '📖 منابع و میز امانت سریع',
    'mod_form'      => '➕ ثبت و ویرایش منبع (ایران‌مارک)',
    'mod_org'       => '🏷️ سازماندهی و چاپ برچسب عطف',
    'mod_locs'      => '📍 مدیریت کتابخانه ها و پیش‌شماره‌ها',
    'mod_orders'    => '🛒 فهرست سفارش و پیشنهاد خرید کتاب',
    'mod_tickets'   => '🎫 سیستم تیکت و پشتیبانی داخلی',
    'mod_imp_exp'   => '🔄 تبادل فراداده (ایزو ۲۷۰۹ و اکسل)',
    'mod_stats'     => '📈 آمار پیشرفته سامانه و کاربران آنلاین',
    'mod_authority' => '📚 بانک مستندات فهرست‌نویسی',
    'mod_bulk'      => '🛠️ کنترل گروهی و سلامت پایگاه',
    'mod_backup'    => '💾 پشتیبان‌گیری و بازیابی اطلاعات',
    'mod_mem'       => '👥 مدیریت اعضا و چاپ کارت عضویت',
    'mod_loan'      => '📅 فهرست امانت‌های جاری و تمدید',
    'mod_rep'       => '📈 گزارش‌های جامع کتابخانه',
    'mod_cms'       => '🌐 مدیریت پرتال، باکس‌ها، اخبار و گالری',
    'mod_users'     => '🔐 مدیریت کتابداران و سطوح دسترسی',
    'mod_chat'      => '💬 چت‌بات هوشمند گفتگو با منابع در پرتال'
);

function generate_asm2_key($payload) {
    ksort($payload);
    $json = json_encode($payload, JSON_UNESCAPED_UNICODE);
    $b64 = rtrim(strtr(base64_encode($json), '+/', '-_'), '=');
    $sig = strtoupper(substr(hash_hmac('sha256', $b64, ASEMAN_VENDOR_SECRET), 0, 16));
    return 'ASM2-' . $b64 . '.' . $sig;
}

$generated_key = '';
$err = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (($_POST['pin'] ?? '') !== VENDOR_PIN) {
        $err = '❌ رمز امنیتی فروشنده نادرست است.';
    } else {
        $bind_mode = ($_POST['bind_mode'] ?? 'any') === 'strict' ? 'strict' : 'domain';
        $domains = trim(en_num($_POST['allowed_domains'] ?? '*'));
        if ($domains === '' || ($_POST['bind_mode'] ?? 'any') === 'any') $domains = '*';
        $inst_code = trim(en_num($_POST['install_code'] ?? ''));
        if ($bind_mode !== 'strict') $inst_code = '';

        $p = array(
            'mode'             => 'commercial',
            'plan_title'       => trim($_POST['plan_title'] ?: 'مجوز تجاری سازمانی'),
            'client_name'      => trim($_POST['client_name'] ?: 'کتابخانه مرکزی'),
            'contract_no'      => trim(en_num($_POST['contract_no'] ?: '1405-110')),
            'bind_mode'        => $bind_mode,
            'install_code'     => $inst_code,
            'allowed_domains'  => strtolower($domains),
            'exp_date'         => trim(en_num($_POST['exp_date'] ?? '')),
            'support_exp_date' => trim(en_num($_POST['support_exp_date'] ?? '')),
            'max_locs'         => max(0, (int)en_num($_POST['max_locs'] ?? 0)),
            'max_records'      => max(0, (int)en_num($_POST['max_records'] ?? 0)),
            'max_items'        => max(0, (int)en_num($_POST['max_items'] ?? 0)),
            'max_members'      => max(0, (int)en_num($_POST['max_members'] ?? 0)),
            'lock_theme'       => isset($_POST['lock_theme']) ? 1 : 0,
            'lock_raw_db'      => 1,
            'idle_limit'       => 600,
            'max_login_try'    => 5,
            'max_upload_mb'    => 20,
            'vendor_name'      => trim($_POST['vendor_name'] ?: 'نرم‌افزار جامع کتابخانه‌ای آسمان'),
            'vendor_url'       => trim($_POST['vendor_url'] ?: 'https://asemanlib.ir'),
            'show_footer'      => isset($_POST['show_footer']) ? 1 : 0
        );
        foreach (array_keys($AllModules) as $mk) {
            $p[$mk] = ($mk === 'mod_dash' || isset($_POST[$mk])) ? 1 : 0;
        }
        $generated_key = generate_asm2_key($p);
    }
}
?>
<!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<title>رمزساز مستقل لایسنس آسمان (ASM2 Keygen - ویژه سیستم فروشنده)</title>
<link href="https://cdn.jsdelivr.net/gh/rastikerdar/vazirmatn@v33.003/Vazirmatn-font-face.css" rel="stylesheet" />
<style>
*{box-sizing:border-box}body{font-family:Vazirmatn,Tahoma,sans-serif;background:#0f172a;color:#0f172a;margin:0;padding:24px}
.wrap{max-width:960px;margin:0 auto;background:#fff;border-radius:20px;padding:26px;box-shadow:0 20px 50px rgba(0,0,0,.4)}
h1{margin:0 0 8px;color:#1e3a8a;font-size:20px}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:12px;margin-bottom:16px}
label{display:block;font-size:12.5px;font-weight:700;margin-bottom:4px;color:#1e3a8a}
input,select,textarea{width:100%;padding:9px 12px;border:1px solid #cbd5e1;border-radius:10px;font:inherit;font-size:13.5px}
input[type=checkbox]{width:auto;margin-left:6px;transform:scale(1.15)}
.mod{display:flex;align-items:center;background:#f8fafc;border:1px solid #e2e8f0;padding:8px 10px;border-radius:10px;font-size:12.5px;font-weight:600;cursor:pointer}
.btn{background:linear-gradient(135deg,#2563eb,#1d4ed8);color:#fff;border:none;padding:12px 28px;border-radius:99px;font:inherit;font-weight:800;cursor:pointer;font-size:14px}
.out-box{background:#ecfdf5;border:2px solid #10b981;border-radius:16px;padding:18px;margin-bottom:20px}
</style>
</head>
<body>
<div class="wrap">
    <h1>🔑 سیستم مستقل تولید کد فعال‌سازی لایسنس «آسمان» (تولید کد ASM2-... ویژه سیستم فروشنده)</h1>
    <p style="font-size:13px;color:#475569;margin-top:0">این فایل هیچ نیازی به دیتابیس ندارد و فقط روی سیستم شخصی شما اجرا می‌شود. کد `ASM2-...` تولیدشده را به مشتری بدهید تا در منوی <b>«تنظیمات مجوز و ارتقا»</b> وارد کند.</p>

    <?php if ($err): ?><div style="background:#ffe4e6;color:#e11d48;padding:12px;border-radius:10px;margin-bottom:14px;font-weight:bold"><?= h($err) ?></div><?php endif; ?>

    <?php if ($generated_key): ?>
    <div class="out-box">
        <div style="font-weight:800;color:#065f46;margin-bottom:8px">✅ کد فعال‌سازی ASM2 با موفقیت ساخته شد (روی کادر زیر کلیک کنید تا کپی شود):</div>
        <textarea rows="4" dir="ltr" readonly style="font-family:monospace;font-size:13px;background:#fff;border-color:#10b981" onclick="this.select();navigator.clipboard.writeText(this.value);alert('کد لایسنس کپی شد!');"><?= h($generated_key) ?></textarea>
    </div>
    <?php endif; ?>

    <form method="post">
        <div class="grid">
            <div><label>نام مشتری / کتابخانه *</label><input name="client_name" value="<?= h($_POST['client_name'] ?? 'کتابخانه مرکزی') ?>" required></div>
            <div><label>عنوان طرح مجوز</label><input name="plan_title" value="<?= h($_POST['plan_title'] ?? 'مجوز تجاری سازمانی') ?>"></div>
            <div><label>شماره قرارداد</label><input name="contract_no" dir="ltr" value="<?= h($_POST['contract_no'] ?? '1405-110') ?>"></div>
            <div><label style="color:#047857">نوع قفل دامنه / سرور</label><select name="bind_mode">
                <option value="any">🔓 بدون قفل دامنه (فعال روی هر دامنه و هاست مشتری - بدون خطای دامنه)</option>
                <option value="domain">🌐 قفل فقط روی نام دامنه مشتری</option>
                <option value="strict">🔒 قفل سخت‌افزاری روی کد نصب سرور (ASM-...)</option>
            </select></div>
            <div><label>دامنه مجاز مشتری (`*` = همه دامنه‌ها)</label><input name="allowed_domains" dir="ltr" value="<?= h($_POST['allowed_domains'] ?? '*') ?>" placeholder="example.ir,localhost یا *"></div>
            <div><label>کد نصب مشتری (فقط برای قفل سخت‌افزاری)</label><input name="install_code" dir="ltr" value="<?= h($_POST['install_code'] ?? '') ?>" placeholder="خالی = بدون حساسیت به کد نصب"></div>
            <div><label>تاریخ انقضای لایسنس (خالی = دائمی)</label><input name="exp_date" dir="ltr" value="<?= h($_POST['exp_date'] ?? '') ?>" placeholder="2028-03-20"></div>
            <div><label>تاریخ انقضای پشتیبانی</label><input name="support_exp_date" dir="ltr" value="<?= h($_POST['support_exp_date'] ?? '2027-12-30') ?>" placeholder="2027-12-30"></div>
            <div><label>سقف تعداد کتابخانه (0 = نامحدود)</label><input type="number" name="max_locs" value="<?= (int)($_POST['max_locs'] ?? 0) ?>"></div>
            <div><label>سقف رکورد کتابشناختی (0 = نامحدود)</label><input type="number" name="max_records" value="<?= (int)($_POST['max_records'] ?? 0) ?>"></div>
            <div><label>سقف کل مجلدات (0 = نامحدود)</label><input type="number" name="max_items" value="<?= (int)($_POST['max_items'] ?? 0) ?>"></div>
            <div><label>سقف اعضا (0 = نامحدود)</label><input type="number" name="max_members" value="<?= (int)($_POST['max_members'] ?? 0) ?>"></div>
            <div><label>نام تجاری شما در فوتر</label><input name="vendor_name" value="نرم‌افزار جامع کتابخانه‌ای آسمان"></div>
            <div><label>لینک سایت شما در فوتر</label><input name="vendor_url" dir="ltr" value="https://asemanlib.ir"></div>
            <div><label style="color:#e11d48">رمز فروشنده جهت صدور کد *</label><input type="password" name="pin" dir="ltr" value="Parsa@1406" required></div>
        </div>

        <div style="display:flex;justify-content:space-between;align-items:center;margin:14px 0 8px">
            <label style="margin:0">ماژول‌های مجاز در این لایسنس:</label>
            <div>
                <button type="button" onclick="document.querySelectorAll('.mc').forEach(c=>c.checked=true)" style="font-size:12px;cursor:pointer">انتخاب همه</button>
                <button type="button" onclick="document.querySelectorAll('.mc:not([disabled])').forEach(c=>c.checked=false)" style="font-size:12px;cursor:pointer">لغو همه</button>
            </div>
        </div>
        <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:8px;margin-bottom:16px">
            <?php foreach ($AllModules as $mk => $ml): ?>
                <label class="mod"><input type="checkbox" class="mc" name="<?= $mk ?>" value="1" checked <?= $mk==='mod_dash'?'disabled':'' ?>> <?= h($ml) ?></label>
            <?php endforeach; ?>
            <label class="mod"><input type="checkbox" name="show_footer" value="1" checked> ©️ نمایش نام شما در فوتر</label>
            <label class="mod"><input type="checkbox" name="lock_theme" value="1"> 🔒 قفل تغییر رنگ توسط مشتری</label>
        </div>

        <button class="btn">⚡ تولید کد فعال‌سازی (ASM2-...) برای مشتری</button>
    </form>
</div>
</body>
</html>
