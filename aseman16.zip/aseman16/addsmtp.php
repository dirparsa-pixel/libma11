<?php
/**
 * افزودن ماژول ارسال مستقیم SMTP (جیمیل / ایمیل سازمانی) به سیستم مانیتورینگ نسخه ۱۶
 */
define('ASEMAN_ROOT', __DIR__);
error_reporting(E_ALL);
ini_set('display_errors', 1);
header('Content-Type: text/html; charset=utf-8');

// ۱. افزودن کلیدهای پیش‌فرض SMTP به config/constants.php
$constFile = ASEMAN_ROOT . '/config/constants.php';
if (file_exists($constFile)) {
    $cCode = file_get_contents($constFile);
    if (strpos($cCode, "'smtp_host'") === false) {
        $smtpDefaults = "    'smtp_host'           => '',\n"
                      . "    'smtp_port'           => '587',\n"
                      . "    'smtp_enc'            => 'tls',\n"
                      . "    'smtp_user'           => '',\n"
                      . "    'smtp_pass'           => '',\n";
        $cCode = str_replace("'monitor_admin_email' => '',", $smtpDefaults . "    'monitor_admin_email' => '',", $cCode);
        file_put_contents($constFile, $cCode);
    }
}

// ۲. افزودن موتور ارتباط مستقیم سوکت SMTP به includes/helpers.php
$hlpFile = ASEMAN_ROOT . '/includes/helpers.php';
if (file_exists($hlpFile)) {
    $hCode = file_get_contents($hlpFile);

    $smtpEngineCode = <<<'NOWDOC'
// ==================== ASEMAN V16: سیستم مانیتورینگ لحظه‌ای (با موتور SMTP توکار) و پشتیبان‌گیری خودکار ====================
if (!function_exists('aseman_v16_send_smtp_email')) {
    function aseman_v16_smtp_read($fp) {
        $data = '';
        while ($str = @fgets($fp, 515)) {
            $data .= $str;
            if (substr($str, 3, 1) === ' ') break;
        }
        return $data;
    }

    function aseman_v16_smtp_cmd($fp, $cmd) {
        @fputs($fp, $cmd . "\r\n");
        return aseman_v16_smtp_read($fp);
    }

    function aseman_v16_send_smtp_email($recipients, $subject_raw, $body_text) {
        $host = function_exists('get_cms') ? trim(get_cms('smtp_host')) : '';
        $port = function_exists('get_cms') ? (int)(get_cms('smtp_port') ?: 587) : 587;
        $enc  = function_exists('get_cms') ? trim(get_cms('smtp_enc') ?: 'tls') : 'tls';
        $user = function_exists('get_cms') ? trim(get_cms('smtp_user')) : '';
        $pass = function_exists('get_cms') ? trim(get_cms('smtp_pass')) : '';

        $encoded_subj = '=?UTF-8?B?' . base64_encode($subject_raw) . '?=';

        // اگر سرور SMTP تنظیم نشده باشد، از تابع پیش‌فرض mail() استفاده کن
        if ($host === '' || $user === '' || $pass === '') {
            $from = $user !== '' ? $user : ('monitor@' . (isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : 'localhost'));
            $hdr  = "From: {$from}\r\nContent-Type: text/plain; charset=UTF-8\r\n";
            return @mail(implode(', ', $recipients), $encoded_subj, $body_text, $hdr);
        }

        $remote = ($enc === 'ssl' ? 'ssl://' : 'tcp://') . $host . ':' . $port;
        $ctx = stream_context_create(array(
            'ssl' => array(
                'verify_peer'       => false,
                'verify_peer_name'  => false,
                'allow_self_signed' => true
            )
        ));

        $fp = @stream_socket_client($remote, $errno, $errstr, 10, STREAM_CLIENT_CONNECT, $ctx);
        if (!$fp) return false;
        stream_set_timeout($fp, 10);

        aseman_v16_smtp_read($fp);
        aseman_v16_smtp_cmd($fp, 'EHLO ' . (isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : 'localhost'));

        if ($enc === 'tls') {
            aseman_v16_smtp_cmd($fp, 'STARTTLS');
            if (!@stream_socket_enable_crypto($fp, true, STREAM_CRYPTO_METHOD_TLS_CLIENT)) {
                @fclose($fp);
                return false;
            }
            aseman_v16_smtp_cmd($fp, 'EHLO ' . (isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : 'localhost'));
        }

        aseman_v16_smtp_cmd($fp, 'AUTH LOGIN');
        aseman_v16_smtp_cmd($fp, base64_encode($user));
        $auth_res = aseman_v16_smtp_cmd($fp, base64_encode($pass));
        if (strpos($auth_res, '235') === false) {
            @fclose($fp);
            return false;
        }

        aseman_v16_smtp_cmd($fp, "MAIL FROM:<{$user}>");
        foreach ($recipients as $rcpt) {
            aseman_v16_smtp_cmd($fp, "RCPT TO:<{$rcpt}>");
        }
        aseman_v16_smtp_cmd($fp, 'DATA');

        $headers  = "Date: " . date('r') . "\r\n";
        $headers .= "From: Aseman Monitoring <{$user}>\r\n";
        $headers .= "To: " . implode(', ', $recipients) . "\r\n";
        $headers .= "Subject: {$encoded_subj}\r\n";
        $headers .= "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";
        $headers .= "Content-Transfer-Encoding: 8bit\r\n\r\n";

        $send_res = aseman_v16_smtp_cmd($fp, $headers . $body_text . "\r\n.");
        aseman_v16_smtp_cmd($fp, 'QUIT');
        @fclose($fp);

        return (strpos($send_res, '250') !== false);
    }
}

if (!function_exists('aseman_v16_report_sudden_error')) {
    function aseman_v16_report_sudden_error($type, $msg, $file, $line) {
        global $db;
        $req_url = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : 'CLI';
        $u_ip    = isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '127.0.0.1';
        $emailed = 0;

        $adm_mail  = function_exists('get_cms') ? trim(get_cms('monitor_admin_email')) : '';
        $tech_mail = function_exists('get_cms') ? trim(get_cms('monitor_tech_email')) : '';
        $alert_on  = function_exists('get_cms') ? (get_cms('monitor_alert_on') !== '0') : true;

        $targets = array();
        if ($adm_mail !== '' && filter_var($adm_mail, FILTER_VALIDATE_EMAIL)) $targets[] = $adm_mail;
        if ($tech_mail !== '' && filter_var($tech_mail, FILTER_VALIDATE_EMAIL)) $targets[] = $tech_mail;
        $targets = array_unique($targets);

        if ($alert_on && !empty($targets)) {
            $subject = 'هشدار خطای ناگهانی در سامانه کتابخانه آسمان (نسخه ۱۶)';
            $body    = "گزارش فوری سیستم مانیتورینگ سامانه آسمان:\n\n"
                     . "نوع رخداد: {$type}\n"
                     . "شرح خطا: {$msg}\n"
                     . "فایل: {$file}\n"
                     . "سطر: {$line}\n"
                     . "آدرس درخواست: {$req_url}\n"
                     . "آی‌پی کاربر: {$u_ip}\n"
                     . "زمان وقوع: " . date('Y-m-d H:i:s') . "\n";
            if (aseman_v16_send_smtp_email($targets, $subject, $body)) {
                $emailed = 1;
            }
        }

        if (isset($db) && $db instanceof PDO) {
            try {
                $st = $db->prepare("INSERT INTO monitoring_logs(err_type,err_msg,err_file,err_line,req_url,user_ip,emailed) VALUES(?,?,?,?,?,?,?)");
                $st->execute(array($type, $msg, $file, (int)$line, $req_url, $u_ip, $emailed));
            } catch (Exception $e) {}
        }
        return $emailed;
    }
NOWDOC;

    $posH = strpos($hCode, '// ==================== ASEMAN V16: سیستم مانیتورینگ لحظه‌ای');
    $posBk = strpos($hCode, 'function aseman_v16_run_auto_backup');
    if ($posH !== false && $posBk !== false) {
        $hCode = substr($hCode, 0, $posH) . $smtpEngineCode . "\n\n    " . substr($hCode, $posBk);
        file_put_contents($hlpFile, $hCode);
    }
}

// ۳. افزودن فیلدهای تنظیم سرور فرستنده (SMTP) به صفحه مانیتورینگ در modules/settings.php
$setFile = ASEMAN_ROOT . '/modules/settings.php';
if (file_exists($setFile)) {
    $sCode = file_get_contents($setFile);
    $oldFormTarget = '<input type="hidden" name="t" value="\' . $tok . \'">';
    $smtpFormFields = <<<'NOWDOC'
            <div class="grid" style="margin-bottom:14px;padding:14px;background:var(--ice);border:1px solid var(--line);border-radius:12px">
                <div>
                    <label style="color:var(--navy2)">آدرس سرور فرستنده (SMTP Host)</label>
                    <input name="smtp_host" dir="ltr" class="no-num" value="' . h(get_cms('smtp_host')) . '" placeholder="smtp.gmail.com یا mail.domain.ir">
                </div>
                <div>
                    <label style="color:var(--navy2)">پورت SMTP</label>
                    <input type="number" name="smtp_port" dir="ltr" class="no-num" value="' . h(get_cms('smtp_port') ?: '587') . '" placeholder="587 یا 465">
                </div>
                <div>
                    <label style="color:var(--navy2)">نوع رمزنگاری</label>
                    <select name="smtp_enc">
                        <option value="tls"' . (get_cms('smtp_enc') !== 'ssl' && get_cms('smtp_enc') !== 'none' ? ' selected' : '') . '>STARTTLS (پورت ۵۸۷ - پیشنهادی)</option>
                        <option value="ssl"' . (get_cms('smtp_enc') === 'ssl' ? ' selected' : '') . '>SSL/TLS مستقیم (پورت ۴۶۵)</option>
                        <option value="none"' . (get_cms('smtp_enc') === 'none' ? ' selected' : '') . '>بدون رمزنگاری (پورت ۲۵)</option>
                    </select>
                </div>
                <div>
                    <label style="color:var(--navy2)">ایمیل فرستنده (نام کاربری SMTP)</label>
                    <input name="smtp_user" dir="ltr" class="no-num" value="' . h(get_cms('smtp_user')) . '" placeholder="yourname@gmail.com">
                </div>
                <div>
                    <label style="color:var(--navy2)">رمز عبور ایمیل فرستنده (یا App Password جیمیل)</label>
                    <input type="password" name="smtp_pass" dir="ltr" class="no-num" value="' . h(get_cms('smtp_pass')) . '" placeholder="رمز عبور یا App Password شانزده رقمی">
                </div>
            </div>
NOWDOC;

    $monPos = strpos($sCode, "action=\"?p=save_monitoring_cfg\"");
    if ($monPos !== false && strpos($sCode, 'name="smtp_host"') === false) {
        $tokPos = strpos($sCode, '<div class="grid">', $monPos);
        if ($tokPos !== false) {
            $sCode = substr($sCode, 0, $tokPos) . $smtpFormFields . "\n            " . substr($sCode, $tokPos);
            file_put_contents($setFile, $sCode);
        }
    }
}

// ۴. ذخیره فیلدهای SMTP در actions/post_handlers.php
$phFile = ASEMAN_ROOT . '/actions/post_handlers.php';
if (file_exists($phFile)) {
    $phCode = file_get_contents($phFile);
    $targetSave = "set_cms('monitor_admin_email', trim(\$_POST['monitor_admin_email'] ?? ''));";
    $smtpSave   = "foreach (array('smtp_host','smtp_port','smtp_enc','smtp_user','smtp_pass') as \$sk) {\n"
                . "                if (isset(\$_POST[\$sk])) set_cms(\$sk, trim(\$_POST[\$sk]));\n"
                . "            }\n            " . $targetSave;
    if (strpos($phCode, "'smtp_host'") === false) {
        $phCode = str_replace($targetSave, $smtpSave, $phCode);
        file_put_contents($phFile, $phCode);
    }
}

echo '<div dir="rtl" style="font-family:Tahoma;padding:24px;background:#ecfdf5;color:#065f46;border:2px solid #10b981;border-radius:14px;max-width:680px;margin:40px auto;line-height:2">
    <h3 style="margin-top:0">✓ تنظیمات سرور فرستنده (SMTP) به منوی مانیتورینگ اضافه شد!</h3>
    <p>اکنون در منوی <b>سیستم مانیتورینگ سامانه</b> می‌توانید مشخصات SMTP جیمیل یا ایمیل سازمانی خود را وارد کرده و با دکمه «ارسال ایمیل آزمایشی» آن را تست کنید.</p>
    <a href="index.php?p=monitoring" style="background:#0d7a8a;color:#fff;padding:10px 20px;border-radius:8px;text-decoration:none;font-weight:bold;display:inline-block">ورود به تنظیمات مانیتورینگ و SMTP</a>
</div>';