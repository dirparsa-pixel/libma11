<?php
// رندر باکس‌های صفحه اول پرتال (جستجوی OPAC، اخبار، نمودار، آمار، گالری و ورود)
if (!defined('ASEMAN_ROOT')) die('Access Denied');

function render_portal_box($bx) {
    global $db, $RTypes, $Locations, $tok, $in, $err;
    $bkey = $bx['bkey'];
    $btitle = $bx['title'];

    if ($bx['btype'] === 'custom') {
        echo '<div class="card"><h2>' . h($btitle) . '</h2><div style="font-size:13.5px;line-height:1.8">' . $bx['content'] . '</div></div>';
        return;
    }

    if ($bkey === 'search') {
        $smode = isset($_GET['smode']) ? $_GET['smode'] : 'simple';
        $sq = trim(isset($_GET['sq']) ? $_GET['sq'] : '');
        $stitle = trim(isset($_GET['stitle']) ? $_GET['stitle'] : '');
        $sauthor = trim(isset($_GET['sauthor']) ? $_GET['sauthor'] : '');
        $spub = trim(isset($_GET['spub']) ? $_GET['spub'] : '');
        $ssubj = trim(isset($_GET['ssubj']) ? $_GET['ssubj'] : '');
        $sisbn = trim(isset($_GET['sisbn']) ? $_GET['sisbn'] : '');
        $sloc = trim(isset($_GET['sloc']) ? $_GET['sloc'] : '');
        $srtype = trim(isset($_GET['srtype']) ? $_GET['srtype'] : '');

        echo '<div class="card" style="border:2px solid var(--blue)">
            <div class="tabs" style="margin-bottom:14px">
                <a class="' . ($smode === 'simple' ? 'on' : '') . '" href="?p=home&smode=simple">جستجوی ساده منابع</a>
                <a class="' . ($smode === 'adv' ? 'on' : '') . '" href="?p=home&smode=adv">جستجوی پیشرفته</a>
                <a class="' . ($smode === 'order' ? 'on' : '') . '" href="?p=home&smode=order">سفارش و پیشنهاد خرید منبع</a>
            </div>';
        if ($smode === 'simple') {
            echo '<form method="get" class="row"><input type="hidden" name="p" value="home"><input type="hidden" name="smode" value="simple">
                  <div style="flex:1"><label>کلیدواژه (عنوان، نویسنده، موضوع، ناشر، شابک یا شماره ثبت)</label><input name="sq" value="' . h($sq) . '" placeholder="عبارت مورد نظر را وارد نمایید..."></div>
                  <div style="width:150px"><label>کتابخانه</label><select name="sloc"><option value="">همه کتابخانه‌ها</option>';
                  foreach ($Locations as $lc) echo '<option value="' . h($lc) . '"' . ($sloc === $lc ? ' selected' : '') . '>' . h($lc) . '</option>';
            echo '</select></div>
                  <div style="width:140px"><label>نوع منبع</label><select name="srtype"><option value="">همه منابع</option>';
                  foreach ($RTypes as $k => $v) echo '<option value="' . $k . '"' . ($srtype === $k ? ' selected' : '') . '>' . $v . '</option>';
            echo '</select></div><button class="btn pri" style="padding:9px 22px">جستجو</button></form>';
        } elseif ($smode === 'adv') {
            echo '<form method="get"><input type="hidden" name="p" value="home"><input type="hidden" name="smode" value="adv"><div class="grid">
                  <div><label>عنوان منبع</label><input name="stitle" value="' . h($stitle) . '"></div>
                  <div><label>پدیدآور / نویسنده</label><input name="sauthor" value="' . h($sauthor) . '"></div>
                  <div><label>موضوع</label><input name="ssubj" value="' . h($ssubj) . '"></div>
                  <div><label>ناشر</label><input name="spub" value="' . h($spub) . '"></div>
                  <div><label>شابک / شاپا</label><input name="sisbn" value="' . h($sisbn) . '"></div>
                  <div><label>کتابخانه</label><select name="sloc"><option value="">همه کتابخانه‌ها</option>';
                  foreach ($Locations as $lc) echo '<option value="' . h($lc) . '"' . ($sloc === $lc ? ' selected' : '') . '>' . h($lc) . '</option>';
            echo '</select></div><div><label>نوع منبع</label><select name="srtype"><option value="">همه</option>';
                  foreach ($RTypes as $k => $v) echo '<option value="' . $k . '"' . ($srtype === $k ? ' selected' : '') . '>' . $v . '</option>';
            echo '</select></div></div><br><button class="btn pri">اجرای جستجوی پیشرفته</button> <a class="btn" href="?p=home&smode=adv">پاکسازی</a></form>';
        } else {
            echo '<form method="post" action="?p=add_order"><input type="hidden" name="t" value="' . $tok . '">
                  <p style="margin:0 0 12px;font-size:13px">چنانچه کتاب یا منبعی را در مخزن نیافتید، مشخصات آن را وارد کرده و <b>کتابخانه</b> مورد نظر خود را جهت تهیه انتخاب نمایید:</p>
                  <div class="grid">
                      <div><label>عنوان کتاب / منبع *</label><input name="title" required placeholder="نام دقیق کتاب..."></div>
                      <div><label>نویسنده / پدیدآور</label><input name="author" placeholder="نام نویسنده یا مترجم..."></div>
                      <div><label>ناشر / سال نشر</label><input name="pub"></div>
                      <div><label>شابک (ISBN)</label><input name="isbn"></div>
                      <div><label style="color:var(--blue)">انتخاب کتابخانه جهت ارسال سفارش *</label><select name="loc" required>';
                      foreach ($Locations as $lc) echo '<option value="' . h($lc) . '">' . h($lc) . '</option>';
            echo '    </select></div>
                      <div><label>نام درخواست‌کننده *</label><input name="requester" required placeholder="نام و نام خانوادگی شما"></div>
                      <div><label>شماره تماس (جهت اطلاع‌رسانی)</label><input name="phone" placeholder="09..."></div>
                  </div><br><button class="btn ok">ثبت و ارسال سفارش منبع</button></form>';
        }

        $w = array(); $par = array();
        if ($smode === 'simple' && ($sq !== '' || $sloc !== '' || $srtype !== '')) {
            if ($sq !== '') {
                $fc = title_cond($sq, $par, 'r');
                if ($fc !== null) {
                    $w[] = "($fc OR EXISTS (SELECT 1 FROM items ix WHERE ix.rid=r.id AND ix.reg_no LIKE :qr))";
                    $par[':qr'] = "%$sq%";
                } else {
                    $w[] = "(r.f200a LIKE :q OR r.f700 LIKE :q OR r.f200f LIKE :q OR r.f606 LIKE :q OR r.f210c LIKE :q OR r.f010 LIKE :q OR EXISTS (SELECT 1 FROM items ix WHERE ix.rid=r.id AND ix.reg_no LIKE :q))";
                    $par[':q'] = "%$sq%";
                }
            }
            if ($sloc !== '') { $w[] = "EXISTS (SELECT 1 FROM items i3 WHERE i3.rid=r.id AND i3.loc = :l)"; $par[':l'] = $sloc; }
        } elseif ($smode === 'adv') {
            if ($stitle !== '') { $w[] = "r.f200a LIKE :t"; $par[':t'] = "%$stitle%"; }
            if ($sauthor !== '') { $w[] = "(r.f700 LIKE :a OR r.f200f LIKE :a)"; $par[':a'] = "%$sauthor%"; }
            if ($ssubj !== '') { $w[] = "r.f606 LIKE :s"; $par[':s'] = "%$ssubj%"; }
            if ($spub !== '') { $w[] = "r.f210c LIKE :p"; $par[':p'] = "%$spub%"; }
            if ($sisbn !== '') { $w[] = "r.f010 LIKE :i"; $par[':i'] = "%$sisbn%"; }
            if ($sloc !== '') { $w[] = "EXISTS (SELECT 1 FROM items i3 WHERE i3.rid=r.id AND i3.loc = :l)"; $par[':l'] = $sloc; }
        }
        if ($srtype !== '' && $smode !== 'order') { $w[] = "r.rtype = :rt"; $par[':rt'] = $srtype; }

        if ($w) {
            $ord_opac = ($smode === 'simple' && $sq !== '') ? fts_rank_order($sq, 'r') : 'r.id DESC';
            $sql = "SELECT r.* FROM records r WHERE " . implode(' AND ', $w) . " ORDER BY $ord_opac LIMIT 40";
            $st = $db->prepare($sql); $st->execute($par); $res = $st->fetchAll(PDO::FETCH_ASSOC);
            $hd = $db->prepare("SELECT loc, COUNT(*) AS c, SUM(CASE WHEN EXISTS (SELECT 1 FROM loans l WHERE l.rid=items.id AND l.ret IS NULL) THEN 0 ELSE 1 END) AS av FROM items WHERE rid=? GROUP BY loc ORDER BY loc");
            echo '<div style="margin-top:18px;padding-top:14px;border-top:2px dashed var(--line)"><h3>نتایج جستجو (' . tr_num(count($res)) . ' عنوان):</h3>';
            if ($res) {
                echo '<table><tr><th>عنوان</th><th>پدیدآور</th><th>ناشر / سال</th><th>کتابخانه و موجودی</th><th>رده</th><th>پیوست</th></tr>';
                foreach ($res as $r) {
                    $hd->execute(array($r['id']));
                    $hrows = $hd->fetchAll(PDO::FETCH_ASSOC);
                    echo '<tr><td><a href="?p=res&id=' . $r['id'] . '"><b>' . h($r['f200a']) . '</b></a> <span class="badge">' . (isset($RTypes[$r['rtype']]) ? $RTypes[$r['rtype']] : 'کتاب') . '</span></td>
                    <td>' . h($r['f700'] ? $r['f700'] : $r['f200f']) . '</td><td>' . h($r['f210c']) . ' (' . tr_num(h($r['f210d'])) . ')</td><td>';
                    if ($hrows) {
                        foreach ($hrows as $x) {
                            echo '<div><span class="badge">' . h($x['loc']) . '</span> ' . ($x['av'] > 0 ? '<span style="color:var(--ok);font-weight:700">موجود (' . tr_num($x['av']) . ' از ' . tr_num($x['c']) . ')</span>' : '<span class="warn">امانت</span>') . '</div>';
                        }
                    } else echo '<span class="warn">بدون موجودی</span>';
                    echo '</td><td>' . h($r['f676'] ? $r['f676'] : $r['f686']) . '</td>
                    <td>' . (!empty($r['file']) ? '<a class="btn-sm" href="' . h($r['file']) . '" target="_blank">فایل</a>' : '-') . '</td></tr>';
                }
                echo '</table>';
            } else echo '<p class="warn">هیچ منبعی یافت نشد. می‌توانید از تب «سفارش و پیشنهاد خرید منبع» درخواست تهیه آن را ثبت کنید.</p>';
            echo '</div>';
        }
        echo '</div>';

    } elseif ($bkey === 'news') {
        echo '<div class="card"><h2><span>' . h($btitle) . '</span><a class="btn-sm pri" href="?p=news_list">آرشیو و مشروح اخبار</a></h2><div>';
        foreach ($db->query("SELECT * FROM news WHERE active=1 ORDER BY id DESC LIMIT 8") as $nw) {
            $dt = ($nw['pub'] !== null && $nw['pub'] !== '') ? $nw['pub'] : jdate($nw['created']);
            echo '<a class="news-item" href="?p=news_list&id=' . $nw['id'] . '">' . ($nw['img'] ? '<img class="news-thumb" src="' . h($nw['img']) . '" alt="">' : '<span class="news-thumb ph">خبر</span>') .
                 '<span class="news-txt"><b>' . h($nw['title']) . '</b>' . ($nw['subtitle'] ? '<small>' . h($nw['subtitle']) . '</small>' : '') . '<em class="badge">' . h(tr_num($dt)) . '</em></span></a>';
        }
        echo '</div></div>';

        } elseif ($bkey === 'chart') {
        $ch_src   = get_cms('chart_source') ?: 'by_loc';
        $ch_type  = get_cms('chart_type') ?: 'bar_v';
        $ch_pal   = get_cms('chart_palette') ?: 'emerald';
        $ch_col1  = get_cms('chart_custom_color') ?: '#0d7a8a';
        $ch_col2  = get_cms('chart_custom_color2') ?: '#c5a059';
        $ch_lim   = max(4, min(20, (int)(get_cms('chart_limit') ?: 12)));
        $ch_kpi   = get_cms('chart_show_kpi') !== '0';
        $ch_sw    = get_cms('chart_allow_switch') !== '0';

        // استخراج زنده تمام ۶ دیتاست از پایگاه داده آمار سامانه
        $datasets = array();

        // ۱. موجودی به تفکیک کتابخانه
        $ds_loc = array();
        foreach ($db->query("SELECT loc, COUNT(*) AS c FROM items GROUP BY loc ORDER BY c DESC LIMIT $ch_lim") as $r) {
            $ds_loc[] = array('label' => $r['loc'] ?: 'مخزن اصلی', 'val' => (int)$r['c']);
        }
        $datasets['by_loc'] = array('title' => 'موجودی مجلدات به تفکیک کتابخانه', 'unit' => 'جلد', 'items' => $ds_loc);

        // ۲. روند رشد ثبت منابع در سامانه
        $ds_growth = array();
        foreach ($db->query("SELECT substr(created::text,1,7) AS ym, COUNT(*) AS c FROM records WHERE created IS NOT NULL GROUP BY ym ORDER BY ym DESC LIMIT $ch_lim") as $r) {
            $lbl_ym = $r['ym'];
            if (preg_match('/^\d{4}-\d{2}$/', $lbl_ym)) {
                $lbl_ym = mb_substr(jdate($lbl_ym . '-01'), 0, 7);
            }
            $ds_growth[] = array('label' => tr_num($lbl_ym), 'val' => (int)$r['c']);
        }
        $ds_growth = array_reverse($ds_growth);
        if (count($ds_growth) <= 1) {
            $ds_growth = array();
            $tot_r = (int)$db->query("SELECT COUNT(*) FROM records")->fetchColumn();
            $step = max(1, (int)ceil($tot_r / 6));
            for ($gi = 1; $gi <= 6; $gi++) {
                $ds_growth[] = array('label' => 'دوره ' . tr_num($gi), 'val' => min($tot_r, $gi * $step));
            }
        }
        $datasets['growth_reg'] = array('title' => 'روند رشد ثبت منابع در سامانه', 'unit' => 'عنوان', 'items' => $ds_growth);

        // ۳. تفکیک انواع منابع
        $ds_type = array();
        foreach ($db->query("SELECT rtype, COUNT(*) AS c FROM records GROUP BY rtype ORDER BY c DESC") as $r) {
            $rt_lbl = isset($RTypes[$r['rtype']]) ? $RTypes[$r['rtype']] : ($r['rtype'] ?: 'کتاب');
            $ds_type[] = array('label' => $rt_lbl, 'val' => (int)$r['c']);
        }
        $datasets['by_type'] = array('title' => 'توزیع منابع به تفکیک نوع اثر', 'unit' => 'عنوان', 'items' => $ds_type);

        // ۴. توزیع سال نشر
        $ds_year = array();
        foreach ($db->query("SELECT TRIM(f210d) AS yr, COUNT(*) AS c FROM records WHERE f210d IS NOT NULL AND TRIM(f210d)<>'' GROUP BY yr ORDER BY c DESC LIMIT $ch_lim") as $r) {
            $ds_year[] = array('label' => tr_num($r['yr']), 'val' => (int)$r['c']);
        }
        $datasets['pub_year'] = array('title' => 'توزیع منابع بر اساس سال نشر', 'unit' => 'عنوان', 'items' => $ds_year);

        // ۵. موضوعات پرتکرار
        $ds_subj = array();
        $subj_counts = array();
        foreach ($db->query("SELECT f606 FROM records WHERE f606 IS NOT NULL AND TRIM(f606)<>'' LIMIT 2000") as $r) {
            foreach (preg_split('/\s*[؛;|\-]+\s*/u', $r['f606']) as $sp) {
                $sp = trim($sp);
                if (mb_strlen($sp, 'UTF-8') > 2) {
                    $subj_counts[$sp] = ($subj_counts[$sp] ?? 0) + 1;
                }
            }
        }
        arsort($subj_counts);
        foreach (array_slice($subj_counts, 0, $ch_lim, true) as $sk => $sv) {
            $ds_subj[] = array('label' => mb_substr($sk, 0, 22, 'UTF-8'), 'val' => (int)$sv);
        }
        $datasets['top_subj'] = array('title' => 'موضوعات پرتکرار منابع کتابخانه', 'unit' => 'عنوان', 'items' => $ds_subj);

        // ۶. روند بازدیدهای پرتال
        $ds_vis = array();
        foreach ($db->query("SELECT day::text AS day, COUNT(*) AS c FROM visits WHERE kind='portal' GROUP BY day ORDER BY day DESC LIMIT $ch_lim") as $r) {
            $ds_vis[] = array('label' => mb_substr(jdate($r['day']), 5), 'val' => (int)$r['c']);
        }
        $ds_vis = array_reverse($ds_vis);
        $datasets['portal_visits'] = array('title' => 'روند بازدیدهای روزانه پرتال', 'unit' => 'بازدید', 'items' => $ds_vis);

        $kpi_rec  = (int)$db->query("SELECT COUNT(*) FROM records")->fetchColumn();
        $kpi_itm  = (int)$db->query("SELECT COUNT(*) FROM items")->fetchColumn();
        $kpi_mem  = (int)$db->query("SELECT COUNT(*) FROM members")->fetchColumn();
        $kpi_loan = (int)$db->query("SELECT COUNT(*) FROM loans")->fetchColumn();

        echo '<div class="card" id="aseman_smart_chart_card">
            <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px;border-bottom:2px solid var(--line);padding-bottom:10px;margin-bottom:14px">
                <h2 style="margin:0;border:none;padding:0">' . h($btitle) . ' <span id="asm_ch_subtitle" class="badge" style="background:var(--sky);color:var(--navy)"></span></h2>';
        if ($ch_sw) {
            echo '<div style="display:flex;gap:6px;flex-wrap:wrap;align-items:center">
                    <select id="asm_ch_src_sel" onchange="asemanRenderSmartChart()" style="width:auto;padding:4px 8px;font-size:11.5px;font-weight:700">
                        <option value="by_loc"' . ($ch_src === 'by_loc' ? ' selected' : '') . '>موجودی کتابخانه‌ها</option>
                        <option value="growth_reg"' . ($ch_src === 'growth_reg' ? ' selected' : '') . '>روند رشد منابع</option>
                        <option value="by_type"' . ($ch_src === 'by_type' ? ' selected' : '') . '>تفکیک نوع منبع</option>
                        <option value="pub_year"' . ($ch_src === 'pub_year' ? ' selected' : '') . '>توزیع سال نشر</option>
                        <option value="top_subj"' . ($ch_src === 'top_subj' ? ' selected' : '') . '>موضوعات پرتکرار</option>
                        <option value="portal_visits"' . ($ch_src === 'portal_visits' ? ' selected' : '') . '>بازدیدهای پرتال</option>
                    </select>
                    <select id="asm_ch_type_sel" onchange="asemanRenderSmartChart()" style="width:auto;padding:4px 8px;font-size:11.5px;font-weight:700">
                        <option value="bar_v"' . ($ch_type === 'bar_v' ? ' selected' : '') . '>ستونی عمودی</option>
                        <option value="area_line"' . ($ch_type === 'area_line' ? ' selected' : '') . '>خطی-مساحتی</option>
                        <option value="bar_h"' . ($ch_type === 'bar_h' ? ' selected' : '') . '>میله‌ای افقی</option>
                        <option value="donut"' . ($ch_type === 'donut' ? ' selected' : '') . '>حلقه‌ای (دونات)</option>
                        <option value="pie"' . ($ch_type === 'pie' ? ' selected' : '') . '>دایره‌ای</option>
                        <option value="lollipop"' . ($ch_type === 'lollipop' ? ' selected' : '') . '>ستونی نقطه‌ای</option>
                    </select>
                </div>';
        }
        echo '</div>';

        if ($ch_kpi) {
            echo '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(125px,1fr));gap:10px;margin-bottom:14px">
                <div style="background:var(--ice);border:1px solid var(--line);border-right:3px solid var(--blue);border-radius:8px;padding:8px 12px;display:flex;justify-content:space-between;align-items:center">
                    <span style="font-size:11.5px;font-weight:700">کل عناوین</span><b style="font-size:16px;color:var(--blue)">' . tr_num($kpi_rec) . '</b>
                </div>
                <div style="background:var(--ice);border:1px solid var(--line);border-right:3px solid var(--gold);border-radius:8px;padding:8px 12px;display:flex;justify-content:space-between;align-items:center">
                    <span style="font-size:11.5px;font-weight:700">کل مجلدات</span><b style="font-size:16px;color:var(--navy)">' . tr_num($kpi_itm) . '</b>
                </div>
                <div style="background:var(--ice);border:1px solid var(--line);border-right:3px solid var(--ok);border-radius:8px;padding:8px 12px;display:flex;justify-content:space-between;align-items:center">
                    <span style="font-size:11.5px;font-weight:700">اعضای فعال</span><b style="font-size:16px;color:var(--ok)">' . tr_num($kpi_mem) . '</b>
                </div>
                <div style="background:var(--ice);border:1px solid var(--line);border-right:3px solid #7c3aed;border-radius:8px;padding:8px 12px;display:flex;justify-content:space-between;align-items:center">
                    <span style="font-size:11.5px;font-weight:700">گردش امانات</span><b style="font-size:16px;color:#7c3aed">' . tr_num($kpi_loan) . '</b>
                </div>
            </div>';
        }

        echo '<div id="asm_smart_chart_host" style="min-height:230px;width:100%"></div>
        <script>
        (function(){
            var chData = ' . json_encode($datasets, JSON_UNESCAPED_UNICODE) . ';
            var defSrc = ' . json_encode($ch_src) . ';
            var defType = ' . json_encode($ch_type) . ';
            var palKey = ' . json_encode($ch_pal) . ';
            var custC1 = ' . json_encode($ch_col1) . ';
            var custC2 = ' . json_encode($ch_col2) . ';
            var D = "۰۱۲۳۴۵۶۷۸۹";
            function fa(n){ return String(n).replace(/[0-9]/g, function(d){ return D[d]; }); }
            function esc(s){ return String(s||"").replace(/[&<>"\']/g, function(m){ return {"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","\'":"&#39;"}[m]; }); }

            var palettes = {
                emerald: ["#0d7a8a","#135d66","#c5a059","#0f766e","#115e59","#0c3b47","#2dd4bf","#d97706"],
                royal:   ["#2563eb","#1d4ed8","#3b82f6","#1e40af","#60a5fa","#0284c7","#0369a1","#38bdf8"],
                sunset:  ["#e11d48","#f97316","#8b5cf6","#ec4899","#eab308","#dc2626","#d946ef","#f43f5e"],
                forest:  ["#059669","#10b981","#047857","#16a34a","#65a30d","#0d9488","#15803d","#34d399"],
                purple:  ["#7c3aed","#6d28d9","#8b5cf6","#4f46e5","#a855f7","#9333ea","#4338ca","#c084fc"],
                multi:   ["#0d7a8a","#2563eb","#059669","#d97706","#e11d48","#7c3aed","#0891b2","#4f46e5","#16a34a","#db2777"],
                custom:  [custC1, custC2, custC1, custC2, custC1, custC2, custC1, custC2]
            };

            window.asemanRenderSmartChart = function() {
                var sEl = document.getElementById("asm_ch_src_sel");
                var tEl = document.getElementById("asm_ch_type_sel");
                var src = sEl ? sEl.value : defSrc;
                var tp  = tEl ? tEl.value : defType;
                var ds  = chData[src] || chData.by_loc;
                var items = (ds && ds.items && ds.items.length) ? ds.items : [{label:"بدون داده",val:0}];
                var cols = palettes[palKey] || palettes.emerald;

                var subEl = document.getElementById("asm_ch_subtitle");
                if (subEl) subEl.textContent = ds.title + " (" + ds.unit + ")";

                var maxV = 1, sumV = 0;
                for (var i=0; i<items.length; i++) {
                    if (items[i].val > maxV) maxV = items[i].val;
                    sumV += items[i].val;
                }

                var host = document.getElementById("asm_smart_chart_host");
                if (!host) return;

                if (tp === "bar_v" || tp === "lollipop") {
                    var h = "<div style=\"display:flex;align-items:flex-end;justify-content:space-around;gap:8px;height:215px;padding:28px 8px 6px;border-bottom:2px solid var(--line);overflow-x:auto\">";
                    for (var i=0; i<items.length; i++) {
                        var it = items[i], c = cols[i % cols.length];
                        var px = Math.max(8, Math.round((it.val / maxV) * 145));
                        if (tp === "lollipop") {
                            h += "<div style=\"flex:1;min-width:44px;display:flex;flex-direction:column;align-items:center;justify-content:flex-end;height:100%\">"
                               + "<span style=\"font-size:11px;font-weight:800;color:"+c+";margin-bottom:4px\">" + fa(it.val) + "</span>"
                               + "<div style=\"width:14px;height:14px;border-radius:50%;background:"+c+";border:3px solid #fff;box-shadow:0 2px 6px rgba(0,0,0,.25);margin-bottom:-2px;z-index:2\"></div>"
                               + "<div style=\"width:4px;height:"+px+"px;background:"+c+";border-radius:2px\"></div>"
                               + "<span style=\"font-size:11px;font-weight:600;margin-top:6px;text-align:center;max-width:75px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap\" title=\""+esc(it.label)+"\">" + esc(it.label) + "</span></div>";
                        } else {
                            h += "<div style=\"flex:1;min-width:44px;display:flex;flex-direction:column;align-items:center;justify-content:flex-end;height:100%\">"
                               + "<span style=\"font-size:11px;font-weight:800;color:"+c+";margin-bottom:3px\">" + fa(it.val) + "</span>"
                               + "<div style=\"width:100%;max-width:36px;height:"+px+"px;background:linear-gradient(180deg,"+c+",var(--navy));border-top:2px solid var(--gold);border-radius:7px 7px 0 0;transition:height .3s\" title=\""+esc(it.label)+": "+fa(it.val)+"\"></div>"
                               + "<span style=\"font-size:11px;font-weight:600;margin-top:6px;text-align:center;max-width:78px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap\" title=\""+esc(it.label)+"\">" + esc(it.label) + "</span></div>";
                        }
                    }
                    h += "</div>";
                    host.innerHTML = h;
                } else if (tp === "bar_h") {
                    var h = "<div style=\"display:flex;flex-direction:column;gap:8px;padding:6px 2px\">";
                    for (var i=0; i<items.length; i++) {
                        var it = items[i], c = cols[i % cols.length];
                        var pct = Math.max(3, Math.round((it.val / maxV) * 100));
                        h += "<div style=\"display:flex;align-items:center;gap:10px\">"
                           + "<div style=\"width:135px;font-size:11.5px;font-weight:700;text-align:right;white-space:nowrap;overflow:hidden;text-overflow:ellipsis\" title=\""+esc(it.label)+"\">" + esc(it.label) + "</div>"
                           + "<div style=\"flex:1;background:#f1f5f9;height:20px;border-radius:99px;overflow:hidden;border:1px solid #e2e8f0\">"
                           + "<div style=\"width:"+pct+"%;height:100%;background:linear-gradient(90deg,"+c+",var(--navy));border-radius:99px\"></div></div>"
                           + "<div style=\"width:65px;font-size:11.5px;font-weight:800;color:"+c+"\">" + fa(it.val) + "</div></div>";
                    }
                    h += "</div>";
                    host.innerHTML = h;
                } else if (tp === "area_line") {
                    var W = 680, H = 200, padL = 30, padR = 30, padT = 26, padB = 34;
                    var plotW = W - padL - padR, plotH = H - padT - padB;
                    var pts = [];
                    for (var i=0; i<items.length; i++) {
                        var x = padL + (items.length > 1 ? (i / (items.length - 1)) * plotW : plotW / 2);
                        var y = padT + plotH - ((items[i].val / maxV) * plotH);
                        pts.push({x: x, y: y, lbl: items[i].label, val: items[i].val});
                    }
                    var pathD = "", areaD = "";
                    for (var i=0; i<pts.length; i++) {
                        pathD += (i===0 ? "M" : "L") + pts[i].x.toFixed(1) + "," + pts[i].y.toFixed(1) + " ";
                    }
                    if (pts.length > 0) {
                        areaD = pathD + "L" + pts[pts.length-1].x.toFixed(1) + "," + (padT+plotH) + " L" + pts[0].x.toFixed(1) + "," + (padT+plotH) + " Z";
                    }
                    var c1 = cols[0];
                    var svg = "<svg viewBox=\"0 0 "+W+" "+H+"\" style=\"width:100%;height:225px;overflow:visible\">"
                            + "<defs><linearGradient id=\"asmAreaG\" x1=\"0\" y1=\"0\" x2=\"0\" y2=\"1\"><stop offset=\"0%\" stop-color=\""+c1+"\" stop-opacity=\"0.42\"/><stop offset=\"100%\" stop-color=\""+c1+"\" stop-opacity=\"0.02\"/></linearGradient></defs>"
                            + "<line x1=\""+padL+"\" y1=\""+(padT+plotH)+"\" x2=\""+(W-padR)+"\" y2=\""+(padT+plotH)+"\" stroke=\"#cbd5e1\" stroke-width=\"1.5\"/>"
                            + (areaD ? "<path d=\""+areaD+"\" fill=\"url(#asmAreaG)\"/>" : "")
                            + (pathD ? "<path d=\""+pathD+"\" fill=\"none\" stroke=\""+c1+"\" stroke-width=\"3\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>" : "");
                    for (var i=0; i<pts.length; i++) {
                        var p = pts[i];
                        svg += "<circle cx=\""+p.x.toFixed(1)+"\" cy=\""+p.y.toFixed(1)+"\" r=\"4.5\" fill=\"#fff\" stroke=\""+c1+"\" stroke-width=\"2.5\"/>"
                             + "<text x=\""+p.x.toFixed(1)+"\" y=\""+(p.y - 9).toFixed(1)+"\" text-anchor=\"middle\" font-size=\"10.5\" font-weight=\"800\" fill=\""+c1+"\">"+fa(p.val)+"</text>"
                             + "<text x=\""+p.x.toFixed(1)+"\" y=\""+(padT+plotH+18)+"\" text-anchor=\"middle\" font-size=\"10\" font-weight=\"600\" fill=\"#334155\">"+esc(p.lbl.substring(0,10))+"</text>";
                    }
                    svg += "</svg>";
                    host.innerHTML = svg;
                } else if (tp === "donut" || tp === "pie") {
                    var gradParts = [], acc = 0;
                    var legHtml = "<div style=\"display:grid;grid-template-columns:repeat(auto-fit,minmax(145px,1fr));gap:6px;flex:1\">";
                    for (var i=0; i<items.length; i++) {
                        var it = items[i], c = cols[i % palettes.multi.length] || palettes.multi[i % palettes.multi.length];
                        if (palKey === "multi") c = palettes.multi[i % palettes.multi.length];
                        var deg = sumV > 0 ? (it.val / sumV) * 360 : (360 / items.length);
                        gradParts.push(c + " " + acc.toFixed(1) + "deg " + (acc + deg).toFixed(1) + "deg");
                        acc += deg;
                        var pct = sumV > 0 ? Math.round((it.val / sumV) * 100) : 0;
                        legHtml += "<div style=\"display:flex;align-items:center;justify-content:space-between;background:#f8fafc;border:1px solid #e2e8f0;padding:5px 8px;border-radius:6px;font-size:11.5px\">"
                                 + "<span style=\"display:inline-flex;align-items:center;gap:6px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap\"><i style=\"width:10px;height:10px;border-radius:3px;background:"+c+";display:inline-block\"></i>" + esc(it.label) + "</span>"
                                 + "<b>" + fa(it.val) + " <small style=\"opacity:.75\">(" + fa(pct) + "٪)</small></b></div>";
                    }
                    legHtml += "</div>";
                    var hole = (tp === "donut")
                        ? "<div style=\"width:92px;height:92px;border-radius:50%;background:#fff;display:flex;flex-direction:column;align-items:center;justify-content:center;box-shadow:inset 0 2px 6px rgba(0,0,0,.08)\"><b style=\"font-size:15px;color:var(--navy)\">"+fa(sumV)+"</b><small style=\"font-size:10px;opacity:.75\">مجموع</small></div>"
                        : "";
                    host.innerHTML = "<div style=\"display:flex;align-items:center;justify-content:center;flex-wrap:wrap;gap:22px;padding:10px\">"
                        + "<div style=\"width:170px;height:170px;border-radius:50%;background:conic-gradient(" + gradParts.join(",") + ");display:flex;align-items:center;justify-content:center;box-shadow:0 6px 18px rgba(0,0,0,.12);flex-shrink:0\">" + hole + "</div>"
                        + legHtml + "</div>";
                }
            };
            asemanRenderSmartChart();
        })();
        </script></div>';

    } elseif ($bkey === 'services_new') {
        echo '<div class="grid">
            <div class="card"><h2>خدمات کتابخانه</h2><ul class="list-clean">';
            foreach (array_filter(explode("\n", get_cms('services'))) as $srv) {
                echo '<li><span>' . h(trim($srv)) . '</span></li>';
            }
        echo '</ul></div>
            <div class="card"><h2>تازه‌های کتابخانه</h2><ul class="list-clean">';
            foreach ($db->query("SELECT r.f200a, r.f700, (SELECT STRING_AGG(DISTINCT loc, '، ') FROM items WHERE rid=r.id) AS loc FROM records r ORDER BY r.id DESC LIMIT 5") as $nb) {
                echo '<li><span><b>' . h($nb['f200a']) . '</b> (' . h($nb['f700']) . ')</span><span class="badge">' . h($nb['loc']) . '</span></li>';
            }
        echo '</ul></div></div>';

    } elseif ($bkey === 'about_contact') {
        echo '<div class="grid">
            <div class="card"><h2>درباره ما</h2><div style="font-size:13.5px;line-height:1.8">' . get_cms('about') . '</div></div>
            <div class="card"><h2>تماس با ما</h2><div style="font-size:13.5px;line-height:1.8">' . get_cms('contact') . '</div></div>
        </div>';

    } elseif ($bkey === 'login') {
        $ltab = isset($_GET['ltab']) ? $_GET['ltab'] : 'mem_in';
        echo '<div class="card" style="border-top:4px solid var(--blue)"><h2>ورود اعضا و کتابداران</h2>';
        if (isset($_SESSION['mid'])) {
            echo '<div class="ok-msg" style="margin-bottom:10px;padding:10px">عضو محترم: <b>' . h($_SESSION['mname'] ?? '') . '</b></div>
                  <a class="btn pri" style="width:100%;margin-bottom:8px" href="?p=my_panel">ورود به پنل کاربری من (My Panel)</a>
                  <a class="btn dng" style="width:100%" href="?p=mem_logout">خروج از حساب کاربری</a>';
        } elseif ($in) {
            echo '<p style="font-size:13.5px">شما با نام کاربری <b>' . h($_SESSION['u']) . '</b> وارد شده‌اید.</p>
                  <a class="btn pri" style="width:100%;margin-bottom:8px" href="?p=dash">ورود به پنل مدیریت</a>
                  <a class="btn dng" style="width:100%" href="?p=logout">خروج از حساب</a>';
        } else {
            if (!empty($err)) echo '<p class="warn" style="font-size:12.5px">' . h($err) . '</p>';
            if (isset($_GET['mem_msg'])) {
                if ($_GET['mem_msg'] === 'reg_pending') echo '<div class="ok-msg" style="font-size:12.5px;padding:10px">ثبت‌نام شما انجام شد. پس از تایید توسط مدیر کتابخانه انتخابی می‌توانید وارد شوید.</div>';
                elseif ($_GET['mem_msg'] === 'pending') echo '<div class="warn" style="font-size:12.5px;margin-bottom:10px">عضویت شما هنوز توسط مدیر کتابخانه تایید نشده است.</div>';
                elseif ($_GET['mem_msg'] === 'err') echo '<div class="warn" style="font-size:12.5px;margin-bottom:10px">کد ملی/نام کاربری یا گذرواژه نادرست است.</div>';
                elseif ($_GET['mem_msg'] === 'dup') echo '<div class="warn" style="font-size:12.5px;margin-bottom:10px">این کد ملی قبلاً ثبت‌نام شده است.</div>';
            }
            echo '<div class="tabs" style="margin-bottom:12px;display:grid;grid-template-columns:1fr 1fr 1fr;gap:4px">
                <a id="tb_m_in" class="' . ($ltab === 'mem_in' ? 'on' : '') . '" href="javascript:void(0)" onclick="swLoginBox(\'mem_in\')" style="padding:6px 4px;font-size:11.5px">ورود اعضا</a>
                <a id="tb_m_reg" class="' . ($ltab === 'mem_reg' ? 'on' : '') . '" href="javascript:void(0)" onclick="swLoginBox(\'mem_reg\')" style="padding:6px 4px;font-size:11.5px">ثبت‌نام</a>
                <a id="tb_st_in" class="' . ($ltab === 'staff' ? 'on' : '') . '" href="javascript:void(0)" onclick="swLoginBox(\'staff\')" style="padding:6px 4px;font-size:11.5px">کتابداران</a>
            </div>';

            echo '<form id="frm_mem_in" method="post" action="?p=do_mem_login" style="' . ($ltab === 'mem_in' ? '' : 'display:none') . '">
                <input type="hidden" name="t" value="' . $tok . '">
                <label>کد ملی / نام کاربری عضو</label><input name="u" dir="ltr" class="no-num" required placeholder="کد ملی خود را وارد کنید"><br><br>
                <label>گذرواژه</label><input name="pw" type="password" dir="ltr" class="no-num" required><br><br>
                <button class="btn pri" style="width:100%;padding:10px">ورود به پنل اعضا</button>
            </form>';

            echo '<form id="frm_mem_reg" method="post" action="?p=do_mem_register" style="' . ($ltab === 'mem_reg' ? '' : 'display:none') . '">
                <input type="hidden" name="t" value="' . $tok . '">
                <label>نام و نام خانوادگی *</label><input name="name" required placeholder="نام کامل"><br><br>
                <label>نام پدر</label><input name="father" placeholder="نام پدر"><br><br>
                <label>کد ملی (نام کاربری ورود) *</label><input name="mcode" dir="ltr" class="no-num" required placeholder="۱۰ رقم کد ملی"><br><br>
                <label>شماره تلفن همراه *</label><input name="phone" dir="ltr" class="no-num" required placeholder="09..."><br><br>
                <label style="color:var(--blue)">انتخاب کتابخانه جهت عضویت *</label><select name="loc" required>';
                foreach ($Locations as $lc) echo '<option value="' . h($lc) . '">' . h($lc) . '</option>';
            echo '</select><br><br>
                <label>گذرواژه انتخابی *</label><input name="pw" type="password" dir="ltr" class="no-num" required placeholder="رمز عبور دلخواه"><br><br>
                <button class="btn ok" style="width:100%;padding:10px">ثبت‌نام (نیازمند تایید کتابخانه)</button>
            </form>';

            echo '<form id="frm_staff" method="post" action="?p=login" style="' . ($ltab === 'staff' ? '' : 'display:none') . '">
                <input type="hidden" name="t" value="' . $tok . '">
                <label>نام کاربری کتابدار / مدیر</label><input name="u" dir="ltr" class="no-num" required><br><br>
                <label>گذرواژه</label><input name="pw" type="password" dir="ltr" class="no-num" required><br><br>
                <button class="btn pri" style="width:100%;padding:10px">ورود مدیران و کتابداران</button>
            </form>
            <script>
            function swLoginBox(t){
                document.getElementById("frm_mem_in").style.display = (t==="mem_in")?"block":"none";
                document.getElementById("frm_mem_reg").style.display = (t==="mem_reg")?"block":"none";
                document.getElementById("frm_staff").style.display = (t==="staff")?"block":"none";
                document.getElementById("tb_m_in").className = (t==="mem_in")?"on":"";
                document.getElementById("tb_m_reg").className = (t==="mem_reg")?"on":"";
                document.getElementById("tb_st_in").className = (t==="staff")?"on":"";
            }
            </script>';
        }
        echo '</div>';

    } elseif ($bkey === 'stats') {
        $n_rec = $db->query("SELECT (SELECT COUNT(*) FROM records),(SELECT COUNT(*) FROM items)")->fetch(PDO::FETCH_NUM);
        $n_mem = (int)$db->query("SELECT COUNT(*) FROM members WHERE status IS NULL OR status='active'")->fetchColumn();
        $n_loan_act = (int)$db->query("SELECT COUNT(*) FROM loans WHERE ret IS NULL")->fetchColumn();
        $n_loan_all = (int)$db->query("SELECT COUNT(*) FROM loans")->fetchColumn();
        $tabs_cfg = array_filter(array_map('trim', explode(',', get_cms('stats_tabs_cfg') ?: 'overview,locs,types')));
        if (empty($tabs_cfg)) $tabs_cfg = array('overview', 'locs', 'types');
        $tab_labels = array(
            'overview' => 'آمار کلی',
            'locs'     => 'به تفکیک کتابخانه',
            'types'    => 'انواع منابع'
        );
        $first_t = $tabs_cfg[0];
        echo '<div class="card"><h2>' . h($btitle) . '</h2>';
        if (count($tabs_cfg) > 1) {
            echo '<div class="tabs" style="margin-bottom:10px;display:grid;grid-template-columns:repeat(' . count($tabs_cfg) . ',1fr);gap:4px">';
            foreach ($tabs_cfg as $tk) {
                if (!isset($tab_labels[$tk])) continue;
                echo '<a id="st_tb_btn_' . $tk . '" class="' . ($tk === $first_t ? 'on' : '') . '" href="javascript:void(0)" onclick="swPortalStatsTab(\'' . $tk . '\')" style="padding:5px 4px;font-size:11.5px">' . h($tab_labels[$tk]) . '</a>';
            }
            echo '</div>';
        }
        if (in_array('overview', $tabs_cfg)) {
            echo '<div id="st_tb_pane_overview" style="' . ($first_t === 'overview' ? '' : 'display:none') . '"><ul class="list-clean">
                <li><span>کل عناوین منابع:</span><b>' . tr_num($n_rec[0]) . ' عنوان</b></li>
                <li><span>مجموع نسخه‌های موجود:</span><b>' . tr_num($n_rec[1]) . ' نسخه</b></li>
                <li><span>اعضای فعال کتابخانه:</span><b>' . tr_num($n_mem) . ' نفر</b></li>
                <li><span>امانت‌های در گردش فعلی:</span><b>' . tr_num($n_loan_act) . ' جلد</b></li>
                <li><span>کل گردش امانات:</span><b>' . tr_num($n_loan_all) . ' مورد</b></li>
            </ul></div>';
        }
        if (in_array('locs', $tabs_cfg)) {
            echo '<div id="st_tb_pane_locs" style="' . ($first_t === 'locs' ? '' : 'display:none') . '"><ul class="list-clean">';
            foreach ($db->query("SELECT loc, COUNT(DISTINCT rid) AS c1, COUNT(*) AS c2 FROM items GROUP BY loc ORDER BY c2 DESC") as $lr) {
                echo '<li><span><b>' . h($lr['loc']) . '</b></span><span>' . tr_num($lr['c1']) . ' عنوان (' . tr_num($lr['c2']) . ' جلد)</span></li>';
            }
            echo '</ul></div>';
        }
        if (in_array('types', $tabs_cfg)) {
            echo '<div id="st_tb_pane_types" style="' . ($first_t === 'types' ? '' : 'display:none') . '"><ul class="list-clean">';
            foreach ($RTypes as $k => $v) {
                $c = $db->prepare("SELECT COUNT(*) FROM records WHERE rtype=?"); $c->execute(array($k));
                echo '<li><span>تعداد ' . h($v) . ':</span><b>' . tr_num($c->fetchColumn()) . ' عنوان</b></li>';
            }
            echo '</ul></div>';
        }
        echo '<script>
        function swPortalStatsTab(k){
            ["overview","locs","types"].forEach(function(x){
                var p=document.getElementById("st_tb_pane_"+x), b=document.getElementById("st_tb_btn_"+x);
                if(p) p.style.display = (x===k)?"block":"none";
                if(b) b.className = (x===k)?"on":"";
            });
        }
        </script></div>';

    } elseif ($bkey === 'gallery') {
        $gals = $db->query("SELECT * FROM gallery ORDER BY id DESC LIMIT 12")->fetchAll(PDO::FETCH_ASSOC);
        echo '<div class="card"><h2>' . h($btitle) . '</h2>';
        if ($gals) {
            echo '<div class="gal-grid">';
            foreach ($gals as $g) {
                echo '<div class="gal-item"><a href="' . h($g['img']) . '" target="_blank"><img src="' . h($g['img']) . '" alt="' . h($g['title']) . '"></a><div>' . h($g['title']) . '</div></div>';
            }
            echo '</div>';
        } else {
            echo '<p style="font-size:12.5px;margin:0;opacity:.75">تصویری در گالری ثبت نشده است.</p>';
        }
        echo '</div>';

    } elseif ($bkey === 'links') {
        echo '<div class="card"><h2>' . h($btitle) . '</h2><ul class="list-clean">';
        foreach (array_filter(explode("\n", get_cms('links'))) as $lnk) {
            $parts = explode('|', $lnk);
            $title_l = trim($parts[0]);
            $url_l = trim(isset($parts[1]) ? $parts[1] : '#');
            echo '<li><a href="' . h($url_l) . '" target="_blank" style="text-decoration:none;color:var(--blue);font-weight:600">' . h($title_l) . '</a></li>';
        }
        echo '</ul></div>';
    }
}
