<?php
/**
 * اسکریپت ارتقای منوی مانیتورینگ (Enterprise Audit Trail)
 * و افزودن باکس جستجو و لیست منابع به منوی ثبت و ویرایش منابع (?p=form)
 */
define('ASEMAN_ROOT', __DIR__);
error_reporting(E_ALL);
ini_set('display_errors', 1);
header('Content-Type: text/html; charset=utf-8');

require_once ASEMAN_ROOT . '/config/constants.php';
require_once ASEMAN_ROOT . '/config/database.php';

$logs = array();

// اطمینان از وجود جدول audit_log در پایگاه داده PostgreSQL
try {
    $db->exec("CREATE TABLE IF NOT EXISTS audit_log(
        id SERIAL PRIMARY KEY,
        ts TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        uname TEXT,
        uloc TEXT,
        action TEXT,
        target_id INT DEFAULT 0,
        detail TEXT
    )");
    $db->exec("CREATE INDEX IF NOT EXISTS idx_audit_ts ON audit_log(ts DESC)");
    $logs[] = "جدول ممیزی امنیتی <code>audit_log</code> در پایگاه داده بررسی و آماده شد.";
} catch (Exception $e) {}

// ============================================================================
// ۱. تکمیل ثبت خودکار رخدادهای ورود و خروج در includes/auth_guard.php
// ============================================================================
$agFile = ASEMAN_ROOT . '/includes/auth_guard.php';
if (file_exists($agFile)) {
    $agCode = file_get_contents($agFile);
    if (strpos($agCode, "audit_log_event('login'") === false) {
        $agCode = str_replace(
            "sess_log_start();",
            "sess_log_start();\n        if (function_exists('audit_log_event')) audit_log_event('login', (int)(\$u['id'] ?? 0), 'ورود موفق به پنل مدیریت (' . \$u['u'] . ')');",
            $agCode
        );
    }
    if (strpos($agCode, "audit_log_event('logout'") === false) {
        $agCode = str_replace(
            "if (isset(\$_SESSION['u'])) sess_end_sid(my_sid(), 'logout');",
            "if (isset(\$_SESSION['u'])) { if (function_exists('audit_log_event')) audit_log_event('logout', 0, 'خروج کاربر از سامانه (' . \$_SESSION['u'] . ')'); sess_end_sid(my_sid(), 'logout'); }",
            $agCode
        );
    }
    file_put_contents($agFile, $agCode);
    $logs[] = "ثبت خودکار رخدادهای ورود و خروج در <code>includes/auth_guard.php</code> فعال شد.";
}

// ============================================================================
// ۲. تکمیل ثبت رخدادهای ثبت/ویرایش/حذف منبع، امانت و تغییرات مدیریتی در actions/post_handlers.php
// ============================================================================
$phFile = ASEMAN_ROOT . '/actions/post_handlers.php';
if (file_exists($phFile)) {
    $phCode = file_get_contents($phFile);

    // الف) ثبت و ویرایش منبع در اکشن save
    if (strpos($phCode, "audit_log_event('edit_record'") === false) {
        $phCode = str_replace(
            "lock_release(\$id);\n            \$msg = 'saved';",
            "lock_release(\$id);\n            audit_log_event('edit_record', \$id, 'ویرایش منبع: ' . (\$d['f200a'] ?? '') . ' [' . \$loc . ']');\n            \$msg = 'saved';",
            $phCode
        );
    }
    if (strpos($phCode, "audit_log_event('add_record'") === false) {
        $phCode = str_replace(
            "\$msg = \$res[1] ? 'saved' : 'dup';",
            "\$msg = \$res[1] ? 'saved' : 'dup';\n            audit_log_event('add_record', \$id, ('ثبت منبع: ' . (\$d['f200a'] ?? '') . ' - ' . \$vols . ' جلد در ' . \$loc));",
            $phCode
        );
    }

    // ب) حذف منبع در اکشن del
    if (strpos($phCode, "audit_log_event('delete_record'") === false) {
        $phCode = str_replace(
            "if (\$p === 'del' && (can('form') || can('rec'))) {\n        \$id = (int)\$_POST['id'];",
            "if (\$p === 'del' && (can('form') || can('rec'))) {\n        \$id = (int)\$_POST['id'];\n        audit_log_event('delete_record', \$id, 'حذف منبع / مجلدات رکورد #' . \$id);",
            $phCode
        );
    }

    // ج) بازگشت امانت در اکشن back
    if (strpos($phCode, "audit_log_event('loan_return'") === false) {
        $phCode = str_replace(
            "if (\$p === 'back' && (can('rec') || can('loan'))) {\n        \$db->prepare(\"UPDATE loans SET ret=? WHERE id=?\")->execute(array(date('Y-m-d'), (int)\$_POST['id']));",
            "if (\$p === 'back' && (can('rec') || can('loan'))) {\n        \$db->prepare(\"UPDATE loans SET ret=? WHERE id=?\")->execute(array(date('Y-m-d'), (int)\$_POST['id']));\n        audit_log_event('loan_return', (int)\$_POST['id'], 'ثبت بازگشت امانت #' . (int)\$_POST['id']);",
            $phCode
        );
    }

    // د) مدیریت کاربران و پرتال
    if (strpos($phCode, "audit_log_event('save_user'") === false) {
        $phCode = str_replace(
            "header('Location: ?p=users&msg=saved');",
            "audit_log_event('save_user', \$edit_uid, 'ثبت/ویرایش کاربر: ' . \$u . ' (کتابخانه: ' . \$uloc . ')');\n        header('Location: ?p=users&msg=saved');",
            $phCode
        );
    }
    if (strpos($phCode, "audit_log_event('delete_user'") === false) {
        $phCode = str_replace(
            "\$db->prepare(\"DELETE FROM users WHERE u=?\")->execute(array(\$u));",
            "\$db->prepare(\"DELETE FROM users WHERE u=?\")->execute(array(\$u));\n            audit_log_event('delete_user', 0, 'حذف کاربر: ' . \$u);",
            $phCode
        );
    }
    if (strpos($phCode, "audit_log_event('update_portal_cms'") === false) {
        $phCode = str_replace(
            "header(\"Location: ?p=cms&box=\$box&msg=saved\");",
            "audit_log_event('update_portal_cms', 0, 'بروزرسانی تنظیمات پرتال (بخش: ' . \$box . ')');\n        header(\"Location: ?p=cms&box=\$box&msg=saved\");",
            $phCode
        );
    }

    file_put_contents($phFile, $phCode);
    $logs[] = "ثبت خودکار رخدادهای ثبت/ویرایش منبع، حذف، امانت و تغییرات مدیریتی در <code>actions/post_handlers.php</code> فعال شد.";
}

// ============================================================================
// ۳. افزودن Enterprise Audit Trail به منوی مانیتورینگ در modules/settings.php
// ============================================================================
$setFile = ASEMAN_ROOT . '/modules/settings.php';
if (file_exists($setFile)) {
    $sCode = file_get_contents($setFile);

    // حذف نسخه قبلی باکس در صورت اجرای مجدد اسکریپت
    $oldAuditStart = strpos($sCode, '// --- ASEMAN V16: ماژول Enterprise Audit Trail');
    $usersPos      = strpos($sCode, "} elseif (\$p === 'users') {");
    if ($oldAuditStart !== false && $usersPos !== false && $usersPos > $oldAuditStart) {
        $sCode = substr($sCode, 0, $oldAuditStart) . substr($sCode, $usersPos);
    }

    $auditTrailBlock = <<<'NOWDOC'
    // --- ASEMAN V16: ماژول Enterprise Audit Trail (ردیابی فعالیت‌های کاربران و کتابداران برای ممیزی امنیتی) ---
    $au_user = trim($_GET['au_user'] ?? '');
    $au_loc  = trim($_GET['au_loc'] ?? '');
    $au_act  = trim($_GET['au_act'] ?? '');
    $au_q    = trim($_GET['au_q'] ?? '');
    $au_pg   = max(1, (int)($_GET['au_pg'] ?? 1));
    $au_per  = 50;

    $au_w = array();
    $au_p = array();
    if ($au_user !== '') {
        $au_w[] = "uname LIKE :au_u";
        $au_p[':au_u'] = "%$au_user%";
    }
    if ($au_loc !== '') {
        $au_w[] = "uloc LIKE :au_l";
        $au_p[':au_l'] = "%$au_loc%";
    }
    if ($au_act !== '') {
        $au_w[] = "action = :au_a";
        $au_p[':au_a'] = $au_act;
    }
    if ($au_q !== '') {
        $au_w[] = "(detail LIKE :au_q OR action LIKE :au_q OR target_id::text = :au_qid)";
        $au_p[':au_q']   = "%$au_q%";
        $au_p[':au_qid'] = en_num($au_q);
    }
    $au_where = $au_w ? 'WHERE ' . implode(' AND ', $au_w) : '';

    $au_tot = 0;
    $au_rows = array();
    $au_users_list = array();
    $au_acts_list  = array();
    try {
        $st_ac = $db->prepare("SELECT COUNT(*) FROM audit_log $au_where");
        $st_ac->execute($au_p);
        $au_tot = (int)$st_ac->fetchColumn();

        $st_ar = $db->prepare("SELECT * FROM audit_log $au_where ORDER BY id DESC LIMIT $au_per OFFSET " . (($au_pg - 1) * $au_per));
        $st_ar->execute($au_p);
        $au_rows = $st_ar->fetchAll(PDO::FETCH_ASSOC);

        $au_users_list = $db->query("SELECT DISTINCT uname FROM audit_log WHERE uname IS NOT NULL AND uname<>'' ORDER BY uname")->fetchAll(PDO::FETCH_COLUMN);
        $au_acts_list  = $db->query("SELECT DISTINCT action FROM audit_log WHERE action IS NOT NULL AND action<>'' ORDER BY action")->fetchAll(PDO::FETCH_COLUMN);
    } catch (Exception $e) {}

    $act_labels_fa = array(
        'login'               => array('ورود به سامانه', '#dbeafe', '#1e40af'),
        'logout'              => array('خروج از سامانه', '#f1f5f9', '#475569'),
        'add_record'          => array('ثبت منبع جدید', '#d1fae5', '#065f46'),
        'edit_record'         => array('ویرایش منبع', '#e0f2fe', '#0369a1'),
        'delete_record'       => array('حذف منبع', '#fee2e2', '#991b1b'),
        'loan_out'            => array('ثبت امانت کتاب', '#fef3c7', '#92400e'),
        'loan_return'         => array('ثبت بازگشت امانت', '#dcfce7', '#166534'),
        'barcode_loan_out'    => array('امانت با بارکدخوان', '#fef3c7', '#92400e'),
        'barcode_loan_return' => array('بازگشت با بارکدخوان', '#dcfce7', '#166534'),
        'add_member'          => array('ثبت عضو جدید', '#ede9fe', '#5b21b6'),
        'edit_member'         => array('ویرایش عضو', '#f3e8ff', '#6b21a8'),
        'delete_member'       => array('حذف عضو', '#ffe4e6', '#be123c'),
        'save_user'           => array('ثبت/ویرایش کاربر و کتابدار', '#ffedd5', '#9a3412'),
        'delete_user'         => array('حذف کاربر', '#fee2e2', '#991b1b'),
        'save_loan_policy'    => array('تغییر سیاست امانت', '#e0e7ff', '#3730a3'),
        'update_portal_cms'   => array('تغییر تنظیمات پرتال', '#ccfbf1', '#115e59')
    );

    echo '<div class="card" id="audit_trail_box" style="border:2px solid var(--gold);margin-top:22px">
        <h2>
            <span>ردیابی فعالیت‌های کاربران و کتابداران جهت ممیزی امنیتی (Enterprise Audit Trail)</span>
            <span class="badge" style="background:var(--navy);color:#fff">مجموع وقایع ثبت‌شده: ' . tr_num($au_tot) . ' رویداد</span>
        </h2>
        <p style="font-size:13px;line-height:1.8;margin:0 0 12px">
            ماژول <b>Enterprise Audit Trail</b> تمامی رخدادهای حساس (ورود و خروج، ثبت و ویرایش منبع، حذف، گردش امانت و تغییرات مدیریتی) را همراه با <b>نام کاربر، کتابخانه، شناسه هدف و زمان دقیق</b> در جدول <code>audit_log</code> ثبت و نمایش می‌دهد:
        </p>
        <form method="get" action="#audit_trail_box" style="background:var(--ice);padding:14px;border-radius:12px;border:1px solid var(--line);margin-bottom:14px">
            <input type="hidden" name="p" value="monitoring">
            <div class="grid">
                <div>
                    <label style="color:var(--blue)">فیلتر نام کاربر / کتابدار</label>
                    <select name="au_user">
                        <option value="">همه کاربران و کتابداران</option>';
                        foreach ($au_users_list as $u_it) {
                            echo '<option value="' . h($u_it) . '"' . ($au_user === $u_it ? ' selected' : '') . '>' . h($u_it) . '</option>';
                        }
    echo '          </select>
                </div>
                <div>
                    <label style="color:var(--blue)">فیلتر نوع عملیات</label>
                    <select name="au_act">
                        <option value="">همه عملیات‌ها</option>';
                        foreach ($au_acts_list as $a_it) {
                            $lbl_a = isset($act_labels_fa[$a_it]) ? $act_labels_fa[$a_it][0] . ' (' . $a_it . ')' : $a_it;
                            echo '<option value="' . h($a_it) . '"' . ($au_act === $a_it ? ' selected' : '') . '>' . h($lbl_a) . '</option>';
                        }
    echo '          </select>
                </div>
                <div>
                    <label>فیلتر کتابخانه</label>
                    <input name="au_loc" value="' . h($au_loc) . '" placeholder="مثلاً: مخزن اصلی">
                </div>
                <div>
                    <label>جستجو در جزئیات یا شناسه هدف</label>
                    <input name="au_q" value="' . h($au_q) . '" placeholder="عنوان کتاب، نام عضو، کد...">
                </div>
            </div>
            <div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:12px">
                <button class="btn pri">اعمال فیلتر ممیزی امنیتی</button>
                <a class="btn" href="?p=monitoring#audit_trail_box">نمایش همه رویدادها</a>
            </div>
        </form>
        <table>
            <tr>
                <th>شناسه</th>
                <th>زمان دقیق وقوع</th>
                <th>نام کاربر / کتابدار</th>
                <th>کتابخانه</th>
                <th>نوع عملیات</th>
                <th>شناسه هدف</th>
                <th>جزئیات کامل رخداد</th>
            </tr>';
    if (!$au_rows) {
        echo '<tr><td colspan="7" style="text-align:center;padding:18px;color:var(--navy2)">هیچ رویدادی با فیلترهای انتخابی در جدول ممیزی امنیتی (audit_log) یافت نشد.</td></tr>';
    } else {
        foreach ($au_rows as $al) {
            $ac_code = $al['action'];
            $ac_info = isset($act_labels_fa[$ac_code]) ? $act_labels_fa[$ac_code] : array($ac_code, '#e2e8f0', '#1e293b');
            echo '<tr>
                <td>' . tr_num($al['id']) . '</td>
                <td style="white-space:nowrap">' . jdate($al['ts'], true) . '</td>
                <td><b>' . h($al['uname']) . '</b></td>
                <td><span class="badge">' . h($al['uloc']) . '</span></td>
                <td><span class="badge" style="background:' . $ac_info[1] . ';color:' . $ac_info[2] . ';border:none">' . h($ac_info[0]) . '</span> <small dir="ltr" style="opacity:.7">(' . h($ac_code) . ')</small></td>
                <td>' . ($al['target_id'] ? '<b>#' . tr_num($al['target_id']) . '</b>' : '-') . '</td>
                <td>' . h($al['detail']) . '</td>
            </tr>';
        }
    }
    echo '</table>';
    $au_last_pg = max(1, (int)ceil($au_tot / $au_per));
    if ($au_last_pg > 1) {
        echo '<div style="margin-top:12px;display:flex;gap:5px;flex-wrap:wrap">';
        $au_qs = '&au_user=' . urlencode($au_user) . '&au_loc=' . urlencode($au_loc) . '&au_act=' . urlencode($au_act) . '&au_q=' . urlencode($au_q);
        for ($ai = max(1, $au_pg - 6); $ai <= min($au_last_pg, $au_pg + 6); $ai++) {
            echo '<a class="btn-sm' . ($ai == $au_pg ? ' pri' : '') . '" href="?p=monitoring' . $au_qs . '&au_pg=' . $ai . '#audit_trail_box">' . tr_num($ai) . '</a> ';
        }
        echo '</div>';
    }
    echo '</div>';
NOWDOC;

    $usersPos = strpos($sCode, "} elseif (\$p === 'users') {");
    if ($usersPos !== false) {
        $sCode = substr($sCode, 0, $usersPos) . "\n" . $auditTrailBlock . "\n\n" . substr($sCode, $usersPos);
        file_put_contents($setFile, $sCode);
        $logs[] = "بخش <b>ردیابی فعالیت‌های کاربران و کتابداران (Enterprise Audit Trail)</b> به منوی مانیتورینگ اضافه شد.";
    }
}

// ============================================================================
// ۴. افزودن باکس جستجو بر اساس مشخصات منبع و لیست منابع به منوی ثبت و ویرایش (modules/catalog.php)
// ============================================================================
$catFile = ASEMAN_ROOT . '/modules/catalog.php';
if (file_exists($catFile)) {
    $catCode = file_get_contents($catFile);

    // حذف نسخه قبلی در صورت اجرای مجدد
    $oldCatSearch = strpos($catCode, '// --- ASEMAN V16: باکس جستجو بر اساس مشخصات منبع');
    $marcMarker   = '// ==================== نمایش شناسنامه مارک و مجلدات ====================';
    $marcPos      = strpos($catCode, $marcMarker);
    if ($oldCatSearch !== false && $marcPos !== false && $marcPos > $oldCatSearch) {
        $catCode = substr($catCode, 0, $oldCatSearch) . substr($catCode, $marcPos);
    }

    $catalogSearchAndListBlock = <<<'NOWDOC'
    // --- ASEMAN V16: باکس جستجو بر اساس مشخصات منبع و لیست منابع جهت ویرایش در منوی ثبت و ویرایش ---
    $allowed_locs = allowed_locations();
    $fq_title  = trim($_GET['fq_title'] ?? '');
    $fq_author = trim($_GET['fq_author'] ?? '');
    $fq_pub    = trim($_GET['fq_pub'] ?? '');
    $fq_code   = trim($_GET['fq_code'] ?? '');
    $fq_rtype  = trim($_GET['fq_rtype'] ?? 'all');
    $fq_loc    = is_loc_restricted() ? user_loc() : trim($_GET['fq_loc'] ?? '');
    $fpg       = max(1, (int)($_GET['fpg'] ?? 1));
    $fper      = 25;

    $fw = array();
    $fpar = array();
    if (is_loc_restricted()) {
        $fw[] = "EXISTS (SELECT 1 FROM items i WHERE i.rid=r.id AND i.loc=:uloc)";
        $fpar[':uloc'] = user_loc();
    } elseif ($fq_loc !== '') {
        $fw[] = "EXISTS (SELECT 1 FROM items i WHERE i.rid=r.id AND i.loc=:floc)";
        $fpar[':floc'] = $fq_loc;
    }
    if ($fq_rtype !== 'all' && $fq_rtype !== '' && isset($RTypes[$fq_rtype])) {
        $fw[] = "r.rtype = :frt";
        $fpar[':frt'] = $fq_rtype;
    }
    if ($fq_title !== '') {
        $fw[] = "(r.f200a LIKE :ft OR r.f200e LIKE :ft OR r.f225 LIKE :ft)";
        $fpar[':ft'] = "%$fq_title%";
    }
    if ($fq_author !== '') {
        $fw[] = "(r.f700 LIKE :fa OR r.f200f LIKE :fa OR r.f710 LIKE :fa)";
        $fpar[':fa'] = "%$fq_author%";
    }
    if ($fq_pub !== '') {
        $fw[] = "(r.f210c LIKE :fp OR r.f210a LIKE :fp OR r.f210d LIKE :fp)";
        $fpar[':fp'] = "%$fq_pub%";
    }
    if ($fq_code !== '') {
        $fw[] = "(r.f010 LIKE :fc OR r.f676 LIKE :fc OR r.f686 LIKE :fc OR r.f606 LIKE :fc OR EXISTS (SELECT 1 FROM items i2 WHERE i2.rid=r.id AND i2.reg_no LIKE :fc))";
        $fpar[':fc'] = "%$fq_code%";
    }

    $fwhere = $fw ? 'WHERE ' . implode(' AND ', $fw) : '';
    $fc_st = $db->prepare("SELECT COUNT(*) FROM records r $fwhere");
    $fc_st->execute($fpar);
    $ftot = (int)$fc_st->fetchColumn();

    $fs_st = $db->prepare("SELECT r.* FROM records r $fwhere ORDER BY r.id DESC LIMIT $fper OFFSET " . (($fpg - 1) * $fper));
    $fs_st->execute($fpar);
    $frows = $fs_st->fetchAll(PDO::FETCH_ASSOC);

    $fhold = array();
    if ($frows) {
        $fids_in = implode(',', array_map('intval', array_column($frows, 'id')));
        foreach ($db->query("SELECT i.rid, i.loc, COUNT(*) c, MIN(i.reg_no) a, MAX(i.reg_no) b FROM items i WHERE i.rid IN ($fids_in) GROUP BY i.rid, i.loc ORDER BY i.loc") as $fhr) {
            if (is_loc_restricted() && $fhr['loc'] !== user_loc()) continue;
            $fhold[$fhr['rid']][] = $fhr;
        }
    }

    echo '<div class="card" id="form_search_box" style="border:2px solid var(--gold);background:linear-gradient(145deg,#ffffff,#fffbeb);margin-top:22px">
        <h2>
            <span>جستجوی تخصصی بر اساس مشخصات منبع جهت ویرایش سریع</span>
            <span class="badge" style="background:var(--navy);color:#fff">کل منابع منطبق: ' . tr_num($ftot) . ' عنوان</span>
        </h2>
        <form method="get" action="#form_search_box">
            <input type="hidden" name="p" value="form">
            ' . ($id ? '<input type="hidden" name="id" value="' . $id . '">' : '') . '
            <div class="grid">
                <div>
                    <label style="color:var(--blue)">عنوان اصلی / فرعی / فروست (200$a)</label>
                    <input name="fq_title" value="' . h($fq_title) . '" placeholder="جستجو در عنوان کتاب...">
                </div>
                <div>
                    <label style="color:var(--blue)">پدیدآور / نویسنده / مترجم (700/200$f)</label>
                    <input name="fq_author" value="' . h($fq_author) . '" placeholder="نام مؤلف یا پدیدآور...">
                </div>
                <div>
                    <label>ناشر / محل نشر / سال نشر (210)</label>
                    <input name="fq_pub" value="' . h($fq_pub) . '" placeholder="نام انتشارات یا سال...">
                </div>
                <div>
                    <label style="color:var(--blue)">شماره ثبت / شابک / رده / موضوع</label>
                    <input name="fq_code" value="' . h($fq_code) . '" placeholder="بارکد، شابک، دیویی یا کنگره...">
                </div>
                <div>
                    <label>نوع منبع</label>
                    <select name="fq_rtype">
                        <option value="all"' . ($fq_rtype === 'all' ? ' selected' : '') . '>همه انواع منابع</option>';
                        foreach ($RTypes as $rtk => $rtv) {
                            echo '<option value="' . h($rtk) . '"' . ($fq_rtype === $rtk ? ' selected' : '') . '>' . h($rtv) . '</option>';
                        }
    echo '          </select>
                </div>
                <div>
                    <label>فیلتر کتابخانه</label>
                    <select name="fq_loc">' . (!is_loc_restricted() ? '<option value="">همه کتابخانه‌ها</option>' : '');
                    foreach ($allowed_locs as $lc) {
                        echo '<option value="' . h($lc) . '"' . ($fq_loc === $lc ? ' selected' : '') . '>' . h($lc) . '</option>';
                    }
    echo '          </select>
                </div>
            </div>
            <div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:14px">
                <button class="btn pri">جستجوی منبع برای ویرایش</button>
                <a class="btn" href="?p=form#form_search_box">پاکسازی فیلترها و نمایش همه</a>
                ' . ($id ? '<a class="btn ok" href="?p=form">+ خالی کردن فرم بالا جهت ثبت منبع جدید</a>' : '') . '
            </div>
        </form>
    </div>';

    echo '<div class="card">
        <h2>
            <span>فهرست منابع ثبت‌شده (انتخاب منبع جهت بارگذاری در فرم ویرایش)</span>
            <span class="badge">صفحه ' . tr_num($fpg) . ' از ' . tr_num(max(1, (int)ceil($ftot / $fper))) . '</span>
        </h2>
        <table>
            <tr>
                <th>شناسه</th>
                <th>نوع</th>
                <th>عنوان اثر</th>
                <th>پدیدآور</th>
                <th>ناشر / سال</th>
                <th>کتابخانه و شماره ثبت مجلدات</th>
                <th>شماره رده</th>
                <th>عملیات ویرایش و مدیریت</th>
            </tr>';
    if (!$frows) {
        echo '<tr><td colspan="8" class="warn" style="text-align:center;padding:18px">هیچ منبعی با مشخصات واردشده یافت نشد.</td></tr>';
    } else {
        foreach ($frows as $fr) {
            $is_editing_row = ($id > 0 && (int)$fr['id'] === $id);
            $row_style = $is_editing_row ? ' style="background:#fef3c7;font-weight:700"' : '';
            echo '<tr' . $row_style . '>
                <td>' . tr_num($fr['id']) . '</td>
                <td><span class="badge">' . h($RTypes[$fr['rtype']] ?? 'کتاب') . '</span></td>
                <td><b>' . h($fr['f200a']) . '</b>' . ($fr['f200e'] ? '<br><small style="color:var(--navy2)">' . h($fr['f200e']) . '</small>' : '') . '</td>
                <td>' . h($fr['f700'] ? $fr['f700'] : $fr['f200f']) . '</td>
                <td>' . h($fr['f210c']) . ($fr['f210d'] ? ' (' . tr_num(h($fr['f210d'])) . ')' : '') . '</td>
                <td>';
            if (!empty($fhold[$fr['id']])) {
                foreach ($fhold[$fr['id']] as $fhr) {
                    echo '<div style="margin-bottom:2px"><span class="badge">' . h($fhr['loc']) . '</span> <small>' . tr_num($fhr['c']) . ' جلد (' . tr_num($fhr['a']) . ($fhr['c'] > 1 ? ' تا ' . tr_num($fhr['b']) : '') . ')</small></div>';
                }
            } else {
                echo '<span class="warn">بدون موجودی</span>';
            }
            echo '</td>
                <td dir="ltr">' . h($fr['f676'] ? $fr['f676'] : $fr['f686']) . '</td>
                <td style="white-space:nowrap">
                    <div style="display:inline-flex;gap:5px;align-items:center">
                        <a class="btn-sm ' . ($is_editing_row ? 'ok' : 'pri') . '" href="?p=form&id=' . $fr['id'] . '&fq_title=' . urlencode($fq_title) . '&fq_author=' . urlencode($fq_author) . '&fq_pub=' . urlencode($fq_pub) . '&fq_code=' . urlencode($fq_code) . '&fq_rtype=' . urlencode($fq_rtype) . '&fq_loc=' . urlencode($fq_loc) . '&fpg=' . $fpg . '">' . ($is_editing_row ? '✓ در حال ویرایش در فرم بالا' : '✎ ویرایش در فرم بالا') . '</a>
                        <a class="btn-sm" href="?p=marc&id=' . $fr['id'] . '">شناسنامه و مجلدات</a>
                        ' . post_btn('del', 'حذف', array('id' => $fr['id']), 'btn-sm dng') . '
                    </div>
                </td>
            </tr>';
        }
    }
    echo '</table>';
    $flast_pg = max(1, (int)ceil($ftot / $fper));
    if ($flast_pg > 1) {
        echo '<div style="margin-top:12px;display:flex;gap:5px;flex-wrap:wrap">';
        $q_str = '&fq_title=' . urlencode($fq_title) . '&fq_author=' . urlencode($fq_author) . '&fq_pub=' . urlencode($fq_pub) . '&fq_code=' . urlencode($fq_code) . '&fq_rtype=' . urlencode($fq_rtype) . '&fq_loc=' . urlencode($fq_loc);
        for ($fi = max(1, $fpg - 6); $fi <= min($flast_pg, $fpg + 6); $fi++) {
            echo '<a class="btn-sm' . ($fi == $fpg ? ' pri' : '') . '" href="?p=form' . ($id ? '&id=' . $id : '') . $q_str . '&fpg=' . $fi . '#form_search_box">' . tr_num($fi) . '</a> ';
        }
        echo '</div>';
    }
    echo '</div>';
NOWDOC;

    $marcPos = strpos($catCode, $marcMarker);
    if ($marcPos !== false) {
        $catCode = substr($catCode, 0, $marcPos) . "\n" . $catalogSearchAndListBlock . "\n\n" . substr($catCode, $marcPos);
        file_put_contents($catFile, $catCode);
        $logs[] = "باکس جستجو بر اساس مشخصات منبع و لیست کامل منابع جهت ویرایش به منوی <code>ثبت و ویرایش منابع (?p=form)</code> اضافه شد.";
    }
}

echo '<div dir="rtl" style="font-family:Tahoma,sans-serif;padding:26px;background:#ecfdf5;color:#065f46;border:2px solid #10b981;border-radius:16px;max-width:740px;margin:40px auto;line-height:2">
    <h3 style="margin-top:0;color:#047857">✓ عملیات ارتقا با موفقیت کامل انجام شد!</h3>
    <ul style="padding-right:20px">';
foreach ($logs as $lg) {
    echo '<li>' . $lg . '</li>';
}
echo '</ul>
    <div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:18px">
        <a href="index.php?p=monitoring#audit_trail_box" style="background:#0c3b47;color:#fff;padding:10px 18px;border-radius:8px;text-decoration:none;font-weight:bold">مشاهده ممیزی امنیتی (Audit Log) در منوی مانیتورینگ</a>
        <a href="index.php?p=form#form_search_box" style="background:#0d7a8a;color:#fff;padding:10px 18px;border-radius:8px;text-decoration:none;font-weight:bold">مشاهده جستجو و لیست منابع در منوی ثبت و ویرایش</a>
    </div>
</div>';