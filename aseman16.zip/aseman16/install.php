<?php
/**
 * جادوگر نصب و پیکربندی اولیه نرم‌افزار جامع کتابخانه‌ای آسمان (نسخه Enterprise v15)
 * این اسکریپت پیش‌نیازهای سرور، اتصال PostgreSQL و حساب مدیر ارشد را بررسی و پیکربندی می‌کند.
 */
define('ASEMAN_ROOT', __DIR__);
session_start();

$msg = '';
$err = '';
$step_ok = false;

$ext_checks = array(
    'pdo_pgsql' => extension_loaded('pdo_pgsql'),
    'mbstring'  => extension_loaded('mbstring'),
    'zip'       => class_exists('ZipArchive'),
    'xml'       => function_exists('simplexml_load_string'),
    'openssl'   => function_exists('openssl_encrypt')
);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['do_install'])) {
    $pg_host = trim($_POST['pg_host'] ?? '127.0.0.1');
    $pg_port = trim($_POST['pg_port'] ?? '5432');
    $pg_db   = trim($_POST['pg_db']   ?? 'aseman_library');
    $pg_user = trim($_POST['pg_user'] ?? 'postgres');
    $pg_pass = $_POST['pg_pass'] ?? '';
    $admin_u = trim($_POST['admin_u'] ?? 'admin');
    $admin_p = $_POST['admin_p'] ?? '';

    try {
        // ۱. بررسی اتصال به سرور PostgreSQL و ساخت دیتابیس در صورت عدم وجود
        $dsn_test = "pgsql:host=$pg_host;port=$pg_port;dbname=$pg_db;options='--client_encoding=UTF8'";
        try {
            $pdo = new PDO($dsn_test, $pg_user, $pg_pass, array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
        } catch (PDOException $ex_db) {
            // تلاش برای اتصال به دیتابیس پیش‌فرض postgres جهت ایجاد دیتابیس جدید
            $dsn_root = "pgsql:host=$pg_host;port=$pg_port;dbname=postgres;options='--client_encoding=UTF8'";
            $pdo_root = new PDO($dsn_root, $pg_user, $pg_pass, array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
            $clean_db = preg_replace('/[^a-zA-Z0-9_]/', '', $pg_db);
            $pdo_root->exec("CREATE DATABASE \"$clean_db\" WITH ENCODING 'UTF8'");
            $pdo = new PDO($dsn_test, $pg_user, $pg_pass, array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
        }

        // ۲. ذخیره تنظیمات اتصال در فایل محیطی
        $ini_content = "; Aseman Library Enterprise Environment Configuration\n"
                     . "PG_HOST = \"$pg_host\"\n"
                     . "PG_PORT = \"$pg_port\"\n"
                     . "PG_DB   = \"$pg_db\"\n"
                     . "PG_USER = \"$pg_user\"\n"
                     . "PG_PASS = \"$pg_pass\"\n";
        $ext_ini_path = dirname(__DIR__) . '/.aseman_env.ini';
        @file_put_contents($ext_ini_path, $ini_content);

        // همچنین ذخیره در config/.env.php برای سرورهایی که دسترسی به پوشه بالاتر ندارند
        $env_php = "<?php\n"
                 . "if (!defined('ASEMAN_ROOT')) die('Access Denied');\n"
                 . "putenv('ASEMAN_PG_HOST=' . " . var_export($pg_host, true) . ");\n"
                 . "putenv('ASEMAN_PG_PORT=' . " . var_export($pg_port, true) . ");\n"
                 . "putenv('ASEMAN_PG_DB='   . " . var_export($pg_db, true) . ");\n"
                 . "putenv('ASEMAN_PG_USER=' . " . var_export($pg_user, true) . ");\n"
                 . "putenv('ASEMAN_PG_PASS=' . " . var_export($pg_pass, true) . ");\n";
        @file_put_contents(ASEMAN_ROOT . '/config/.env.php', $env_php);

        // ۳. بارگذاری جداول و ایندکس‌های نسخه Enterprise
        require_once ASEMAN_ROOT . '/config/constants.php';
        require_once ASEMAN_ROOT . '/config/database.php';

        if ($admin_u !== '' && $admin_p !== '') {
            $hash = password_hash($admin_p, PASSWORD_DEFAULT);
            $st = $db->prepare("INSERT INTO users(u,pw,perms,uloc) VALUES(?,?,'all','all') ON CONFLICT (u) DO UPDATE SET pw=EXCLUDED.pw");
            $st->execute(array($admin_u, $hash));
        }

        $step_ok = true;
        $msg = 'نصب و پیکربندی پایگاه داده PostgreSQL با موفقیت انجام شد! اکنون می‌توانید وارد سامانه شوید.';
    } catch (Exception $e) {
        $err = 'خطا در اتصال یا ساخت پایگاه داده: ' . $e->getMessage();
    }
}
?>
<!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>نصب و راه‌اندازی سامانه کتابخانه‌ای آسمان (نسخه Enterprise v15)</title>
<link href="fonts/fonts.css" rel="stylesheet" type="text/css" />
<style>
body{margin:0;padding:30px 15px;font-family:"Vazirmatn",Tahoma,sans-serif;background:#f0f6ff;color:#0c3b47;direction:rtl}
.box{max-width:720px;margin:0 auto;background:#fff;border-radius:16px;padding:28px;border:1px solid #cbd5e1;border-top:4px solid #c5a059;box-shadow:0 12px 30px -10px rgba(12,59,71,.15)}
h1{font-size:20px;margin:0 0 8px;color:#0c3b47}
h2{font-size:15px;margin:20px 0 10px;padding-bottom:6px;border-bottom:2px solid #e2e8f0}
.grid{display:grid;grid-template-columns:1fr 1fr;gap:12px}
label{display:block;font-size:12.5px;font-weight:700;margin-bottom:4px}
input{width:100%;box-sizing:border-box;padding:9px 12px;border:1px solid #cbd5e1;border-radius:8px;font:inherit;font-size:13.5px}
.btn{background:linear-gradient(135deg,#0d7a8a,#0c3b47);color:#fff;border:none;padding:11px 24px;border-radius:10px;font:inherit;font-weight:700;cursor:pointer;text-decoration:none;display:inline-block}
.ok{background:#ecfdf5;border:1px solid #6ee7b7;color:#065f46;padding:12px 16px;border-radius:10px;margin-bottom:14px;font-weight:700}
.err{background:#fff1f2;border:1px solid #fecdd3;color:#be123c;padding:12px 16px;border-radius:10px;margin-bottom:14px;font-weight:700}
.chk{display:flex;justify-content:space-between;padding:7px 10px;background:#f8fafc;border-radius:8px;margin-bottom:5px;font-size:13px}
</style>
</head>
<body>
<div class="box">
    <h1>جادوگر نصب و راه‌اندازی سامانه کتابخانه‌ای آسمان (Enterprise v15)</h1>
    <p style="font-size:13px;color:#475569;margin-top:0">پیکربندی آفلاین پایگاه داده PostgreSQL، ساخت خودکار جداول و ایندکس‌های مقیاس بالا (۱ میلیون رکورد)</p>

    <?php if ($msg !== ''): ?>
        <div class="ok"><?= htmlspecialchars($msg, ENT_QUOTES, 'UTF-8') ?></div>
        <p><a class="btn" href="index.php">ورود به پرتال و پیشخوان مدیریت آسمان</a></p>
    <?php endif; ?>
    <?php if ($err !== ''): ?>
        <div class="err"><?= htmlspecialchars($err, ENT_QUOTES, 'UTF-8') ?></div>
    <?php endif; ?>

    <h2>۱. بررسی پیش‌نیازهای سرور PHP</h2>
    <?php foreach ($ext_checks as $ext_name => $is_ok): ?>
        <div class="chk">
            <span>افزونه <code><?= htmlspecialchars($ext_name) ?></code></span>
            <b style="color:<?= $is_ok ? '#059669' : '#e11d48' ?>"><?= $is_ok ? '✓ فعال و آماده' : '✕ غیرفعال (در php.ini فعال شود)' ?></b>
        </div>
    <?php endforeach; ?>

    <?php if (!$step_ok): ?>
    <form method="post">
        <input type="hidden" name="do_install" value="1">
        <h2>۲. مشخصات اتصال به پایگاه داده PostgreSQL</h2>
        <div class="grid">
            <div><label>آدرس سرور (Host)</label><input name="pg_host" dir="ltr" value="127.0.0.1" required></div>
            <div><label>پورت (Port)</label><input name="pg_port" dir="ltr" value="5432" required></div>
            <div><label>نام پایگاه داده (Database Name)</label><input name="pg_db" dir="ltr" value="aseman_library" required></div>
            <div><label>نام کاربری دیتابیس (DB User)</label><input name="pg_user" dir="ltr" value="adminaseman" required></div>
            <div style="grid-column:span 2"><label>گذرواژه دیتابیس (DB Password)</label><input type="password" name="pg_pass" dir="ltr" placeholder="رمز عبور کاربر PostgreSQL"></div>
        </div>

        <h2>۳. تنظیم حساب مدیر ارشد سامانه</h2>
        <div class="grid">
            <div><label>نام کاربری مدیر کل</label><input name="admin_u" dir="ltr" value="admin" required></div>
            <div><label>گذرواژه مدیر کل</label><input type="password" name="admin_p" dir="ltr" value="admin123" required></div>
        </div>
        <br>
        <button type="submit" class="btn">ذخیره تنظیمات، ساخت جداول و تکمیل نصب</button>
    </form>
    <?php endif; ?>
</div>
</body>
</html>
