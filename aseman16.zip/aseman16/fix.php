<?php
$file = __DIR__ . '/modules/settings.php';
if (file_exists($file)) {
    $code = file_get_contents($file);
    // حذف بک‌اسلش‌های مشکل‌ساز در دکمه حذف اسلاید (خطوط ۷۳۹ و ۷۶۹)
    $code = str_replace(
        array(
            "onclick=\"this.closest(\\\\'.v16-slide-card\\\\').remove()\"",
            "onclick=\"this.closest(\\'.v16-slide-card\\').remove()\"",
            "onclick=\"this.closest('.v16-slide-card').remove()\""
        ),
        'onclick="this.parentNode.parentNode.remove()"',
        $code
    );
    file_put_contents($file, $code);
    echo '<div dir="rtl" style="font-family:Tahoma;padding:20px;color:#065f46;background:#ecfdf5;border:2px solid #10b981;border-radius:10px;">
        ✓ خطای سینتکس خط ۷۶۹ در فایل <b>modules/settings.php</b> با موفقیت برطرف شد. اکنون منوهای مدیریت پرتال و سیستم مانیتورینگ فعال هستند.
    </div>';
}