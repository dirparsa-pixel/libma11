<?php
/**
 * اصلاح خطای تایپ‌کست TIMESTAMP در نمودار پرتال PostgreSQL
 */
define('ASEMAN_ROOT', __DIR__);
header('Content-Type: text/html; charset=utf-8');

$file = ASEMAN_ROOT . '/templates/portal_boxes.php';
if (!file_exists($file)) {
    die('فایل templates/portal_boxes.php یافت نشد.');
}

$code = file_get_contents($file);

// ۱. اصلاح کوئری تاریخ ثبت برای سازگاری کامل با نوع TIMESTAMP در PostgreSQL
$oldQuery = "SELECT substr(created,1,7) AS ym, COUNT(*) AS c FROM records WHERE created IS NOT NULL AND created<>'' GROUP BY ym ORDER BY ym DESC";
$newQuery = "SELECT substr(created::text,1,7) AS ym, COUNT(*) AS c FROM records WHERE created IS NOT NULL GROUP BY ym ORDER BY ym DESC";

$code = str_replace($oldQuery, $newQuery, $code);

// ۲. محافظت از کوئری بازدیدهای پرتال در صورتی که جدول visits خالی یا متفاوت باشد
$code = str_replace(
    "SELECT day, COUNT(*) AS c FROM visits WHERE kind='portal' GROUP BY day ORDER BY day DESC",
    "SELECT day::text AS day, COUNT(*) AS c FROM visits WHERE kind='portal' GROUP BY day ORDER BY day DESC",
    $code
);

file_put_contents($file, $code);

echo '<div dir="rtl" style="font-family:Tahoma,sans-serif;max-width:620px;margin:40px auto;padding:22px;background:#ecfdf5;color:#065f46;border:2px solid #10b981;border-radius:12px;line-height:1.9">
    <h3 style="margin-top:0">✓ خطای PostgreSQL در نمودار صفحه اصلی برطرف شد!</h3>
    <p>تبدیل نوع <code>created::text</code> در فایل <code>templates/portal_boxes.php</code> اعمال گردید و صفحه اصلی پرتال اکنون با استایل کامل و نمودارهای زنده بارگذاری می‌شود.</p>
    <p style="margin-bottom:0"><a href="index.php?p=home" style="background:#0d7a8a;color:#fff;padding:9px 20px;border-radius:8px;text-decoration:none;font-weight:bold;display:inline-block">مشاهده صفحه اصلی پرتال</a></p>
</div>';