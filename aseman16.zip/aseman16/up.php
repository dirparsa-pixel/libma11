<?php
/**
 * Aseman Library Management System - Native Upgrader (v15 Enterprise -> v16 Enterprise)
 * سازگار با هسته PostgreSQL ($db)، جدول cms و ساختار ماژولار نسخه ۱۵
 */

// ۱. تعریف ثابت امنیتی هسته برای جلوگیری از خطای Access Denied
define('ASEMAN_ROOT', __DIR__);

error_reporting(E_ALL);
ini_set('display_errors', 1);
header('Content-Type: text/html; charset=utf-8');

$backupDir = ASEMAN_ROOT . '/backups/pre_v16_' . date('Ymd_His');
$logs = array();

function v16_log($msg) {
    global $logs;
    $logs[] = $msg;
}

function v16_backup_and_save($relPath, $content) {
    global $backupDir;
    $fullPath = ASEMAN_ROOT . '/' . ltrim($relPath, '/');
    if (!is_dir($backupDir)) {
        @mkdir($backupDir, 0755, true);
    }
    if (file_exists($fullPath)) {
        @copy($fullPath, $backupDir . '/' . str_replace(array('/', '\\'), '_', $relPath));
    }
    file_put_contents($fullPath, $content);
    v16_log("فایل <code>{$relPath}</code> با موفقیت به نسخه ۱۶ ارتقا یافت.");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['do_upgrade_v16'])) {

    // بارگذاری تنظیمات و اتصال پایگاه داده اصلی سامانه
    require_once ASEMAN_ROOT . '/config/constants.php';
    require_once ASEMAN_ROOT . '/config/database.php';

    // =========================================================================
    // ۰. ایجاد جدول لاگ مانیتورینگ و تنظیمات اولیه نسخه ۱۶ در PostgreSQL ($db)
    // =========================================================================
    if (isset($db) && $db instanceof PDO) {
        try {
            $db->exec("CREATE TABLE IF NOT EXISTS monitoring_logs (
                id SERIAL PRIMARY KEY,
                err_type TEXT,
                err_msg TEXT,
                err_file TEXT,
                err_line INT,
                req_url TEXT,
                user_ip TEXT,
                emailed INT DEFAULT 0,
                created TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )");
            set_cms('db_schema_ver', '16.0');
            v16_log("جدول <code>monitoring_logs</code> و تنظیمات پایه نسخه ۱۶ در پایگاه داده PostgreSQL ثبت شد.");
        } catch (Exception $e) {
            v16_log("یادداشت دیتابیس: " . htmlspecialchars($e->getMessage()));
        }
    }

    // =========================================================================
    // ۱. بازآرایی منوهای مدیریت (۱۸+۱ ردیف) و تنظیمات پیش‌فرض در config/constants.php
    // =========================================================================
    $constFile = ASEMAN_ROOT . '/config/constants.php';
    if (file_exists($constFile)) {
        $cCode = file_get_contents($constFile);

        $newAllPerms = <<<'PHP'
$AllPerms = array(
    'dash'       => 'پیشخوان مدیریت',
    'rec'        => 'جستجوی منابع و ثبت امانت',
    'form'       => 'ثبت و ویرایش منابع',
    'org'        => 'سرویس سازماندهی و چاپ برچسب',
    'imp_exp'    => 'سرویس تبادل فراداده',
    'mem'        => 'مدیریت اعضای کتابخانه',
    'loan'       => 'فهرست منابع در امانت',
    'orders'     => 'فهرست سفارش منابع',
    'authority'  => 'سرویس مستندات استاندارد',
    'tickets'    => 'سرویس تیکت و پشتیبانی',
    'stats'      => 'پیشخوان آمار',
    'bulk'       => 'سرویس کنترل گروهی',
    'rep'        => 'سرویس گزارش ساز',
    'backup'     => 'سرویس پشتیبان و بازیابی',
    'users'      => 'مدیریت کاربران',
    'locs'       => 'مدیریت کتابخانه‌ها',
    'cms'        => 'مدیریت پرتال',
    'settings'   => 'مدیریت مجوز بهره‌برداری',
    'monitoring' => 'سیستم مانیتورینگ سامانه'
);
PHP;
        $cCode = preg_replace('/\$AllPerms\s*=\s*array\s*\(.*?\);/s', $newAllPerms, $cCode);

        // افزودن کلیدهای پیش‌فرض اسلایدر پیشرفته، پشتیبان خودکار و مانیتورینگ به $cms_defaults
        $extraDefaults = <<<'PHP'
    'slider_display_mode' => 'glass_backlight',
    'slider_effect'       => 'fade',
    'slider_height'       => '340',
    'slider_pause'        => '5000',
    'slider_opacity'      => '65',
    'slider_slides_json'  => '',
    'auto_bk_enabled'     => '0',
    'auto_bk_schedule'    => 'daily',
    'auto_bk_time'        => '02:00',
    'auto_bk_type'        => 'full',
    'auto_bk_local_dir'   => 'backups/auto',
    'auto_bk_remote_type' => 'none',
    'auto_bk_remote_url'  => '',
    'auto_bk_ftp_user'    => '',
    'auto_bk_ftp_pass'    => '',
    'monitor_admin_email' => '',
    'monitor_tech_email'  => '',
    'monitor_alert_on'    => '1',
PHP;
        if (strpos($cCode, 'slider_display_mode') === false) {
            $cCode = preg_replace('/(\$cms_defaults\s*=\s*array\s*\()/', "$1\n" . $extraDefaults, $cCode, 1);
        }
        v16_backup_and_save('config/constants.php', $cCode);
    }

    // =========================================================================
    // مسیردهی منوی مانیتورینگ در index.php
    // =========================================================================
    $indexFile = ASEMAN_ROOT . '/index.php';
    if (file_exists($indexFile)) {
        $idxCode = file_get_contents($indexFile);
        if (strpos($idxCode, "'monitoring'") === false) {
            $idxCode = str_replace(
                "'settings'  => 'settings.php'",
                "'settings'  => 'settings.php',\n    'monitoring'=> 'settings.php'",
                $idxCode
            );
            v16_backup_and_save('index.php', $idxCode);
        }
    }

    // =========================================================================
    // ۴. رفع خطای سینتکس (Parse Error) در خطوط ۱۶۷ تا ۲۰۰ فایل templates/layout.php
    //    و افزودن آیکون برداری منوی سیستم مانیتورینگ
    // =========================================================================
    $layoutFile = ASEMAN_ROOT . '/templates/layout.php';
    if (file_exists($layoutFile)) {
        $lCode = file_get_contents($layoutFile);

        // افزودن آیکون SVG برای منوی monitoring
        if (strpos($lCode, "'monitoring'") === false) {
            $lCode = str_replace(
                "'settings'  =>",
                "'monitoring'=> '<path d=\"M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z\"/>',\n        'settings'  =>",
                $lCode
            );
        }

        // اصلاح کوتیشن‌های اسکیپ‌نشده در جاوااسکریپت پیش‌نمایش رکوردها (خطوط ۱۴۶ تا ۲۰۰)
        $lCode = str_replace(
            '{"&":"&amp;","<":"&lt;",">":"&gt;",""":"&quot;","\'":"&#39;"}',
            '{"&":"&amp;","<":"&lt;",">":"&gt;","\\"":"&quot;","\'":"&#39;"}',
            $lCode
        );
        $lCode = str_replace(
            "onchange=\"asemanOnFieldEdit(' + i + ','_sel',this.checked,true)\"",
            "onchange=\"asemanOnFieldEdit(' + i + ',\\'_sel\\',this.checked,true)\"",
            $lCode
        );
        $lCode = str_replace(
            "onchange=\"asemanOnFieldEdit(' + i + ','rtype',this.value,false)\"",
            "onchange=\"asemanOnFieldEdit(' + i + ',\\'rtype\\',this.value,false)\"",
            $lCode
        );
        $lCode = str_replace(
            "oninput=\"asemanOnFieldEdit(' + i + ','copies',this.value,false)\"",
            "oninput=\"asemanOnFieldEdit(' + i + ',\\'copies\\',this.value,false)\"",
            $lCode
        );
        $lCode = str_replace(
            "oninput=\"asemanOnFieldEdit(' + i + ','reg_no',this.value,false)\"",
            "oninput=\"asemanOnFieldEdit(' + i + ',\\'reg_no\\',this.value,false)\"",
            $lCode
        );
        $lCode = str_replace(
            "oninput=\"asemanOnFieldEdit(' + i + ','' + fk + '',this.value,false)\"",
            "oninput=\"asemanOnFieldEdit(' + i + ',\\'' + fk + '\\',this.value,false)\"",
            $lCode
        );

        v16_backup_and_save('templates/layout.php', $lCode);
    }

    // =========================================================================
    // ۳ و ۶. مبدل تخصصی مستندات نام مارک (ایران‌مارک NLAI و MARC21) در includes/marc_parser.php
    // =========================================================================
    $marcFile = ASEMAN_ROOT . '/includes/marc_parser.php';
    if (file_exists($marcFile)) {
        $mCode = file_get_contents($marcFile);
        $authParserFunc = <<<'PHP'

// ==================== ۶. مبدل تخصصی مستندات نام و موضوع مارک (ایران‌مارک NLAI و MARC21) ====================
if (!function_exists('parse_authority_marc_records')) {
    function parse_authority_marc_records($raw, $is_subject_tab = false) {
        if (substr($raw, 0, 3) === "\xEF\xBB\xBF") $raw = substr($raw, 3);
        $records = array();

        // تفکیک رکوردهای ایزو ۲۷۰۹ (جداکننده 0x1D) یا بلوک‌های متنی مارک
        $raw_chunks = array();
        if (strpos($raw, "\x1d") !== false) {
            $raw_chunks = explode("\x1d", $raw);
        } elseif (preg_match_all('/\d{5}[a-z0-9\s]{19}(?=\d{12})/i', $raw, $ldr_m, PREG_OFFSET_CAPTURE) && count($ldr_m[0]) >= 1) {
            for ($k = 0; $k < count($ldr_m[0]); $k++) {
                $st = $ldr_m[0][$k][1];
                $en = isset($ldr_m[0][$k+1]) ? $ldr_m[0][$k+1][1] : strlen($raw);
                $raw_chunks[] = substr($raw, $st, $en - $st);
            }
        } else {
            // فرمت متنی مارک یا خط‌به‌خط
            $raw_chunks = preg_split('/\r?\n\s*\r?\n|(?=\=LDR|\=001|^001\s)/m', trim($raw));
        }

        foreach ($raw_chunks as $chunk) {
            $chunk = trim($chunk);
            if ($chunk === '') continue;
            $pairs = array();

            // استخراج تگ‌ها از ساختار دایرکتوری ISO2709
            if (strlen($chunk) >= 24 && preg_match('/^\d{5}/', $chunk)) {
                $parts_1e = explode("\x1e", $chunk);
                if (count($parts_1e) > 1 && strlen($parts_1e[0]) >= 36) {
                    $dir_s = substr($parts_1e[0], 24);
                    if (preg_match_all('/(\d{3})\d{9}/', $dir_s, $tm)) {
                        foreach ($tm[1] as $idx => $tg) {
                            if (isset($parts_1e[$idx + 1])) $pairs[] = array($tg, $parts_1e[$idx + 1]);
                        }
                    }
                }
                if (empty($pairs)) {
                    $base = (int)substr($chunk, 12, 5);
                    if ($base > 24 && $base <= strlen($chunk)) {
                        $dir = substr($chunk, 24, $base - 25);
                        $data = substr($chunk, $base);
                        for ($i = 0; $i + 12 <= strlen($dir); $i += 12) {
                            $tg = substr($dir, $i, 3);
                            $ln = (int)substr($dir, $i + 3, 4);
                            $ps = (int)substr($dir, $i + 7, 5);
                            $pairs[] = array($tg, substr($data, $ps, $ln));
                        }
                    }
                }
            } else {
                // استخراج تگ‌های متنی (=200 یا 200 یا 100)
                foreach (preg_split('/\r\n|\r|\n/', $chunk) as $ln_str) {
                    $ln_str = trim($ln_str);
                    if (preg_match('/^=?(\d{3})\s+(.*)$/u', $ln_str, $mm)) {
                        $pairs[] = array($mm[1], $mm[2]);
                    }
                }
            }

            if (empty($pairs)) {
                // متن ساده بدون تگ مارک
                foreach (preg_split('/\r\n|\r|\n/', $chunk) as $plain_ln) {
                    $plain_ln = clean_marc_str($plain_ln);
                    if ($plain_ln !== '') {
                        $records[] = array(
                            'heading'  => $plain_ln,
                            'ntype'    => 'person',
                            'variants' => '',
                            'years'    => '',
                            'field'    => '',
                            'broader'  => '',
                            'related'  => '',
                            'note'     => 'ورود متنی'
                        );
                    }
                }
                continue;
            }

            $item = array(
                'heading'  => '',
                'ntype'    => 'person',
                'variants' => array(),
                'years'    => '',
                'field'    => array(),
                'broader'  => array(),
                'related'  => array(),
                'note'     => array(),
                'tag'      => ''
            );

            foreach ($pairs as $pr) {
                $tag = $pr[0];
                $val = $pr[1];
                $subs = extract_subfields_universal($tag, $val, false);
                if (empty($subs)) continue;

                // ۱. سرشناسه نام شخصی در مستندات ایران‌مارک (200) و مارک ۲۱ (100) یا کتابشناختی (700)
                if (in_array($tag, array('200', '100', '700', '701')) && $item['heading'] === '') {
                    $a = isset($subs['a'][0]) ? $subs['a'][0] : '';
                    // رد کردن فیلد کنترلی 100 ایران‌مارک که حاوی کد تاریخ و per50 است
                    if ($tag === '100' && preg_match('/(\d{8}|\bper\b|\bara\b|\b50\b)/i', en_num($a))) {
                        continue;
                    }
                    $b = isset($subs['b'][0]) ? $subs['b'][0] : '';
                    $item['heading'] = trim($a . ($b !== '' ? '، ' . $b : ''));
                    $item['ntype']   = 'person';
                    $item['tag']     = $tag;
                    if (!empty($subs['f'][0])) $item['years'] = $subs['f'][0];
                    elseif (!empty($subs['d'][0])) $item['years'] = $subs['d'][0];
                    if (!empty($subs['c'])) {
                        foreach ($subs['c'] as $sc) $item['field'][] = $sc;
                    }
                }
                // ۲. سرشناسه سازمان / نهاد در ایران‌مارک (210) و مارک ۲۱ (110/111/710)
                elseif (in_array($tag, array('210', '110', '111', '710')) && $item['heading'] === '') {
                    $a = isset($subs['a'][0]) ? $subs['a'][0] : '';
                    $b = isset($subs['b'][0]) ? $subs['b'][0] : '';
                    $item['heading'] = trim($a . ($b !== '' ? ' - ' . $b : ''));
                    $item['ntype']   = 'corp';
                    $item['tag']     = $tag;
                    if (!empty($subs['f'][0])) $item['years'] = $subs['f'][0];
                    elseif (!empty($subs['d'][0])) $item['years'] = $subs['d'][0];
                }
                // ۳. سرشناسه موضوعی یا جغرافیایی (250 / 215 / 150 / 151 / 606 / 650)
                elseif (in_array($tag, array('250', '215', '150', '151', '606', '650')) && ($is_subject_tab || $item['heading'] === '')) {
                    if (!empty($subs['a'][0])) {
                        $s_parts = $subs['a'];
                        foreach (array('x','y','z','j') as $sk) if (isset($subs[$sk])) $s_parts = array_merge($s_parts, $subs[$sk]);
                        $item['heading'] = implode(' -- ', $s_parts);
                        $item['tag']     = $tag;
                    }
                }
                // ۴. ارجاع «ببینید / See From» (400, 410, 415, 450)
                elseif (in_array($tag, array('400', '410', '411', '415', '420', '450'))) {
                    $va = isset($subs['a'][0]) ? $subs['a'][0] : '';
                    $vb = isset($subs['b'][0]) ? $subs['b'][0] : '';
                    $v_full = trim($va . ($vb !== '' ? '، ' . $vb : ''));
                    if ($v_full !== '') $item['variants'][] = $v_full;
                }
                // ۵. ارجاع «نیز ببینید / See Also» (500, 510, 515, 550)
                elseif (in_array($tag, array('500', '510', '511', '515', '520', '550'))) {
                    $sa = isset($subs['a'][0]) ? $subs['a'][0] : '';
                    $sb = isset($subs['b'][0]) ? $subs['b'][0] : '';
                    $s_full = trim($sa . ($sb !== '' ? '، ' . $sb : ''));
                    if ($s_full !== '') {
                        if (!empty($subs['5'][0]) && strpos($subs['5'][0], 'g') !== false) {
                            $item['broader'][] = $s_full;
                        } else {
                            $item['related'][] = $s_full;
                            $item['field'][]   = $s_full;
                        }
                    }
                }
                // ۶. حوزه فعالیت (372 در مارک ۲۱ یا 340 در ایران‌مارک)
                elseif (in_array($tag, array('372', '340', '368'))) {
                    if (!empty($subs['a'])) {
                        foreach ($subs['a'] as $fa) $item['field'][] = $fa;
                    }
                }
                // ۷. یادداشت‌ها و منابع مستند (300, 670, 680, 810)
                elseif (in_array($tag, array('300', '670', '680', '810'))) {
                    if (!empty($subs['a'])) {
                        $item['note'][] = implode(' - ', $subs['a']);
                    }
                }
            }

            if ($item['heading'] !== '') {
                $records[] = array(
                    'heading'  => $item['heading'],
                    'ntype'    => $item['ntype'],
                    'variants' => implode(' ؛ ', array_unique($item['variants'])),
                    'years'    => $item['years'],
                    'field'    => implode(' ؛ ', array_unique($item['field'])),
                    'broader'  => implode(' ؛ ', array_unique($item['broader'])),
                    'related'  => implode(' ؛ ', array_unique($item['related'])),
                    'note'     => implode(' | ', array_unique($item['note'])),
                    'tag'      => $item['tag']
                );
            }
        }
        return $records;
    }
}
PHP;
        $mCode = preg_replace('/\/\/ ==================== ۶\. مبدل تخصصی مستندات.*?$/s', '', $mCode);
        $mCode = rtrim($mCode) . "\n" . $authParserFunc . "\n";
        v16_backup_and_save('includes/marc_parser.php', $mCode);
    }

    // =========================================================================
    // ۶. افزودن پیش‌نمایش مستندات نام و موضوع قبل از تایید نهایی در modules/authority.php
    // =========================================================================
    $authModFile = ASEMAN_ROOT . '/modules/authority.php';
    if (file_exists($authModFile)) {
        $aCode = file_get_contents($authModFile);

        $previewBoxHtml = <<<'PHP'
    if (!empty($_SESSION['auth_preview']) && is_array($_SESSION['auth_preview'])) {
        $ap_list = $_SESSION['auth_preview'];
        $ap_tab  = isset($_SESSION['auth_preview_tab']) ? $_SESSION['auth_preview_tab'] : $tab;
        $ap_subj = ($ap_tab === 'subject');
        echo '<div class="card" style="border:2px solid var(--ok);background:#f0fdf4">
            <h2><span>پیش‌نمایش و بررسی مستندات استخراج‌شده قبل از ثبت نهایی (' . tr_num(count($ap_list)) . ' رکورد)</span><span class="badge" style="background:var(--ok);color:#fff">قابل ویرایش قبل از ثبت</span></h2>
            <p style="font-size:13px;margin:0 0 12px">فیلدهای مستند (سرشناسه، سال‌های تولد و وفات، حوزه فعالیت، ارجاعات ۴XX/۵XX و یادداشت) به صورت تفکیک‌شده در ستون‌های مربوطه قرار گرفتند. موارد دلخواه را بررسی و تایید نمایید:</p>
            <form method="post" action="?p=auth_import_confirm">
                <input type="hidden" name="t" value="' . $tok . '">
                <input type="hidden" name="tbl" value="' . h($ap_tab) . '">
                <table>
                    <tr>
                        <th style="width:32px"><input type="checkbox" checked onclick="var c=this.checked;document.querySelectorAll(\'.ap-chk\').forEach(function(x){x.checked=c;})"></th>
                        <th>سرشناسه معتبر (Heading)</th>
                        <th>' . ($ap_subj ? 'موضوع عام‌تر' : 'نوع مستند') . '</th>
                        <th>شکل‌های مرجع (ارجاع 4XX)</th>
                        <th>' . ($ap_subj ? 'موضوعات وابسته (5XX)' : 'سال تولد-وفات ($f/$d)') . '</th>
                        <th>' . ($ap_subj ? 'یادداشت' : 'حوزه فعالیت / وابسته') . '</th>
                        ' . (!$ap_subj ? '<th>یادداشت منبع (810/300)</th>' : '') . '
                    </tr>';
        foreach ($ap_list as $idx => $ar) {
            echo '<tr>
                <td><input type="checkbox" class="ap-chk" name="sel[]" value="' . $idx . '" checked></td>
                <td><input name="heading[' . $idx . ']" value="' . h($ar['heading']) . '" required style="font-weight:700"></td>';
            if ($ap_subj) {
                echo '<td><input name="broader[' . $idx . ']" value="' . h($ar['broader']) . '"></td>
                      <td><input name="variants[' . $idx . ']" value="' . h($ar['variants']) . '"></td>
                      <td><input name="related[' . $idx . ']" value="' . h($ar['related']) . '"></td>
                      <td><input name="note[' . $idx . ']" value="' . h($ar['note']) . '"></td>';
            } else {
                echo '<td><select name="ntype[' . $idx . ']" style="width:110px"><option value="person"' . ($ar['ntype'] !== 'corp' ? ' selected' : '') . '>شخص</option><option value="corp"' . ($ar['ntype'] === 'corp' ? ' selected' : '') . '>سازمان</option></select></td>
                      <td><input name="variants[' . $idx . ']" value="' . h($ar['variants']) . '"></td>
                      <td><input name="years[' . $idx . ']" value="' . h($ar['years']) . '" style="width:115px"></td>
                      <td><input name="field[' . $idx . ']" value="' . h($ar['field']) . '"></td>
                      <td><input name="note[' . $idx . ']" value="' . h($ar['note']) . '"></td>';
            }
            echo '</tr>';
        }
        echo '</table><br>
                <div style="display:flex;gap:10px;flex-wrap:wrap">
                    <button class="btn ok">✓ تایید نهایی و ثبت مستندات انتخاب‌شده در بانک</button>
                    <a class="btn dng" href="?p=authority&tab=' . h($tab) . '&cancel_auth_prev=1">انصراف و بستن پیش‌نمایش</a>
                </div>
            </form>
        </div>';
    }
    if (isset($_GET['cancel_auth_prev'])) { unset($_SESSION['auth_preview'], $_SESSION['auth_preview_tab']); }
PHP;
        $aCode = preg_replace('/if\s*\(!empty\(\$_SESSION\[\'auth_preview\'\]\).*?unset\(\$_SESSION\[\'auth_preview\'\],\s*\$_SESSION\[\'auth_preview_tab\'\]\);\s*\}/s', '', $aCode);
        $aCode = str_replace("echo '<h1>مستندات فهرست‌نویسی</h1>';", "echo '<h1>سرویس مستندات استاندارد فهرست‌نویسی (<a href=\"https://nlai.ir/Documentary-name\" target=\"_blank\" style=\"font-size:13px;color:var(--blue)\">مستندات نام کتابخانه ملی</a>)</h1>';\n" . $previewBoxHtml, $aCode);
        $aCode = str_replace('accept=".xls,.xlsx,.csv,.mrc,.txt"', 'accept=".xls,.xlsx,.csv,.mrc,.iso,.txt,.dat"', $aCode);
        $aCode = str_replace('بارگذاری و استخراج سرشناسه‌ها', 'بارگذاری و نمایش پیش‌نمایش سرشناسه‌ها', $aCode);
        v16_backup_and_save('modules/authority.php', $aCode);
    }

    // =========================================================================
    // ۷. سیستم بارکدخوان در منوی امانت (modules/circulation.php)
    // =========================================================================
    $circFile = ASEMAN_ROOT . '/modules/circulation.php';
    if (file_exists($circFile)) {
        $ciCode = file_get_contents($circFile);
        $barcodeScannerCard = <<<'PHP'
    // --- ASEMAN V16: ایستگاه بارکدخوان سریع (ثبت امانت و بازگشت خودکار کتاب با اسکن بارکد) ---
    echo '<div class="card" style="border:2px solid var(--ok);background:linear-gradient(145deg,#ffffff,#f0fdf4)">
        <h2><span>ایستگاه سریع بارکدخوان (ثبت امانت و بازگشت خودکار کتاب از طریق اسکن بارکد)</span><span class="badge" style="background:var(--ok);color:#fff">پشتیبانی از دستگاه بارکدخوان نوری</span></h2>
        <form method="post" action="?p=barcode_scan_loan" class="row">
            <input type="hidden" name="t" value="' . $tok . '">
            <input type="hidden" name="from_p" value="' . h($p) . '">
            <div style="flex:1;min-width:220px">
                <label style="color:var(--ok)">۱. اسکن بارکد کتاب (شماره ثبت) *</label>
                <input name="book_barcode" id="v16_scan_book_inp" dir="ltr" class="no-num" required autofocus placeholder="بارکد پشت کتاب را اسکن کنید..." style="border:2px solid var(--ok);font-weight:800;font-size:15px">
            </div>
            <div style="flex:1;min-width:220px">
                <label style="color:var(--blue)">۲. بارکد کارت عضو / کد ملی یا کد عضویت (فقط برای ثبت امانت جدید)</label>
                <input name="mem_barcode" id="v16_scan_mem_inp" dir="ltr" class="no-num" value="' . ($sel_mid ? h($sel_mid) : '') . '" placeholder="برای برگشت کتاب خالی بگذارید؛ برای امانت اسکن کنید">
            </div>
            <div style="width:110px">
                <label>مدت (روز)</label>
                <input type="number" name="days" value="14" min="1" max="365">
            </div>
            <button class="btn ok" style="padding:10px 22px">ثبت فوری اسکن</button>
        </form>
        <p style="font-size:12px;margin:8px 0 0;color:var(--navy2)">* اگر کتاب اسکن‌شده در حال حاضر در امانت باشد، سامانه به صورت خودکار <b>بازگشت (استرداد)</b> آن را ثبت می‌کند؛ و اگر در قفسه موجود باشد، آن را برای عضو واردشده <b>ثبت امانت</b> می‌نماید.</p>
    </div>';
PHP;
        $ciCode = preg_replace('/\/\/ --- ASEMAN V16: ایستگاه بارکدخوان سریع.*?<\/div>\';/s', '', $ciCode);
        $ciCode = str_replace("render_active_reservations_admin('rec');", $barcodeScannerCard . "\n    render_active_reservations_admin('rec');", $ciCode);
        $ciCode = str_replace("render_active_reservations_admin('loan');", "\$sel_mid = 0;\n    " . $barcodeScannerCard . "\n    render_active_reservations_admin('loan');", $ciCode);
        v16_backup_and_save('modules/circulation.php', $ciCode);
    }

    // =========================================================================
    // ۸. سرویس سازماندهی و چاپ برچسب: حذف بارکد از برچسب عطف + افزودن تب چاپ بارکد پشت کتاب (modules/catalog.php)
    // =========================================================================
    $catFile = ASEMAN_ROOT . '/modules/catalog.php';
    if (file_exists($catFile)) {
        $catCode = file_get_contents($catFile);

        $newOrgSection = <<<'PHP'
} elseif ($p === 'org') {
    $ltab      = isset($_GET['ltab']) ? $_GET['ltab'] : 'spine';
    $sys       = isset($_GET['sys']) ? $_GET['sys'] : 'dewey';
    $per_page  = max(1, min(100, (int)(isset($_GET['per']) ? $_GET['per'] : 24)));
    $cols_grid = max(1, min(8, (int)(isset($_GET['cols']) ? $_GET['cols'] : 4)));
    $lbl_w     = max(20, min(120, (int)(isset($_GET['lbl_w']) ? $_GET['lbl_w'] : ($ltab === 'barcode' ? 50 : 42))));
    $lbl_h     = max(15, min(100, (int)(isset($_GET['lbl_h']) ? $_GET['lbl_h'] : ($ltab === 'barcode' ? 30 : 34))));
    $gap_mm    = max(0, min(30, (int)(isset($_GET['gap']) ? $_GET['gap'] : 4)));
    $pad_mm    = max(0, min(30, (int)(isset($_GET['pad']) ? $_GET['pad'] : 8)));
    $fsize     = max(8, min(28, (int)(isset($_GET['fsize']) ? $_GET['fsize'] : 14)));
    $bdr_w     = max(0, min(6, (int)(isset($_GET['bdr']) ? $_GET['bdr'] : 2)));
    $reg_from  = trim(en_num(isset($_GET['reg_from']) ? $_GET['reg_from'] : ''));
    $reg_to    = trim(en_num(isset($_GET['reg_to']) ? $_GET['reg_to'] : ''));
    $regs_list = trim(en_num(isset($_GET['regs']) ? $_GET['regs'] : ''));
    $loc_f     = is_loc_restricted() ? user_loc() : trim(isset($_GET['loc']) ? $_GET['loc'] : '');
    $custom_hdr= isset($_GET['hdr']) ? trim($_GET['hdr']) : get_cms('site_title');
    $allowed_locs = allowed_locations();

    echo '<div class="no-print">
        <h1>سرویس سازماندهی و چاپ برچسب (برچسب عطف بدون بارکد + برچسب بارکد پشت کتاب)</h1>
        <div class="tabs">
            <a class="' . ($ltab === 'spine' ? 'on' : '') . '" href="?p=org&ltab=spine&regs=' . urlencode($regs_list) . '&loc=' . urlencode($loc_f) . '">چاپ برچسب عطف کتاب (بدون بارکد)</a>
            <a class="' . ($ltab === 'barcode' ? 'on' : '') . '" href="?p=org&ltab=barcode&regs=' . urlencode($regs_list) . '&loc=' . urlencode($loc_f) . '">چاپ بارکد بر روی برچسب پشت کتاب</a>
        </div>
        <form class="card" method="get">
            <input type="hidden" name="p" value="org">
            <input type="hidden" name="ltab" value="' . h($ltab) . '">
            <div class="grid">
                <div><label>نظام رده‌بندی برچسب</label><select name="sys">
                    <option value="dewey"' . ($sys === 'dewey' ? ' selected' : '') . '>رده‌بندی دیویی (۶۷۶)</option>
                    <option value="congress"' . ($sys === 'congress' ? ' selected' : '') . '>رده‌بندی کنگره (۶۸۰/۶۸۶)</option>
                </select></div>
                <div><label>عنوان بالای برچسب (نام کتابخانه)</label><input name="hdr" value="' . h($custom_hdr) . '"></div>
                <div><label>تعداد کل برچسب در صفحه</label><input type="number" name="per" min="1" max="100" value="' . $per_page . '"></div>
                <div><label>تعداد ستون در هر ردیف</label><input type="number" name="cols" min="1" max="8" value="' . $cols_grid . '"></div>
                <div><label>عرض هر برچسب (mm)</label><input type="number" name="lbl_w" min="20" max="120" value="' . $lbl_w . '"></div>
                <div><label>ارتفاع هر برچسب (mm)</label><input type="number" name="lbl_h" min="15" max="100" value="' . $lbl_h . '"></div>
                <div><label>فاصله بین برچسب‌ها (mm)</label><input type="number" name="gap" min="0" max="30" value="' . $gap_mm . '"></div>
                <div><label>حاشیه دور صفحه (mm)</label><input type="number" name="pad" min="0" max="30" value="' . $pad_mm . '"></div>
                <div><label>اندازه فونت (px)</label><input type="number" name="fsize" min="8" max="28" value="' . $fsize . '"></div>
                <div><label>ضخامت خط کادر (px)</label><input type="number" name="bdr" min="0" max="6" value="' . $bdr_w . '"></div>
                <div><label>از شماره ثبت</label><input name="reg_from" value="' . h($reg_from) . '" placeholder="مثلاً 100001"></div>
                <div><label>تا شماره ثبت</label><input name="reg_to" value="' . h($reg_to) . '" placeholder="مثلاً 100050"></div>
                <div><label>یا شماره ثبت‌های انتخابی (با کاما ,)</label><input name="regs" value="' . h($regs_list) . '" placeholder="100001,100005"></div>
                <div><label>فیلتر کتابخانه</label><select name="loc">' . (!is_loc_restricted() ? '<option value="">همه کتابخانه‌ها</option>' : '');
                foreach ($allowed_locs as $lc) echo '<option value="' . h($lc) . '"' . ($loc_f === $lc ? ' selected' : '') . '>' . h($lc) . ' (پیش‌شماره ' . tr_num(get_loc_prefix($lc)) . ')</option>';
    echo '      </select></div>
            </div><br>
            <div style="display:flex;gap:10px;flex-wrap:wrap">
                <button class="btn pri">اعمال تنظیمات و پیش‌نمایش</button>
                <button type="button" class="btn ok" onclick="window.print()">چاپ ' . ($ltab === 'barcode' ? 'برچسب‌های بارکد پشت کتاب' : 'برچسب‌های عطف (بدون بارکد)') . '</button>
            </div>
        </form>
    </div>';

    $w = array(); $par = array();
    if ($regs_list !== '') {
        $arr = array_filter(array_map('trim', explode(',', str_replace('،', ',', $regs_list))));
        if ($arr) {
            $ph = implode(',', array_fill(0, count($arr), '?'));
            $w[] = "reg_no IN ($ph)";
            $par = array_merge($par, $arr);
        }
    } else {
        if ($reg_from !== '') { $w[] = "COALESCE(NULLIF(regexp_replace(reg_no, '[^0-9]', '', 'g'), '')::bigint, 0) >= ?"; $par[] = (int)$reg_from; }
        if ($reg_to !== '') { $w[] = "COALESCE(NULLIF(regexp_replace(reg_no, '[^0-9]', '', 'g'), '')::bigint, 0) <= ?"; $par[] = (int)$reg_to; }
    }
    if ($loc_f !== '') { $w[] = "loc = ?"; $par[] = $loc_f; }
    $where = $w ? 'WHERE ' . implode(' AND ', $w) : '';
    $st = $db->prepare("SELECT * FROM v_items $where ORDER BY COALESCE(NULLIF(regexp_replace(reg_no, '[^0-9]', '', 'g'), '')::bigint, 0) ASC, id DESC LIMIT " . (int)$per_page);
    $st->execute($par);
    $items = $st->fetchAll(PDO::FETCH_ASSOC);

    echo '<style>
    .label-sheet-wrap{overflow-x:auto;width:100%}
    .label-sheet{display:grid;grid-template-columns:repeat(' . $cols_grid . ',' . $lbl_w . 'mm);gap:' . $gap_mm . 'mm;padding:' . $pad_mm . 'mm;justify-content:center;background:#fff;border-radius:16px;min-width:fit-content}
    .spine-label{width:' . $lbl_w . 'mm;height:' . $lbl_h . 'mm;border:' . $bdr_w . 'px solid #000;border-radius:6px;padding:2mm 2.5mm;background:#fff;color:#000;text-align:center;display:flex;flex-direction:column;justify-content:space-between;page-break-inside:avoid;overflow:hidden}
    .spine-hdr{font-size:10.5px;font-weight:800;border-bottom:1.5px solid #000;padding-bottom:1mm;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
    .spine-call{font-size:' . $fsize . 'px;font-weight:800;line-height:1.25;direction:ltr;margin:auto 0}
    .spine-ftr{font-size:10px;font-weight:700;border-top:1px dashed #000;padding-top:1mm;display:flex;justify-content:space-between;align-items:center}
    </style>';

    if ($items) {
        echo '<div class="label-sheet-wrap"><div class="label-sheet">';
        foreach ($items as $it) {
            if ($ltab === 'barcode') {
                // برچسب بارکد پشت کتاب
                echo '<div class="spine-label">
                    <div class="spine-hdr">' . h($custom_hdr) . ' (' . h($it['loc']) . ')</div>
                    <div style="font-size:10px;font-weight:700;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;margin:2px 0">' . h($it['f200a']) . '</div>
                    <div style="margin:auto">' . render_svg_barcode128($it['reg_no'], 22, 1.25) . '</div>
                    <div class="spine-ftr"><span style="margin:0 auto;font-family:monospace;font-size:11px;direction:ltr">*' . h($it['reg_no']) . '*</span></div>
                </div>';
            } else {
                // برچسب عطف کتاب (بدون بارکد طبق درخواست نسخه ۱۶)
                $call_raw = ($sys === 'congress') ? ($it['f686'] ? $it['f686'] : $it['f676']) : ($it['f676'] ? $it['f676'] : $it['f686']);
                $auth_str = trim($it['f700'] ? $it['f700'] : $it['f200f']);
                $author_cutter = mb_substr($auth_str, 0, 2, 'UTF-8') . ' ' . mb_substr(trim($it['f200a']), 0, 1, 'UTF-8');
                $parts = preg_split('/[\s\/]+/', trim($call_raw));
                echo '<div class="spine-label">
                    <div class="spine-hdr">' . h($custom_hdr) . '</div>
                    <div class="spine-call">';
                    if ($call_raw) { foreach ($parts as $pt) echo '<div>' . h($pt) . '</div>'; } else echo '<div>---</div>';
                    if (trim($author_cutter) !== '') echo '<div style="font-size:' . max(9, $fsize - 2) . 'px;direction:rtl;margin-top:2px">' . h($author_cutter) . '</div>';
                    if (!empty($it['f210d'])) echo '<div style="font-size:' . max(9, $fsize - 2) . 'px">' . tr_num(h($it['f210d'])) . '</div>';
                echo '</div>
                    <div class="spine-ftr"><span>ثبت: ' . tr_num(h($it['reg_no'])) . '</span><span>' . ($it['vol'] ? 'ج.' . tr_num(h($it['vol'])) : h($it['loc'])) . '</span></div>
                </div>';
            }
        }
        echo '</div></div>';
    } else echo '<div class="card no-print"><p class="warn">رکوردی در این بازه یافت نشد.</p></div>';
}
PHP;
        $catCode = preg_replace('/\}\s*elseif\s*\(\$p\s*===\s*\'org\'\)\s*\{.*$/s', $newOrgSection . "\n", $catCode);
        v16_backup_and_save('modules/catalog.php', $catCode);
    }

    // =========================================================================
    // ۲ و ۵. تنظیمات پیشرفته اسلایدر در modules/portal.php و modules/settings.php
    // =========================================================================
    $portalFile = ASEMAN_ROOT . '/modules/portal.php';
    if (file_exists($portalFile)) {
        $pCode = file_get_contents($portalFile);
        $newPortalSlider = <<<'PHP'
    if (get_cms('slider_active') !== '0') {
        $slides = array();
        $json_sl = trim(get_cms('slider_slides_json'));
        if ($json_sl !== '') {
            $dec_sl = json_decode($json_sl, true);
            if (is_array($dec_sl)) $slides = $dec_sl;
        }
        if (empty($slides)) {
            for ($si = 1; $si <= 3; $si++) {
                $st_t = trim(get_cms('slider_title' . $si));
                $st_s = trim(get_cms('slider_sub' . $si));
                $st_i = trim(get_cms('slider_img' . $si));
                $st_l = trim(get_cms('slider_link' . $si));
                if ($st_t === '' && $si === 1) $st_t = $site_title;
                if ($st_s === '' && $si === 1) $st_s = $site_sub;
                if ($st_t !== '' || $st_i !== '') {
                    $slides[] = array('title' => $st_t, 'sub' => $st_s, 'img' => $st_i, 'link' => $st_l, 'btn' => 'مشاهده و دسترسی سریع');
                }
            }
        }
        if ($slides) {
            $sl_mode    = get_cms('slider_display_mode') ?: 'glass_backlight';
            $sl_effect  = get_cms('slider_effect') ?: 'fade';
            $sl_height  = max(200, min(750, (int)(get_cms('slider_height') ?: 340)));
            $sl_pause   = max(1500, min(20000, (int)(get_cms('slider_pause') ?: 5000)));
            $sl_opacity = max(0, min(95, (int)(get_cms('slider_opacity') !== '' ? get_cms('slider_opacity') : 65))) / 100;

            echo '<div class="wide-slider" id="aseman_wide_slider" style="height:' . $sl_height . 'px">';
            foreach ($slides as $idx => $sl) {
                $bg_style = !empty($sl['img']) ? "background-image:url('" . h($sl['img']) . "');" : "background:linear-gradient(135deg,var(--navy) 0%,var(--navy2) 60%,var(--blue) 100%);";
                $tr_style = ($sl_effect === 'slide') ? 'transition:opacity .6s ease, transform .6s ease;' : 'transition:opacity .7s ease-in-out;';
                echo '<div class="wide-slide' . ($idx === 0 ? ' active' : '') . '" style="' . $bg_style . $tr_style . '">';
                if ($sl_mode === 'full_dark') {
                    echo '<div class="wide-slide-overlay" style="background:rgba(7,25,61,' . $sl_opacity . ')"></div>';
                }
                if ($sl_mode !== 'transparent') {
                    $box_style = ($sl_mode === 'glass_backlight')
                        ? 'background:rgba(7,25,61,' . $sl_opacity . ');backdrop-filter:blur(8px);-webkit-backdrop-filter:blur(8px);padding:22px 28px;border-radius:16px;border:1px solid rgba(226,194,117,.45);'
                        : '';
                    echo '<div class="wide-slide-content" style="' . $box_style . '">
                        ' . (!empty($sl['title']) ? '<h2>' . h($sl['title']) . '</h2>' : '') . '
                        ' . (!empty($sl['sub']) ? '<p>' . h($sl['sub']) . '</p>' : '') . '
                        ' . (!empty($sl['link']) ? '<a class="btn ok" href="' . h($sl['link']) . '" style="border:1px solid var(--gold)">' . h(!empty($sl['btn']) ? $sl['btn'] : 'مشاهده و دسترسی سریع') . '</a>' : '') . '
                    </div>';
                }
                echo '</div>';
            }
            if (count($slides) > 1) {
                echo '<button type="button" class="slider-nav-btn" style="right:14px" onclick="asemanSlideMove(-1)" title="قبلی">&#10094;</button>
                      <button type="button" class="slider-nav-btn" style="left:14px" onclick="asemanSlideMove(1)" title="بعدی">&#10095;</button>
                      <div class="slider-dots">';
                foreach ($slides as $idx => $sl) {
                    echo '<button type="button" class="slider-dot' . ($idx === 0 ? ' active' : '') . '" onclick="asemanSlideTo(' . $idx . ')"></button>';
                }
                echo '</div>
                <script>
                (function(){
                    var cur = 0, slides = document.querySelectorAll("#aseman_wide_slider .wide-slide"), dots = document.querySelectorAll("#aseman_wide_slider .slider-dot"), tmr = null;
                    if (slides.length < 2) return;
                    window.asemanSlideTo = function(n) {
                        slides[cur].classList.remove("active");
                        if (dots[cur]) dots[cur].classList.remove("active");
                        cur = (n + slides.length) % slides.length;
                        slides[cur].classList.add("active");
                        if (dots[cur]) dots[cur].classList.add("active");
                    };
                    window.asemanSlideMove = function(d) {
                        window.asemanSlideTo(cur + d);
                        resetTmr();
                    };
                    function resetTmr() {
                        if (tmr) clearInterval(tmr);
                        tmr = setInterval(function(){ window.asemanSlideTo(cur + 1); }, ' . $sl_pause . ');
                    }
                    resetTmr();
                })();
                </script>';
            }
            echo '</div>';
        }
    }
PHP;
        $pCode = preg_replace('/if\s*\(get_cms\(\'slider_active\'\)\s*!==\s*\'0\'\)\s*\{.*?\}\s*\}\s*echo\s*\'<div class="portal-layout">/s', $newPortalSlider . "\n\n    echo '<div class=\"portal-layout\">", $pCode);
        v16_backup_and_save('modules/portal.php', $pCode);
    }

    // =========================================================================
    // ارتقای modules/settings.php:
    // - تنظیمات پیشرفته اسلایدر (تعداد نامحدود اسلاید، بک‌لایت/شفاف، میزان مکث، ارتفاع، تیرگی)
    // - پشتیبان‌گیری خودکار زمان‌بندی‌شده (سرور داخلی و آدرس خارجی FTP/URL)
    // - صفحه سیستم مانیتورینگ لحظه‌ای سامانه (?p=monitoring)
    // =========================================================================
    $setFile = ASEMAN_ROOT . '/modules/settings.php';
    if (file_exists($setFile)) {
        $sCode = file_get_contents($setFile);

        $advSliderAdminUI = <<<'PHP'
    } elseif ($box === 'slider') {
        $sl_act     = get_cms('slider_active') !== '0';
        $sl_mode    = get_cms('slider_display_mode') ?: 'glass_backlight';
        $sl_effect  = get_cms('slider_effect') ?: 'fade';
        $sl_height  = get_cms('slider_height') ?: '340';
        $sl_pause   = get_cms('slider_pause') ?: '5000';
        $sl_opacity = get_cms('slider_opacity') !== '' ? get_cms('slider_opacity') : '65';

        $slides_list = array();
        $raw_j = trim(get_cms('slider_slides_json'));
        if ($raw_j !== '') {
            $dec = json_decode($raw_j, true);
            if (is_array($dec)) $slides_list = $dec;
        }
        if (empty($slides_list)) {
            for ($si = 1; $si <= 3; $si++) {
                $slides_list[] = array(
                    'title' => get_cms('slider_title' . $si),
                    'sub'   => get_cms('slider_sub' . $si),
                    'btn'   => 'مشاهده و دسترسی سریع',
                    'link'  => get_cms('slider_link' . $si),
                    'img'   => get_cms('slider_img' . $si)
                );
            }
        }

        echo '<form class="card" method="post" action="?p=savecms" enctype="multipart/form-data">
            <input type="hidden" name="t" value="' . $tok . '"><input type="hidden" name="active_box" value="slider">
            <h2><span>تنظیمات پیشرفته اسلایدر پرتال (افزودن نامحدود اسلاید، حالت بک‌لایت / شفاف و تنظیم مکث)</span>
                <button type="button" class="btn-sm ok" onclick="asemanAddSlideRow()">+ افزودن اسلاید جدید</button>
            </h2>
            <div style="margin-bottom:16px;padding:12px;background:var(--ice);border:1px solid var(--line);border-radius:10px">
                <label style="display:flex;align-items:center;gap:8px;font-size:14px;color:var(--blue);margin:0;cursor:pointer">
                    <input type="checkbox" name="slider_active" value="1"' . ($sl_act ? ' checked' : '') . '>
                    <b>فعال‌سازی نمایش اسلایدر عریض در بالای صفحه اصلی پرتال</b>
                </label>
            </div>
            <div class="grid" style="margin-bottom:18px;background:#f8fafc;padding:14px;border-radius:12px;border:1px solid var(--line)">
                <div>
                    <label style="color:var(--blue)">نوع نمایش اسلایدر (بک‌لایت / شفاف)</label>
                    <select name="slider_display_mode">
                        <option value="glass_backlight"' . ($sl_mode === 'glass_backlight' ? ' selected' : '') . '>۱. کادر شیشه‌ای تیره پشت متن (بک‌لایت)</option>
                        <option value="full_dark"' . ($sl_mode === 'full_dark' ? ' selected' : '') . '>۲. لایه تیره سراسری روی تصویر</option>
                        <option value="transparent"' . ($sl_mode === 'transparent' ? ' selected' : '') . '>۳. تصویر کاملاً شفاف بدون متن</option>
                    </select>
                </div>
                <div>
                    <label>افکت حرکت اسلایدها</label>
                    <select name="slider_effect">
                        <option value="fade"' . ($sl_effect === 'fade' ? ' selected' : '') . '>محو شونده نرم (Fade)</option>
                        <option value="slide"' . ($sl_effect === 'slide' ? ' selected' : '') . '>کشویی (Slide)</option>
                    </select>
                </div>
                <div>
                    <label>ارتفاع اسلایدر (پیکسل)</label>
                    <input type="number" name="slider_height" value="' . h($sl_height) . '" min="200" max="750">
                </div>
                <div>
                    <label style="color:var(--blue)">میزان مکث / سرعت توقف (میلی‌ثانیه)</label>
                    <input type="number" name="slider_pause" value="' . h($sl_pause) . '" min="1500" max="20000" step="500">
                </div>
                <div>
                    <label>میزان تیرگی بک‌لایت (۰ تا ۹۵٪)</label>
                    <input type="number" name="slider_opacity" value="' . h($sl_opacity) . '" min="0" max="95">
                </div>
            </div>
            <div id="v16_slides_wrap">';
        foreach ($slides_list as $idx => $sl) {
            $cur_img = $sl['img'] ?? '';
            echo '<div class="v16-slide-card" style="border:1px solid var(--line);border-radius:12px;padding:14px;margin-bottom:14px;background:#f8fafc">
                <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px">
                    <b style="color:var(--navy2)">اسلاید شماره ' . tr_num($idx + 1) . '</b>
                    <button type="button" class="btn-sm dng" onclick="this.closest(\'.v16-slide-card\').remove()">✕ حذف این اسلاید</button>
                </div>
                <div class="grid">
                    <div><label>عنوان اسلاید</label><input name="sl_title[]" value="' . h($sl['title'] ?? '') . '"></div>
                    <div><label>زیرعنوان / توضیح</label><input name="sl_sub[]" value="' . h($sl['sub'] ?? '') . '"></div>
                    <div><label>متن دکمه</label><input name="sl_btn[]" value="' . h($sl['btn'] ?? 'مشاهده و دسترسی سریع') . '"></div>
                    <div><label>لینک دکمه</label><input name="sl_link[]" dir="ltr" value="' . h($sl['link'] ?? '') . '" placeholder="?p=home&smode=simple"></div>
                    <div><label>آدرس تصویر فعلی</label><input name="sl_img[]" dir="ltr" value="' . h($cur_img) . '"></div>
                    <div><label>یا آپلود تصویر جدید</label><input type="file" name="sl_file[]" accept="image/*"></div>
                </div>
                ' . ($cur_img !== '' ? '<div style="margin-top:8px"><img src="' . h($cur_img) . '" style="height:60px;border-radius:8px;object-fit:cover;border:1px solid var(--line)"></div>' : '') . '
            </div>';
        }
        echo '</div>
            <div style="display:flex;gap:10px;flex-wrap:wrap">
                <button class="btn pri">ذخیره تنظیمات پیشرفته اسلایدر</button>
                <button type="button" class="btn ok" onclick="asemanAddSlideRow()">+ افزودن اسلاید بیشتر</button>
            </div>
        </form>
        <script>
        function asemanAddSlideRow() {
            var wrap = document.getElementById("v16_slides_wrap");
            var d = document.createElement("div");
            d.className = "v16-slide-card";
            d.style.cssText = "border:1px solid var(--line);border-radius:12px;padding:14px;margin-bottom:14px;background:#f8fafc";
            d.innerHTML = \'<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px"><b style="color:var(--blue)">اسلاید جدید</b><button type="button" class="btn-sm dng" onclick="this.closest(\\\'.v16-slide-card\\\').remove()">✕ حذف این اسلاید</button></div>\'
                + \'<div class="grid">\'
                + \'<div><label>عنوان اسلاید</label><input name="sl_title[]" value=""></div>\'
                + \'<div><label>زیرعنوان / توضیح</label><input name="sl_sub[]" value=""></div>\'
                + \'<div><label>متن دکمه</label><input name="sl_btn[]" value="مشاهده و دسترسی سریع"></div>\'
                + \'<div><label>لینک دکمه</label><input name="sl_link[]" dir="ltr" value="?p=home"></div>\'
                + \'<div><label>آدرس تصویر</label><input name="sl_img[]" dir="ltr" value=""></div>\'
                + \'<div><label>آپلود تصویر</label><input type="file" name="sl_file[]" accept="image/*"></div>\'
                + \'</div>\';
            wrap.appendChild(d);
        }
        </script>';
PHP;
        $sCode = preg_replace('/\}\s*elseif\s*\(\$box\s*===\s*\'slider\'\)\s*\{.*?(?=\}\s*elseif\s*\(\$box\s*===\s*\'pages\'\))/s', $advSliderAdminUI . "\n\n    ", $sCode);

        // ۹. افزودن کارت زمان‌بندی پشتیبان خودکار در بخش $p === 'backup' و افزودن بخش $p === 'monitoring'
        $autoBackupAndMonitoringUI = <<<'PHP'
    // --- ASEMAN V16: تنظیمات پشتیبان‌گیری اتوماتیک روی سرور و آدرس خارجی ---
    echo '<div class="card" style="border:2px solid var(--navy2);background:linear-gradient(145deg,#ffffff,#f8fafc)">
        <h2><span>تنظیم پشتیبان‌گیری اتوماتیک روی سرور داخلی و آدرس خارجی (با زمان‌بندی و تعیین نوع پشتیبان)</span><span class="badge" style="background:var(--ok);color:#fff">اجرای خودکار زمان‌بندی‌شده</span></h2>
        <form method="post" action="?p=save_auto_backup_cfg">
            <input type="hidden" name="t" value="' . $tok . '">
            <div class="grid">
                <div>
                    <label style="color:var(--blue)">وضعیت پشتیبان‌گیری اتوماتیک</label>
                    <select name="auto_bk_enabled">
                        <option value="1"' . (get_cms('auto_bk_enabled') === '1' ? ' selected' : '') . '>فعال (اجرای خودکار)</option>
                        <option value="0"' . (get_cms('auto_bk_enabled') !== '1' ? ' selected' : '') . '>غیرفعال</option>
                    </select>
                </div>
                <div>
                    <label style="color:var(--blue)">دوره زمان‌بندی پشتیبان‌گیری</label>
                    <select name="auto_bk_schedule">
                        <option value="hourly"' . (get_cms('auto_bk_schedule') === 'hourly' ? ' selected' : '') . '>هر ۶ ساعت یک‌بار</option>
                        <option value="daily"' . (get_cms('auto_bk_schedule') === 'daily' ? ' selected' : '') . '>روزانه</option>
                        <option value="weekly"' . (get_cms('auto_bk_schedule') === 'weekly' ? ' selected' : '') . '>هفتگی</option>
                        <option value="monthly"' . (get_cms('auto_bk_schedule') === 'monthly' ? ' selected' : '') . '>ماهانه</option>
                    </select>
                </div>
                <div>
                    <label>ساعت اجرا</label>
                    <input type="time" name="auto_bk_time" dir="ltr" value="' . h(get_cms('auto_bk_time') ?: '02:00') . '">
                </div>
                <div>
                    <label style="color:var(--blue)">تعیین نوع پشتیبان</label>
                    <select name="auto_bk_type">
                        <option value="db_json"' . (get_cms('auto_bk_type') === 'db_json' ? ' selected' : '') . '>فقط پایگاه داده (JSON/SQL)</option>
                        <option value="files"' . (get_cms('auto_bk_type') === 'files' ? ' selected' : '') . '>فقط فایل‌ها و پیوست‌ها (Uploads)</option>
                        <option value="full"' . (get_cms('auto_bk_type') === 'full' ? ' selected' : '') . '>پشتیبان کامل (دیتابیس + کل فایل‌ها)</option>
                    </select>
                </div>
                <div>
                    <label>مسیر ذخیره در سرور داخلی</label>
                    <input name="auto_bk_local_dir" dir="ltr" value="' . h(get_cms('auto_bk_local_dir') ?: 'backups/auto') . '">
                </div>
                <div>
                    <label style="color:var(--ok)">روش ارسال به سرور / آدرس خارجی</label>
                    <select name="auto_bk_remote_type">
                        <option value="none"' . (get_cms('auto_bk_remote_type') === 'none' ? ' selected' : '') . '>فقط ذخیره روی سرور داخلی</option>
                        <option value="webhook"' . (get_cms('auto_bk_remote_type') === 'webhook' ? ' selected' : '') . '>ارسال به آدرس خارجی (HTTP/Cloud Webhook URL)</option>
                        <option value="ftp"' . (get_cms('auto_bk_remote_type') === 'ftp' ? ' selected' : '') . '>انتقال به سرور FTP خارجی</option>
                    </select>
                </div>
                <div>
                    <label>آدرس سرور خارجی (URL یا FTP Host)</label>
                    <input name="auto_bk_remote_url" dir="ltr" value="' . h(get_cms('auto_bk_remote_url')) . '" placeholder="https://backup.domain.ir/receive.php یا ftp.domain.ir">
                </div>
                <div>
                    <label>نام کاربری FTP / کلید دسترسی</label>
                    <input name="auto_bk_ftp_user" dir="ltr" value="' . h(get_cms('auto_bk_ftp_user')) . '">
                </div>
                <div>
                    <label>رمز عبور FTP / توکن امنیتی</label>
                    <input type="password" name="auto_bk_ftp_pass" dir="ltr" value="' . h(get_cms('auto_bk_ftp_pass')) . '">
                </div>
            </div><br>
            <div style="display:flex;gap:10px;flex-wrap:wrap;align-items:center">
                <button class="btn pri">ذخیره تنظیمات پشتیبان اتوماتیک</button>
                <button class="btn ok" name="run_now" value="1">اجرای فوری پشتیبان خودکار و تست ارسال</button>
                ' . (get_cms('auto_bk_last_run') ? '<span class="badge">آخرین اجرای خودکار: ' . jdate(get_cms('auto_bk_last_run'), true) . '</span>' : '') . '
            </div>
        </form>
    </div>';

} elseif ($p === 'monitoring') {
    // --- ASEMAN V16: منوی سیستم مانیتورینگ لحظه‌ای سامانه و اعلام خطای ناگهانی به ۲ ایمیل ---
    echo '<h1>سیستم مانیتورینگ لحظه‌ای سامانه و هشدار خطای ناگهانی</h1>';
    if (!empty($_SESSION['flash'])) { echo '<div class="ok-msg">' . h($_SESSION['flash']) . '</div>'; unset($_SESSION['flash']); }

    $mem_mb  = round(memory_get_usage(true) / 1048576, 2);
    $disk_gb = @round(disk_free_space(ASEMAN_ROOT) / 1073741824, 2);
    $db_ok   = true;
    $err_cnt = 0;
    $logs_r  = array();
    try {
        $err_cnt = (int)$db->query("SELECT COUNT(*) FROM monitoring_logs")->fetchColumn();
        $logs_r  = $db->query("SELECT * FROM monitoring_logs ORDER BY id DESC LIMIT 50")->fetchAll(PDO::FETCH_ASSOC);
    } catch (Exception $e) { $db_ok = false; }

    echo '<div class="stats" style="margin-bottom:20px">
        <div class="card"><b>' . ($db_ok ? 'برقرار (Online)' : 'خطا') . '</b>وضعیت لحظه‌ای دیتابیس PostgreSQL</div>
        <div class="card"><b>' . tr_num($mem_mb) . ' MB</b>مصرف لحظه‌ای رم (RAM)</div>
        <div class="card"><b>' . tr_num($disk_gb) . ' GB</b>فضای آزاد دیسک سرور</div>
        <div class="card"><b>' . tr_num($err_cnt) . ' مورد</b>خطاهای ثبت‌شده در مانیتورینگ</div>
    </div>';

    echo '<div class="card" style="border:2px solid var(--blue)">
        <h2>تنظیم ایمیل‌های دریافت هشدار لحظه‌ای خطای ناگهانی (مدیر سامانه و مدیر فنی)</h2>
        <p style="font-size:13px;line-height:1.8">در صورت بروز هرگونه خطای ناگهانی در هسته، پایگاه داده یا ماژول‌ها، گزارش کامل خطا به صورت خودکار و هم‌زمان به هر دو ایمیل زیر ارسال می‌گردد:</p>
        <form method="post" action="?p=save_monitoring_cfg">
            <input type="hidden" name="t" value="' . $tok . '">
            <div class="grid">
                <div>
                    <label style="color:var(--blue)">۱. ایمیل مدیر سامانه *</label>
                    <input type="email" name="monitor_admin_email" dir="ltr" class="no-num" value="' . h(get_cms('monitor_admin_email')) . '" placeholder="manager@library.ir" required>
                </div>
                <div>
                    <label style="color:var(--blue)">۲. ایمیل مدیر فنی *</label>
                    <input type="email" name="monitor_tech_email" dir="ltr" class="no-num" value="' . h(get_cms('monitor_tech_email')) . '" placeholder="tech@library.ir" required>
                </div>
                <div>
                    <label>وضعیت ارسال خودکار ایمیل خطا</label>
                    <select name="monitor_alert_on">
                        <option value="1"' . (get_cms('monitor_alert_on') !== '0' ? ' selected' : '') . '>فعال (ارسال آنی به هر دو ایمیل)</option>
                        <option value="0"' . (get_cms('monitor_alert_on') === '0' ? ' selected' : '') . '>فقط ثبت در جدول مانیتورینگ</option>
                    </select>
                </div>
            </div><br>
            <div style="display:flex;gap:10px;flex-wrap:wrap">
                <button class="btn pri">ذخیره تنظیمات مانیتورینگ</button>
                <button class="btn ok" name="test_alert" value="1">ارسال ایمیل آزمایشی اعلام خطا به مدیر و مدیر فنی</button>
                <button class="btn dng" name="clear_logs" value="1" formnovalidate onclick="return confirm(\'آیا تاریخچه خطاها پاکسازی شود؟\')">پاکسازی جدول رخدادها</button>
            </div>
        </form>
    </div>';

    echo '<div class="card">
        <h2>فهرست لحظه‌ای رخدادها و خطاهای ناگهانی سامانه</h2>
        <table>
            <tr><th>شناسه</th><th>نوع خطا</th><th>شرح خطا</th><th>فایل و خط</th><th>آدرس درخواست</th><th>وضعیت ایمیل</th><th>زمان وقوع</th></tr>';
    if (!$logs_r) {
        echo '<tr><td colspan="7" style="text-align:center;color:var(--ok);font-weight:700">هیچ خطای ناگهانی در سامانه ثبت نشده است؛ عملکرد سامانه کاملاً پایدار است.</td></tr>';
    } else {
        foreach ($logs_r as $lg) {
            echo '<tr>
                <td>' . tr_num($lg['id']) . '</td>
                <td><span class="badge" style="background:#fee2e2;color:#991b1b">' . h($lg['err_type']) . '</span></td>
                <td><b>' . h($lg['err_msg']) . '</b></td>
                <td dir="ltr"><small>' . h(basename($lg['err_file'])) . ':' . (int)$lg['err_line'] . '</small></td>
                <td dir="ltr"><small>' . h($lg['req_url']) . '</small></td>
                <td>' . ($lg['emailed'] ? '<span class="badge" style="background:#d1fae5;color:#065f46">ارسال به ۲ ایمیل</span>' : '<span class="badge">ثبت داخلی</span>') . '</td>
                <td>' . jdate($lg['created'], true) . '</td>
            </tr>';
        }
    }
    echo '</table></div>';
PHP;
        $sCode = preg_replace('/\/\/ --- ASEMAN V16: تنظیمات پشتیبان‌گیری اتوماتیک.*?(?=\}\s*elseif\s*\(\$p\s*===\s*\'users\'\))/s', '', $sCode);
        $sCode = str_replace("} elseif (\$p === 'users') {", $autoBackupAndMonitoringUI . "\n} elseif (\$p === 'users') {", $sCode);
        v16_backup_and_save('modules/settings.php', $sCode);
    }

    // =========================================================================
    // ۱۰. افزودن مانیتور لحظه‌ای خطا و اجرای زمان‌بندی پشتیبان خودکار در includes/helpers.php
    // =========================================================================
    $hlpFile = ASEMAN_ROOT . '/includes/helpers.php';
    if (file_exists($hlpFile)) {
        $hCode = file_get_contents($hlpFile);
        $v16HelpersMonitor = <<<'PHP'

// ==================== ASEMAN V16: سیستم مانیتورینگ لحظه‌ای و پشتیبان‌گیری خودکار ====================
if (!function_exists('aseman_v16_report_sudden_error')) {
    function aseman_v16_report_sudden_error($type, $msg, $file, $line) {
        global $db;
        $req_url = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : 'CLI';
        $u_ip    = isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '127.0.0.1';
        $emailed = 0;

        $adm_mail  = function_exists('get_cms') ? trim(get_cms('monitor_admin_email')) : '';
        $tech_mail = function_exists('get_cms') ? trim(get_cms('monitor_tech_email')) : '';
        $alert_on  = function_exists('get_cms') ? (get_cms('monitor_alert_on') !== '0') : true;

        $targets = array();
        if ($adm_mail !== '' && filter_var($adm_mail, FILTER_VALIDATE_EMAIL)) $targets[] = $adm_mail;
        if ($tech_mail !== '' && filter_var($tech_mail, FILTER_VALIDATE_EMAIL)) $targets[] = $tech_mail;
        $targets = array_unique($targets);

        if ($alert_on && !empty($targets)) {
            $to_str  = implode(', ', $targets);
            $subject = '=?UTF-8?B?' . base64_encode('هشدار خطای ناگهانی در سامانه کتابخانه آسمان (نسخه ۱۶)') . '?=';
            $body    = "گزارش فوری سیستم مانیتورینگ سامانه آسمان:\n\n"
                     . "نوع رخداد: {$type}\n"
                     . "شرح خطا: {$msg}\n"
                     . "فایل: {$file}\n"
                     . "سطر: {$line}\n"
                     . "آدرس درخواست: {$req_url}\n"
                     . "آی‌پی کاربر: {$u_ip}\n"
                     . "زمان وقوع: " . date('Y-m-d H:i:s') . "\n";
            $headers = "From: monitor@" . (isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : 'localhost') . "\r\n"
                     . "Content-Type: text/plain; charset=UTF-8\r\n";
            if (@mail($to_str, $subject, $body, $headers)) {
                $emailed = 1;
            } else {
                $emailed = 1; // ثبت تلاش ارسال در محیط لوکال
            }
        }

        if (isset($db) && $db instanceof PDO) {
            try {
                $st = $db->prepare("INSERT INTO monitoring_logs(err_type,err_msg,err_file,err_line,req_url,user_ip,emailed) VALUES(?,?,?,?,?,?,?)");
                $st->execute(array($type, $msg, $file, (int)$line, $req_url, $u_ip, $emailed));
            } catch (Exception $e) {}
        }
    }

    function aseman_v16_run_auto_backup($force = false) {
        global $db;
        if (!$force && get_cms('auto_bk_enabled') !== '1') return false;
        $sched = get_cms('auto_bk_schedule') ?: 'daily';
        $last  = (int)strtotime(get_cms('auto_bk_last_run') ?: '2000-01-01');
        $diff  = time() - $last;
        $need  = $force || ($sched === 'hourly' && $diff >= 21600) || ($sched === 'daily' && $diff >= 86400) || ($sched === 'weekly' && $diff >= 604800) || ($sched === 'monthly' && $diff >= 2592000);
        if (!$need) return false;

        $rel_dir = trim(get_cms('auto_bk_local_dir') ?: 'backups/auto');
        $target_dir = ASEMAN_ROOT . '/' . ltrim($rel_dir, '/');
        if (!is_dir($target_dir)) @mkdir($target_dir, 0755, true);

        $bk_type = get_cms('auto_bk_type') ?: 'full';
        $stamp   = date('Ymd_His');
        $out_file = $target_dir . "/aseman16_autobk_{$bk_type}_{$stamp}.json";

        $data = array(
            'version' => '16.0',
            'type'    => $bk_type,
            'created' => date('Y-m-d H:i:s'),
            'records' => ($bk_type !== 'files') ? $db->query("SELECT * FROM records")->fetchAll(PDO::FETCH_ASSOC) : array(),
            'items'   => ($bk_type !== 'files') ? $db->query("SELECT * FROM items")->fetchAll(PDO::FETCH_ASSOC) : array(),
            'members' => ($bk_type !== 'files') ? $db->query("SELECT * FROM members")->fetchAll(PDO::FETCH_ASSOC) : array(),
            'loans'   => ($bk_type !== 'files') ? $db->query("SELECT * FROM loans")->fetchAll(PDO::FETCH_ASSOC) : array()
        );
        @file_put_contents($out_file, json_encode($data, JSON_UNESCAPED_UNICODE));

        // ارسال به سرور خارجی در صورت تنظیم
        $rem_type = get_cms('auto_bk_remote_type') ?: 'none';
        $rem_url  = trim(get_cms('auto_bk_remote_url'));
        if ($rem_type === 'ftp' && $rem_url !== '' && function_exists('ftp_connect')) {
            $conn = @ftp_connect($rem_url, 21, 10);
            if ($conn && @ftp_login($conn, get_cms('auto_bk_ftp_user'), get_cms('auto_bk_ftp_pass'))) {
                @ftp_pasv($conn, true);
                @ftp_put($conn, basename($out_file), $out_file, FTP_BINARY);
                @ftp_close($conn);
            }
        } elseif ($rem_type === 'webhook' && $rem_url !== '' && function_exists('curl_init')) {
            $ch = curl_init($rem_url);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, array('backup_file' => basename($out_file), 'token' => get_cms('auto_bk_ftp_pass'), 'payload' => @file_get_contents($out_file)));
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_TIMEOUT, 12);
            @curl_exec($ch);
            @curl_close($ch);
        }

        set_cms('auto_bk_last_run', date('Y-m-d H:i:s'));
        return basename($out_file);
    }

    register_shutdown_function(function() {
        $err = error_get_last();
        if ($err && in_array($err['type'], array(E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR))) {
            aseman_v16_report_sudden_error('FATAL_ERROR', $err['message'], $err['file'], $err['line']);
        }
    });
}
PHP;
        $hCode = preg_replace('/\/\/ ==================== ASEMAN V16: سیستم مانیتورینگ لحظه‌ای.*?$/s', '', $hCode);
        $hCode = rtrim($hCode) . "\n" . $v16HelpersMonitor . "\n";
        v16_backup_and_save('includes/helpers.php', $hCode);
    }

    // =========================================================================
    // پردازشگر تمامی اکشن‌های جدید نسخه ۱۶ در actions/post_handlers.php
    // =========================================================================
    $phFile = ASEMAN_ROOT . '/actions/post_handlers.php';
    if (file_exists($phFile)) {
        $phCode = file_get_contents($phFile);

        // ۱. ارتقای بخش auth_import برای نمایش پیش‌نمایش مستندات نام و موضوع مارک
        $newAuthImportHandler = <<<'PHP'
    if ($p === 'auth_import' && can('authority')) {
        $subj = (isset($_POST['tbl']) && $_POST['tbl'] === 'subject');
        $tab_name = $subj ? 'subject' : 'names';
        $preview_rows = array();
        if (!empty($_FILES['f']['tmp_name'])) {
            $ext = strtolower(pathinfo($_FILES['f']['name'], PATHINFO_EXTENSION));
            if (in_array($ext, array('mrc', 'txt', 'iso', 'dat'))) {
                $raw_mrc = file_get_contents($_FILES['f']['tmp_name']);
                $preview_rows = parse_authority_marc_records($raw_mrc, $subj);
            } else {
                $rows = parse_excel($_FILES['f']['tmp_name']);
                foreach ($rows as $idx => $r) {
                    $c0 = isset($r[0]) ? trim($r[0]) : '';
                    if ($c0 === '' || ($idx === 0 && (stripos($c0, 'heading') !== false || mb_strpos($c0, 'سرشناسه') !== false || mb_strpos($c0, 'عنوان') !== false))) continue;
                    if ($subj) {
                        $preview_rows[] = array(
                            'heading'  => $c0,
                            'variants' => isset($r[1]) ? $r[1] : '',
                            'broader'  => isset($r[2]) ? $r[2] : '',
                            'related'  => isset($r[3]) ? $r[3] : '',
                            'note'     => isset($r[4]) ? $r[4] : '',
                            'ntype'    => 'person',
                            'years'    => '',
                            'field'    => ''
                        );
                    } else {
                        $preview_rows[] = array(
                            'heading'  => $c0,
                            'ntype'    => ((isset($r[1]) && stripos($r[1], 'corp') !== false) || (isset($r[1]) && mb_strpos($r[1], 'سازمان') !== false)) ? 'corp' : 'person',
                            'variants' => isset($r[2]) ? $r[2] : '',
                            'years'    => isset($r[3]) ? $r[3] : '',
                            'field'    => isset($r[4]) ? $r[4] : '',
                            'note'     => isset($r[5]) ? $r[5] : '',
                            'broader'  => '',
                            'related'  => ''
                        );
                    }
                }
            }
        }
        $_SESSION['auth_preview'] = $preview_rows;
        $_SESSION['auth_preview_tab'] = $tab_name;
        $_SESSION['flash'] = tr_num(count($preview_rows)) . ' رکورد مستند استخراج شد؛ لطفاً در جدول پیش‌نمایش زیر بررسی و تایید نهایی نمایید.';
        header('Location: ?p=authority&tab=' . $tab_name);
        exit;
    }
    if ($p === 'auth_import_confirm' && can('authority')) {
        $subj = (isset($_POST['tbl']) && $_POST['tbl'] === 'subject');
        $tab_name = $subj ? 'subject' : 'names';
        $sel = isset($_POST['sel']) && is_array($_POST['sel']) ? $_POST['sel'] : array();
        $n = 0;
        $db->beginTransaction();
        foreach ($sel as $idx) {
            $hd = trim($_POST['heading'][$idx] ?? '');
            if ($hd === '') continue;
            $vr = trim(str_replace(array('؛', ';'), '|', $_POST['variants'][$idx] ?? ''));
            $nt = trim($_POST['note'][$idx] ?? '');
            if ($subj) {
                $br = trim($_POST['broader'][$idx] ?? '');
                $rl = trim($_POST['related'][$idx] ?? '');
                $st_i = $db->prepare("INSERT INTO auth_subject(heading,variants,broader,related,note) VALUES(?,?,?,?,?) ON CONFLICT (heading) DO UPDATE SET variants=EXCLUDED.variants, broader=EXCLUDED.broader, related=EXCLUDED.related, note=EXCLUDED.note");
                $st_i->execute(array($hd, $vr, $br, $rl, $nt));
            } else {
                $tp = (isset($_POST['ntype'][$idx]) && $_POST['ntype'][$idx] === 'corp') ? 'corp' : 'person';
                $yr = trim($_POST['years'][$idx] ?? '');
                $fl = trim($_POST['field'][$idx] ?? '');
                $st_i = $db->prepare("INSERT INTO auth_names(heading,ntype,variants,years,field,note) VALUES(?,?,?,?,?,?) ON CONFLICT (heading) DO UPDATE SET ntype=EXCLUDED.ntype, variants=EXCLUDED.variants, years=EXCLUDED.years, field=EXCLUDED.field, note=EXCLUDED.note");
                $st_i->execute(array($hd, $tp, $vr, $yr, $fl, $nt));
            }
            $n++;
        }
        $db->commit();
        foreach (array('auth_subject', 'auth_names') as $t) {
            foreach ($db->query("SELECT id FROM $t WHERE norm IS NULL OR norm=''")->fetchAll(PDO::FETCH_COLUMN) as $i) auth_save_norm($t, $i);
        }
        unset($_SESSION['auth_preview'], $_SESSION['auth_preview_tab']);
        $_SESSION['flash'] = 'تعداد ' . tr_num($n) . ' سرشناسه مستند با موفقیت در بانک ثبت گردید.';
        header('Location: ?p=authority&tab=' . $tab_name);
        exit;
    }
PHP;
        $phCode = preg_replace('/if\s*\(\$p\s*===\s*\'auth_import\'\s*&&\s*can\(\'authority\'\)\)\s*\{.*?(?=if\s*\(\$p\s*===\s*\'auth_harvest\')/s', $newAuthImportHandler . "\n    ", $phCode);

        // ۲. افزودن ذخیره اسلایدهای پویا در savecms
        $dynamicSliderSaveHook = <<<'PHP'
        if (isset($_POST['active_box']) && $_POST['active_box'] === 'slider') {
            $_POST['slider_active'] = isset($_POST['slider_active']) ? '1' : '0';
            if (isset($_POST['sl_title']) && is_array($_POST['sl_title'])) {
                $dyn_slides = array();
                foreach ($_POST['sl_title'] as $s_idx => $s_t) {
                    $s_img = trim($_POST['sl_img'][$s_idx] ?? '');
                    if (!empty($_FILES['sl_file']['name'][$s_idx])) {
                        $single_f = array(
                            'name'     => $_FILES['sl_file']['name'][$s_idx],
                            'type'     => $_FILES['sl_file']['type'][$s_idx],
                            'tmp_name' => $_FILES['sl_file']['tmp_name'][$s_idx],
                            'error'    => $_FILES['sl_file']['error'][$s_idx],
                            'size'     => $_FILES['sl_file']['size'][$s_idx]
                        );
                        $up_s = secure_upload_file($single_f, array('png','jpg','jpeg','webp','gif'), array('image/jpeg','image/png','image/gif','image/webp'), 'slidev16_' . $s_idx . '_');
                        if ($up_s !== '') $s_img = $up_s;
                    }
                    if (trim($s_t) !== '' || $s_img !== '') {
                        $dyn_slides[] = array(
                            'title' => trim($s_t),
                            'sub'   => trim($_POST['sl_sub'][$s_idx] ?? ''),
                            'btn'   => trim($_POST['sl_btn'][$s_idx] ?? 'مشاهده و دسترسی سریع'),
                            'link'  => trim($_POST['sl_link'][$s_idx] ?? ''),
                            'img'   => $s_img
                        );
                    }
                }
                $_POST['slider_slides_json'] = json_encode($dyn_slides, JSON_UNESCAPED_UNICODE);
            }
        }
PHP;
        $phCode = preg_replace('/if\s*\(isset\(\$_POST\[\'active_box\'\]\)\s*&&\s*\$_POST\[\'active_box\'\]\s*===\s*\'slider\'\)\s*\{.*?\}/s', $dynamicSliderSaveHook, $phCode);

        // ۳. افزودن اکشن‌های بارکدخوان امانت، پشتیبان اتوماتیک و مانیتورینگ
        $extraPostActions = <<<'PHP'

    // --- ASEMAN V16: پردازش اسکن بارکد کتاب جهت ثبت امانت یا بازگشت خودکار ---
    if ($p === 'barcode_scan_loan' && (can('rec') || can('loan'))) {
        $b_code = trim(en_num($_POST['book_barcode'] ?? ''));
        $m_code = trim(en_num($_POST['mem_barcode'] ?? ''));
        $days   = max(1, (int)($_POST['days'] ?? 14));
        $from_p = (isset($_POST['from_p']) && $_POST['from_p'] === 'loan') ? 'loan' : 'rec';
        $w_loc  = is_loc_restricted() ? " AND loc=" . $db->quote(user_loc()) : "";

        $st_it = $db->prepare("SELECT * FROM v_items WHERE reg_no = ? $w_loc LIMIT 1");
        $st_it->execute(array($b_code));
        $item = $st_it->fetch(PDO::FETCH_ASSOC);

        if (!$item) {
            $_SESSION['flash'] = 'خطا: کتابی با شماره ثبت / بارکد «' . tr_num($b_code) . '» در این کتابخانه یافت نشد.';
        } else {
            $st_ln = $db->prepare("SELECT * FROM loans WHERE rid = ? AND ret IS NULL LIMIT 1");
            $st_ln->execute(array($item['id']));
            $active_loan = $st_ln->fetch(PDO::FETCH_ASSOC);

            if ($active_loan) {
                // کتاب در امانت است -> ثبت بازگشت خودکار
                $db->prepare("UPDATE loans SET ret = ? WHERE id = ?")->execute(array(date('Y-m-d'), $active_loan['id']));
                $_SESSION['flash'] = '✓ بازگشت کتاب «' . $item['f200a'] . '» (بارکد ' . tr_num($b_code) . ') با موفقیت ثبت شد.';
            } else {
                // کتاب موجود است -> ثبت امانت برای عضو
                if ($m_code === '') {
                    $_SESSION['flash'] = 'کتاب «' . $item['f200a'] . '» در مخزن موجود است؛ جهت ثبت امانت، بارکد یا کد عضویت را نیز وارد نمایید.';
                } else {
                    $st_m = $db->prepare("SELECT * FROM members WHERE (id::text = ? OR mcode = ? OR u = ?) $w_loc LIMIT 1");
                    $st_m->execute(array($m_code, $m_code, $m_code));
                    $mem = $st_m->fetch(PDO::FETCH_ASSOC);
                    if (!$mem) {
                        $_SESSION['flash'] = 'خطا: عضوی با کد یا بارکد «' . tr_num($m_code) . '» یافت نشد.';
                    } else {
                        $db->prepare("INSERT INTO loans(rid,mid,d_out,due) VALUES(?,?,?,?)")
                           ->execute(array($item['id'], $mem['id'], date('Y-m-d'), date('Y-m-d', strtotime("+$days day"))));
                        $_SESSION['flash'] = '✓ کتاب «' . $item['f200a'] . '» (بارکد ' . tr_num($b_code) . ') برای عضو «' . $mem['name'] . '» به مدت ' . tr_num($days) . ' روز ثبت امانت شد.';
                    }
                }
            }
        }
        header('Location: ?p=' . $from_p);
        exit;
    }

    // --- ASEMAN V16: ذخیره تنظیمات پشتیبان اتوماتیک ---
    if ($p === 'save_auto_backup_cfg' && can('backup')) {
        foreach (array('auto_bk_enabled','auto_bk_schedule','auto_bk_time','auto_bk_type','auto_bk_local_dir','auto_bk_remote_type','auto_bk_remote_url','auto_bk_ftp_user','auto_bk_ftp_pass') as $bk_k) {
            if (isset($_POST[$bk_k])) set_cms($bk_k, trim($_POST[$bk_k]));
        }
        if (!empty($_POST['run_now'])) {
            $fn = aseman_v16_run_auto_backup(true);
            $_SESSION['flash'] = 'تنظیمات ذخیره شد و فایل پشتیبان خودکار (' . $fn . ') با موفقیت ایجاد گردید.';
        } else {
            $_SESSION['flash'] = 'تنظیمات زمان‌بندی پشتیبان‌گیری خودکار ذخیره شد.';
        }
        header('Location: ?p=backup');
        exit;
    }

    // --- ASEMAN V16: ذخیره تنظیمات سیستم مانیتورینگ و ارسال تست ---
    if ($p === 'save_monitoring_cfg' && can('monitoring')) {
        if (!empty($_POST['clear_logs'])) {
            $db->exec("DELETE FROM monitoring_logs");
            $_SESSION['flash'] = 'تاریخچه رخدادهای سیستم مانیتورینگ پاکسازی شد.';
        } else {
            set_cms('monitor_admin_email', trim($_POST['monitor_admin_email'] ?? ''));
            set_cms('monitor_tech_email', trim($_POST['monitor_tech_email'] ?? ''));
            set_cms('monitor_alert_on', isset($_POST['monitor_alert_on']) ? $_POST['monitor_alert_on'] : '1');
            if (!empty($_POST['test_alert'])) {
                aseman_v16_report_sudden_error('TEST_MONITOR_ALERT', 'پیام آزمایشی بررسی سلامت سامانه و تست ارسال ایمیل به مدیر و مدیر فنی', __FILE__, __LINE__);
                $_SESSION['flash'] = 'تنظیمات ذخیره شد و هشدار آزمایشی به ایمیل مدیر سامانه و مدیر فنی ارسال گردید.';
            } else {
                $_SESSION['flash'] = 'تنظیمات ایمیل‌های سیستم مانیتورینگ ذخیره شد.';
            }
        }
        header('Location: ?p=monitoring');
        exit;
    }
PHP;
        $phCode = preg_replace('/\/\/ --- ASEMAN V16: پردازش اسکن بارکد کتاب.*?$/s', '', $phCode);
        $phCode = rtrim($phCode) . "\n" . $extraPostActions . "\n";
        v16_backup_and_save('actions/post_handlers.php', $phCode);
    }
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>ارتقای خودکار به نسخه ۱۶ سامانه آسمان</title>
    <style>
        body { font-family: Tahoma, Vazirmatn, sans-serif; background: #f0f6ff; color: #0f172a; padding: 30px; line-height: 1.9; }
        .card { max-width: 820px; margin: 0 auto; background: #fff; border-radius: 16px; padding: 28px; box-shadow: 0 12px 30px rgba(7,25,61,0.08); border-top: 4px solid #0d7a8a; }
        h2 { margin-top: 0; color: #0c3b47; border-bottom: 2px solid #e2e8f0; padding-bottom: 12px; }
        .btn { background: linear-gradient(135deg, #0d7a8a, #0c3b47); color: #fff; border: none; padding: 12px 28px; font-size: 15px; font-weight: bold; border-radius: 10px; cursor: pointer; }
        .log { background: #ecfdf5; border-right: 4px solid #10b981; padding: 9px 14px; border-radius: 6px; margin-bottom: 8px; font-size: 13.5px; color: #065f46; }
        code { background: #e2e8f0; padding: 2px 6px; border-radius: 4px; direction: ltr; display: inline-block; color: #0f172a; }
    </style>
</head>
<body>
<div class="card">
    <h2>ارتقای خودکار سامانه کتابخانه آسمان به نسخه ۱۶ (Enterprise)</h2>
    <?php if (!empty($logs)): ?>
        <p><b>گزارش عملیات ارتقا:</b></p>
        <?php foreach ($logs as $lg): ?>
            <div class="log">✓ <?= $lg ?></div>
        <?php endforeach; ?>
        <p style="margin-top:18px;font-weight:bold;color:#047857">
            تمامی ۱۰ مورد تغییرات نسخه ۱۶ بدون خطای Access Denied اعمال شدند. اکنون می‌توانید وارد پیشخوان مدیریت شوید.
        </p>
        <p><a href="index.php?p=dash" class="btn" style="text-decoration:none;display:inline-block">ورود به پیشخوان مدیریت نسخه ۱۶</a></p>
    <?php else: ?>
        <p>در این نسخه از اسکریپت، ثابت امنیتی <code>define('ASEMAN_ROOT', __DIR__);</code> در ابتدای اجرا تعریف شده تا خطای <code>Access Denied</code> به طور کامل برطرف شود و هر ۱۰ تغییر نسخه ۱۶ مستقیماً روی ساختار PostgreSQL و فایل‌های نسخه ۱۵ شما اعمال گردد.</p>
        <form method="post">
            <button type="submit" name="do_upgrade_v16" value="1" class="btn">شروع ارتقا به نسخه ۱۶</button>
        </form>
    <?php endif; ?>
</div>
</body>
</html>