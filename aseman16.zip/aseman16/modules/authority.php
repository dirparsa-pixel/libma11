<?php
// ماژول بانک مستندات فهرست‌نویسی (با پشتیبانی از استریم فایل‌های حجیم مارک و صفحه‌بندی مجازی)
if (!defined('ASEMAN_ROOT')) die('Access Denied');

$tab = isset($_GET['tab']) ? $_GET['tab'] : 'subject';
if (!in_array($tab, array('subject', 'names', 'tools'))) $tab = 'subject';

if (isset($_GET['cancel_auth_prev'])) {
    if (!empty($_SESSION['auth_preview_file']) && file_exists($_SESSION['auth_preview_file'])) {
        @unlink($_SESSION['auth_preview_file']);
    }
    unset($_SESSION['auth_preview'], $_SESSION['auth_preview_tab'], $_SESSION['auth_preview_file'], $_SESSION['auth_preview_total']);
}

echo '<h1>سرویس مستندات استاندارد فهرست‌نویسی (<a href="https://nlai.ir/Documentary-name" target="_blank" style="font-size:13px;color:var(--blue)">مستندات نام کتابخانه ملی</a>)</h1>';

if (!empty($_SESSION['auth_preview']) && is_array($_SESSION['auth_preview'])) {
    $ap_list = $_SESSION['auth_preview'];
    if (!empty($_SESSION['auth_preview_file']) && file_exists($_SESSION['auth_preview_file'])) {
        $full_dec = json_decode(file_get_contents($_SESSION['auth_preview_file']), true);
        if (is_array($full_dec)) $ap_list = $full_dec;
    }
    $ap_tab  = isset($_SESSION['auth_preview_tab']) ? $_SESSION['auth_preview_tab'] : $tab;
    $ap_subj = ($ap_tab === 'subject');
    $total_cnt = count($ap_list);

    echo '<div class="card" style="border:2px solid var(--ok);background:#f0fdf4">
        <h2>
            <span>پیش‌نمایش و بررسی مستندات استخراج‌شده قبل از ثبت نهایی (' . tr_num($total_cnt) . ' رکورد)</span>
            <span class="badge" style="background:var(--ok);color:#fff">رندر مجازی ۵۰ تایی بدون مصرف رم</span>
        </h2>
        <p style="font-size:12.5px;margin:0 0 10px">فیلدهای مستند (سرشناسه، سال‌های تولد و وفات، حوزه فعالیت، ارجاعات ۴XX/۵XX و یادداشت) به صورت تفکیک‌شده آماده ثبت هستند:</p>
        <form method="post" action="?p=auth_import_confirm" id="auth_prev_form">
            <input type="hidden" name="t" value="' . $tok . '">
            <input type="hidden" name="tbl" value="' . h($ap_tab) . '">
            <input type="hidden" name="auth_bulk_json" id="auth_bulk_json" value="">
            <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px;margin-bottom:10px;background:#dcfce7;padding:8px 12px;border-radius:8px">
                <div style="font-size:12.5px;font-weight:700;color:#065f46">
                    صفحه <span id="ap_cur_pg">۱</span> از <span id="ap_tot_pg">۱</span> (کل: ' . tr_num($total_cnt) . ' رکورد)
                </div>
                <div id="ap_pg_btns" style="display:flex;gap:4px;flex-wrap:wrap"></div>
                <div style="display:flex;gap:6px">
                    <button type="button" class="btn-sm ok" onclick="apToggleAll(true)">✓ انتخاب همه (' . tr_num($total_cnt) . ')</button>
                    <button type="button" class="btn-sm dng" onclick="apToggleAll(false)">✕ لغو همه</button>
                </div>
            </div>
            <div class="tbl-scroll">
                <table class="excel-tbl" id="ap_virtual_tbl">
                    <thead>
                    <tr>
                        <th style="width:28px"><input type="checkbox" checked onchange="apTogglePage(this.checked)"></th>
                        <th style="width:42px">ردیف</th>
                        <th>سرشناسه معتبر (Heading)</th>
                        <th style="width:95px">' . ($ap_subj ? 'موضوع عام‌تر' : 'نوع مستند') . '</th>
                        <th>شکل‌های مرجع (ارجاع 4XX)</th>
                        <th>' . ($ap_subj ? 'موضوعات وابسته (5XX)' : 'سال تولد-وفات ($f/$d)') . '</th>
                        <th>' . ($ap_subj ? 'یادداشت' : 'حوزه فعالیت / وابسته') . '</th>
                        ' . (!$ap_subj ? '<th>یادداشت منبع (810/300)</th>' : '') . '
                    </tr>
                    </thead>
                    <tbody id="ap_tbody_host"></tbody>
                </table>
            </div>
            <div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:12px">
                <button type="submit" class="btn ok">✓ تایید نهایی و ثبت مستندات انتخاب‌شده در بانک</button>
                <a class="btn dng" href="?p=authority&tab=' . h($tab) . '&cancel_auth_prev=1">انصراف و بستن پیش‌نمایش</a>
            </div>
        </form>
        <script>
        (function(){
            var apData = ' . json_encode(array_values($ap_list), JSON_UNESCAPED_UNICODE) . ';
            var isSubj = ' . ($ap_subj ? 'true' : 'false') . ';
            for (var i=0; i<apData.length; i++) apData[i]._sel = true;
            var pgSize = 50, curPg = 1, totPg = Math.max(1, Math.ceil(apData.length / pgSize));
            var D = "۰۱۲۳۴۵۶۷۸۹";
            function fa(n){ return String(n).replace(/[0-9]/g, function(d){ return D[d]; }); }
            function esc(s){ return String(s||"").replace(/[&<>"\']/g, function(m){ return {"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","\'":"&#39;"}[m]; }); }

            window.apEdit = function(idx, k, v) { if(apData[idx]) apData[idx][k] = v; };
            window.apToggleAll = function(st) { for(var i=0;i<apData.length;i++) apData[i]._sel = st; renderApPage(curPg); };
            window.apTogglePage = function(st) {
                var s = (curPg-1)*pgSize, e = Math.min(apData.length, s+pgSize);
                for(var i=s;i<e;i++) apData[i]._sel = st;
                renderApPage(curPg);
            };

            window.renderApPage = function(p) {
                curPg = Math.max(1, Math.min(totPg, p));
                var s = (curPg-1)*pgSize, e = Math.min(apData.length, s+pgSize), h = "";
                for (var i=s; i<e; i++) {
                    var r = apData[i];
                    h += "<tr><td><input type=\"checkbox\" " + (r._sel ? "checked" : "") + " onchange=\"apEdit("+i+",\'_sel\',this.checked)\"></td>"
                       + "<td style=\"text-align:center\">" + fa(i+1) + "</td>"
                       + "<td><input value=\"" + esc(r.heading) + "\" oninput=\"apEdit("+i+",\'heading\',this.value)\" style=\"font-weight:700\"></td>";
                    if (isSubj) {
                        h += "<td><input value=\"" + esc(r.broader) + "\" oninput=\"apEdit("+i+",\'broader\',this.value)\"></td>"
                           + "<td><input value=\"" + esc(r.variants) + "\" oninput=\"apEdit("+i+",\'variants\',this.value)\"></td>"
                           + "<td><input value=\"" + esc(r.related) + "\" oninput=\"apEdit("+i+",\'related\',this.value)\"></td>"
                           + "<td><input value=\"" + esc(r.note) + "\" oninput=\"apEdit("+i+",\'note\',this.value)\"></td>";
                    } else {
                        h += "<td><select onchange=\"apEdit("+i+",\'ntype\',this.value)\"><option value=\"person\"" + (r.ntype!=="corp"?" selected":"") + ">شخص</option><option value=\"corp\"" + (r.ntype==="corp"?" selected":"") + ">سازمان</option></select></td>"
                           + "<td><input value=\"" + esc(r.variants) + "\" oninput=\"apEdit("+i+",\'variants\',this.value)\"></td>"
                           + "<td><input value=\"" + esc(r.years) + "\" oninput=\"apEdit("+i+",\'years\',this.value)\"></td>"
                           + "<td><input value=\"" + esc(r.field) + "\" oninput=\"apEdit("+i+",\'field\',this.value)\"></td>"
                           + "<td><input value=\"" + esc(r.note) + "\" oninput=\"apEdit("+i+",\'note\',this.value)\"></td>";
                    }
                    h += "</tr>";
                }
                document.getElementById("ap_tbody_host").innerHTML = h;
                document.getElementById("ap_cur_pg").textContent = fa(curPg);
                document.getElementById("ap_tot_pg").textContent = fa(totPg);

                var bw = document.getElementById("ap_pg_btns");
                bw.innerHTML = "";
                if (totPg > 1) {
                    for (var pg=1; pg<=totPg; pg++) {
                        if (totPg > 10 && pg > 2 && pg < totPg - 1 && Math.abs(pg - curPg) > 2) continue;
                        (function(pn){
                            var b = document.createElement("button");
                            b.type = "button";
                            b.className = "btn-sm" + (pn===curPg ? " pri" : "");
                            b.textContent = fa(pn);
                            b.onclick = function(){ renderApPage(pn); };
                            bw.appendChild(b);
                        })(pg);
                    }
                }
            };

            document.getElementById("auth_prev_form").addEventListener("submit", function(ev){
                var sel = [];
                for (var i=0; i<apData.length; i++) {
                    if (apData[i]._sel) {
                        var c = Object.assign({}, apData[i]);
                        delete c._sel;
                        sel.push(c);
                    }
                }
                if (!sel.length) { ev.preventDefault(); alert("هیچ رکوردی انتخاب نشده است."); return; }
                document.getElementById("auth_bulk_json").value = JSON.stringify(sel);
            });

            renderApPage(1);
        })();
        </script>
    </div>';
}

if (!empty($_SESSION['flash'])) { echo '<div class="ok-msg">' . h($_SESSION['flash']) . '</div>'; unset($_SESSION['flash']); }
if (isset($_GET['msg'])) echo '<div class="ok-msg">' . ($_GET['msg'] === 'dup' ? 'این سرشناسه از قبل در بانک وجود دارد.' : 'انجام شد.') . '</div>';
echo '<div class="tabs"><a class="' . ($tab === 'subject' ? 'on' : '') . '" href="?p=authority&tab=subject">بانک سرشناسهٔ موضوعی مستند فارسی</a><a class="' . ($tab === 'names' ? 'on' : '') . '" href="?p=authority&tab=names">بانک مستند مشاهیر (اشخاص و سازمان‌ها)</a><a class="' . ($tab === 'tools' ? 'on' : '') . '" href="?p=authority&tab=tools">ابزارها (ساخت از رکوردها، اعمال، راهنما)</a></div>';

if ($tab === 'tools') {
    $c1 = (int)$db->query("SELECT COUNT(*) FROM auth_subject")->fetchColumn();
    $c2 = (int)$db->query("SELECT COUNT(*) FROM auth_names")->fetchColumn();
    echo '<div class="stats"><div class="card"><b>' . tr_num($c1) . '</b>سرشناسهٔ موضوعی</div><div class="card"><b>' . tr_num($c2) . '</b>مستند مشاهیر</div></div>
    <div class="grid"><div class="card"><h2>ساخت بانک از رکوردهای موجود</h2><p style="font-size:12.8px;line-height:1.8">همهٔ نام‌های پدیدآور (فیلد ۷۰۰ و ۷۱۰) و سرشناسه‌های موضوعی (فیلد ۶۰۶، جداشده با «؛») که تا امروز در رکوردها ثبت شده، به‌عنوان مستند اولیه ساخته می‌شود.</p>' . post_btn('auth_harvest', 'ساخت مستند از رکوردها', array(), 'btn pri') . '</div>';
    if (is_super_admin()) echo '<div class="card"><h2>اعمال شکل معتبر روی رکوردها</h2><p style="font-size:12.8px;line-height:1.8">هر رکوردی که یکی از «شکل‌های مرجع» را دارد، با سرشناسهٔ معتبر جایگزین می‌شود. پیش از اجرا پشتیبان خودکار گرفته می‌شود.</p>' . post_btn('auth_apply', 'اعمال بر همهٔ رکوردها', array(), 'btn dng') . '</div>';
    echo '</div>';
} else {
    $subj = ($tab === 'subject');
    $tbl = $subj ? 'auth_subject' : 'auth_names';
    $eid = (int)(isset($_GET['edit']) ? $_GET['edit'] : 0);
    $e = array('id' => 0, 'heading' => '', 'variants' => '', 'broader' => '', 'related' => '', 'note' => '', 'ntype' => 'person', 'years' => '', 'field' => '');
    if ($eid) { $se = $db->prepare("SELECT * FROM $tbl WHERE id=?"); $se->execute(array($eid)); $fe = $se->fetch(PDO::FETCH_ASSOC); if ($fe) $e = array_merge($e, $fe); }
    echo '<div class="card"><h2>' . ($e['id'] ? 'ویرایش' : 'افزودن') . ($subj ? ' سرشناسهٔ موضوعی' : ' مستند شخص/سازمان') . '</h2><form method="post" action="?p=auth_save"><input type="hidden" name="t" value="' . $tok . '"><input type="hidden" name="tbl" value="' . $tab . '"><input type="hidden" name="id" value="' . $e['id'] . '"><div class="grid">
        <div><label>' . ($subj ? 'سرشناسهٔ موضوعی معتبر *' : 'سرشناسهٔ معتبر (نام خانوادگی، نام) *') . '</label><input name="heading" value="' . h($e['heading']) . '" required></div>
        <div><label>شکل‌های مرجع (ارجاع «ببینید») — با «؛» جدا کنید</label><input name="variants" value="' . h(str_replace('|', '؛ ', $e['variants'])) . '"></div>';
    if ($subj) echo '<div><label>موضوع عام‌تر</label><input name="broader" value="' . h($e['broader']) . '"></div><div><label>موضوعات وابسته</label><input name="related" value="' . h($e['related']) . '"></div>';
    else echo '<div><label>نوع</label><select name="ntype"><option value="person"' . ($e['ntype'] !== 'corp' ? ' selected' : '') . '>شخص (مشاهیر)</option><option value="corp"' . ($e['ntype'] === 'corp' ? ' selected' : '') . '>سازمان / نهاد</option></select></div><div><label>سال تولد - وفات / فعالیت</label><input name="years" value="' . h($e['years']) . '"></div><div><label>حوزهٔ فعالیت</label><input name="field" value="' . h($e['field']) . '"></div>';
    echo '<div><label>یادداشت</label><input name="note" value="' . h($e['note']) . '"></div></div><br><button class="btn pri">' . ($e['id'] ? 'ذخیرهٔ ویرایش' : 'افزودن به بانک') . '</button> ' . ($e['id'] ? '<a class="btn" href="?p=authority&tab=' . $tab . '">انصراف</a>' : '') . '</form></div>';

    $q = trim(isset($_GET['q']) ? $_GET['q'] : '');
    $pg = max(1, (int)(isset($_GET['pg']) ? $_GET['pg'] : 1));
    $per = 40;
    $par = array(); $w = '';
    if ($q !== '') { $w = "WHERE norm LIKE :q OR heading LIKE :q2"; $par[':q'] = '%' . fts_norm($q) . '%'; $par[':q2'] = '%' . $q . '%'; }
    $ct = $db->prepare("SELECT COUNT(*) FROM $tbl $w"); $ct->execute($par); $tot = (int)$ct->fetchColumn();
    $st = $db->prepare("SELECT * FROM $tbl $w ORDER BY heading LIMIT $per OFFSET " . (($pg - 1) * $per)); $st->execute($par);
    echo '<form class="card row" method="get"><input type="hidden" name="p" value="authority"><input type="hidden" name="tab" value="' . $tab . '"><div style="flex:1"><label>جستجو در بانک</label><input name="q" value="' . h($q) . '"></div><button class="btn pri">جستجو</button><a class="btn" href="?p=authority&tab=' . $tab . '&export=1">اکسل</a></form>';
    echo '<form class="card" method="post" action="?p=auth_bulk_del" onsubmit="return confirm(\'آیا از حذف مستندات انتخاب‌شده یا کل لیست مطمئن هستید؟\')">
        <input type="hidden" name="t" value="' . $tok . '"><input type="hidden" name="tbl" value="' . $tab . '"><input type="hidden" name="q" value="' . h($q) . '">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;flex-wrap:wrap;gap:8px">
            <div style="display:flex;gap:6px">
                <button type="submit" class="btn-sm dng">حذف موارد انتخاب‌شده</button>
                <button type="submit" name="del_all" value="1" class="btn-sm dng" style="background:#ef4444;color:#fff;border-color:#b91c1c" onclick="return prompt(\'برای تایید عبارت (حذف کامل) را تایپ کنید:\') === \'حذف کامل\'">حذف کل مستندات ' . ($q !== '' ? 'یافت‌شده' : 'این بانک') . '</button>
            </div>
        </div>
        <table><tr><th style="width:28px"><input type="checkbox"></th><th>سرشناسه</th><th>' . ($subj ? 'شکل‌های مرجع' : 'نوع / سال‌ها') . '</th><th>' . ($subj ? 'عام‌تر' : 'حوزه') . '</th><th style="width:65px">کاربرد</th><th style="width:95px">عملیات</th></tr>';
    foreach ($st as $x) {
        if ($subj) { $us = $db->prepare("SELECT COUNT(*) FROM records WHERE f606 LIKE ?"); $us->execute(array('%' . $x['heading'] . '%')); }
        else { $us = $db->prepare("SELECT COUNT(*) FROM records WHERE f700=? OR f710=? OR f200f=?"); $us->execute(array($x['heading'], $x['heading'], $x['heading'])); }
        echo '<tr><td><input type="checkbox" name="ids[]" value="' . $x['id'] . '"></td><td><b>' . h($x['heading']) . '</b></td><td>' . ($subj ? h(str_replace('|', '؛ ', $x['variants'])) : ($x['ntype'] === 'corp' ? 'سازمان' : 'شخص') . ' ' . h($x['years']) . ($x['variants'] ? '<br><small>ارجاع: ' . h(str_replace('|', '؛ ', $x['variants'])) . '</small>' : '')) . '</td><td>' . h($subj ? $x['broader'] : $x['field']) . '</td><td>' . tr_num($us->fetchColumn()) . '</td><td style="white-space:nowrap"><a class="btn-sm pri" href="?p=authority&tab=' . $tab . '&edit=' . $x['id'] . '">ویرایش</a> <a class="btn-sm dng" href="#" onclick="if(confirm(\'حذف شود؟\')){var f=document.createElement(\'form\');f.method=\'post\';f.action=\'?p=auth_del\';f.innerHTML=\'<input type=\x22hidden\x22 name=\x22t\x22 value=\x22' . $tok . '\x22><input type=\x22hidden\x22 name=\x22tbl\x22 value=\x22' . $tab . '\x22><input type=\x22hidden\x22 name=\x22id\x22 value=\x22' . $x['id'] . '\x22>\';document.body.appendChild(f);f.submit();}return false;">حذف</a></td></tr>';
    }
    echo '</table><p style="margin:8px 0 0">مجموع: <b>' . tr_num($tot) . '</b></p></form>';
    $last = max(1, (int)ceil($tot / $per));
    for ($i = max(1, $pg - 6); $i <= min($last, $pg + 6); $i++) echo '<a class="btn-sm' . ($i == $pg ? ' pri' : '') . '" href="?p=authority&tab=' . $tab . '&q=' . urlencode($q) . '&pg=' . $i . '">' . tr_num($i) . '</a> ';
    echo '<div class="card" style="margin-top:14px"><h2>ورود گروهی (اکسل، CSV و فایل‌های مستند مارک / متنی MARC بدون محدودیت حجم)</h2><form method="post" action="?p=auth_import" enctype="multipart/form-data" class="row"><input type="hidden" name="t" value="' . $tok . '"><input type="hidden" name="tbl" value="' . $tab . '"><div style="flex:1"><label>انتخاب فایل (.xls, .xlsx, .csv, .mrc, .iso, .txt, .dat)</label><input type="file" name="f" accept=".xls,.xlsx,.csv,.mrc,.iso,.txt,.dat" required></div><button class="btn pri">بارگذاری و پیش‌نمایش سرشناسه‌ها</button></form></div>';
}