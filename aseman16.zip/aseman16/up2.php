<?php
/**
 * اسکریپت ارتقای یکپارچه سامانه کتابخانه آسمان (Aseman v16.1 Patch)
 * ۱. اکسل‌مانند شدن، فشرده‌سازی و حذف اسکرول افقی تمام جداول سایت
 * ۲. رفع قطعی خطای Allowed memory size exhausted در ورود مستندات نام مارک (پردازش جریانی + صفحه‌بندی مجازی)
 * ۳. نمودار پیشرفته و خودکار پرتال متصل به آمار زنده سامانه (۶ منبع داده، ۶ نوع نمودار، ۷ پالت رنگی + انتخابگر رنگ)
 */

@ini_set('memory_limit', '-1');
@set_time_limit(0);
define('ASEMAN_ROOT', __DIR__);

error_reporting(E_ALL);
ini_set('display_errors', 1);
header('Content-Type: text/html; charset=utf-8');

$backupDir = ASEMAN_ROOT . '/backups/patch_v16_1_' . date('Ymd_His');
$logs = array();

function patch_log($msg) {
    global $logs;
    $logs[] = $msg;
}

function patch_save_file($relPath, $content) {
    global $backupDir;
    $fullPath = ASEMAN_ROOT . '/' . ltrim($relPath, '/');
    if (!is_dir($backupDir)) {
        @mkdir($backupDir, 0755, true);
    }
    if (file_exists($fullPath)) {
        @copy($fullPath, $backupDir . '/' . str_replace(array('/', '\\'), '_', $relPath));
    }
    file_put_contents($fullPath, $content);
    patch_log("فایل <code>{$relPath}</code> با موفقیت بروزرسانی شد.");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['run_patch'])) {

    require_once ASEMAN_ROOT . '/config/constants.php';
    require_once ASEMAN_ROOT . '/config/database.php';

    // =========================================================================
    // بخش ۱: برداشتن محدودیت‌های حافظه و زمان اجرا در هسته و افزایش سقف ورود گروهی
    // =========================================================================
    
    // 1.1: index.php
    $indexFile = ASEMAN_ROOT . '/index.php';
    if (file_exists($indexFile)) {
        $idxCode = file_get_contents($indexFile);
        if (strpos($idxCode, "ini_set('memory_limit'") === false) {
            $idxCode = preg_replace(
                '/define\(\'ASEMAN_ROOT\',\s*__DIR__\);/',
                "define('ASEMAN_ROOT', __DIR__);\n@ini_set('memory_limit', '-1');\n@ini_set('max_execution_time', '0');\n@set_time_limit(0);",
                $idxCode,
                1
            );
            patch_save_file('index.php', $idxCode);
        }
    }

    // 1.2: config/constants.php (افزایش سقف پیش‌فرض و افزودن تنظیمات نمودار پیشرفته)
    $constFile = ASEMAN_ROOT . '/config/constants.php';
    if (file_exists($constFile)) {
        $cCode = file_get_contents($constFile);
        if (strpos($cCode, "ini_set('memory_limit'") === false) {
            $cCode = preg_replace(
                '/if\s*\(!defined\(\'ASEMAN_ROOT\'\)\)\s*die\(\'Access Denied\'\);/',
                "if (!defined('ASEMAN_ROOT')) die('Access Denied');\n@ini_set('memory_limit', '-1');\n@set_time_limit(0);",
                $cCode,
                1
            );
        }
        $cCode = str_replace("'max_bulk_import' => '500'", "'max_bulk_import' => '100000'", $cCode);

        $chartDefaults = <<<'PHP'
    'chart_source'        => 'by_loc',
    'chart_type'          => 'bar_v',
    'chart_palette'       => 'emerald',
    'chart_custom_color'  => '#0d7a8a',
    'chart_custom_color2' => '#c5a059',
    'chart_limit'         => '12',
    'chart_show_kpi'      => '1',
    'chart_allow_switch'  => '1',
PHP;
        if (strpos($cCode, "'chart_source'") === false) {
            $cCode = preg_replace('/(\$cms_defaults\s*=\s*array\s*\()/', "$1\n" . $chartDefaults, $cCode, 1);
        }
        patch_save_file('config/constants.php', $cCode);
    }

    if (isset($db) && $db instanceof PDO) {
        try {
            $st_lim = $db->prepare("INSERT INTO cms(k,v) VALUES('max_bulk_import','100000') ON CONFLICT (k) DO UPDATE SET v='100000'");
            $st_lim->execute();
            patch_log("سقف ورود گروهی در دیتابیس به <code>100,000</code> رکورد ارتقا یافت.");
        } catch (Exception $e) {}
    }

    // =========================================================================
    // بخش ۲: بازنویسی مبدل مستندات مارک به روش جریانی و اشاره‌گری (بدون مصرف رم)
    // =========================================================================
    $marcFile = ASEMAN_ROOT . '/includes/marc_parser.php';
    if (file_exists($marcFile)) {
        $mCode = file_get_contents($marcFile);
        if (strpos($mCode, "ini_set('memory_limit'") === false) {
            $mCode = preg_replace('/<\?php/', "<?php\n@ini_set('memory_limit', '-1');\n@set_time_limit(0);", $mCode, 1);
        }

        // جایگزینی کامل تابع parse_authority_marc_records با نسخه Stream/Offset Pointer
        $newAuthParser = <<<'PHP'
// ==================== ۶. مبدل تخصصی مستندات نام و موضوع مارک (پردازش جریانی بدون مصرف حافظه) ====================
if (!function_exists('parse_single_authority_marc_chunk')) {
    function parse_single_authority_marc_chunk($chunk, $is_subject_tab = false) {
        $chunk = trim($chunk);
        if ($chunk === '') return array();
        $pairs = array();
        $out = array();

        if (strlen($chunk) >= 24 && preg_match('/^\d{5}/', $chunk)) {
            $pos_1e = strpos($chunk, "\x1e");
            if ($pos_1e !== false && $pos_1e >= 24) {
                $dir_s = substr($chunk, 24, $pos_1e - 24);
                $fields_raw = explode("\x1e", substr($chunk, $pos_1e + 1));
                $f_idx = 0;
                $dir_len = strlen($dir_s);
                for ($i = 0; $i + 12 <= $dir_len; $i += 12) {
                    $tg = substr($dir_s, $i, 3);
                    if (ctype_digit($tg) && isset($fields_raw[$f_idx])) {
                        $pairs[] = array($tg, $fields_raw[$f_idx]);
                    }
                    $f_idx++;
                }
            }
            if (empty($pairs)) {
                $base = (int)substr($chunk, 12, 5);
                if ($base > 24 && $base <= strlen($chunk)) {
                    $dir = substr($chunk, 24, $base - 25);
                    $data = substr($chunk, $base);
                    $dir_len = strlen($dir);
                    for ($i = 0; $i + 12 <= $dir_len; $i += 12) {
                        $tg = substr($dir, $i, 3);
                        $ln = (int)substr($dir, $i + 3, 4);
                        $ps = (int)substr($dir, $i + 7, 5);
                        $pairs[] = array($tg, substr($data, $ps, $ln));
                    }
                }
            }
        } else {
            foreach (preg_split('/\r\n|\r|\n/', $chunk) as $ln_str) {
                $ln_str = trim($ln_str);
                if (preg_match('/^=?(\d{3})\s+(.*)$/u', $ln_str, $mm)) {
                    $pairs[] = array($mm[1], $mm[2]);
                }
            }
        }

        if (empty($pairs)) {
            foreach (preg_split('/\r\n|\r|\n/', $chunk) as $plain_ln) {
                $plain_ln = clean_marc_str($plain_ln);
                if ($plain_ln !== '') {
                    $out[] = array(
                        'heading'  => $plain_ln,
                        'ntype'    => 'person',
                        'variants' => '',
                        'years'    => '',
                        'field'    => '',
                        'broader'  => '',
                        'related'  => '',
                        'note'     => 'ورود متنی'
                    );
                }
            }
            return $out;
        }

        $item = array(
            'heading'  => '',
            'ntype'    => 'person',
            'variants' => array(),
            'years'    => '',
            'field'    => array(),
            'broader'  => array(),
            'related'  => array(),
            'note'     => array(),
            'tag'      => ''
        );

        foreach ($pairs as $pr) {
            $tag = $pr[0];
            $val = $pr[1];
            $subs = extract_subfields_universal($tag, $val, false);
            if (empty($subs)) continue;

            if (in_array($tag, array('200', '100', '700', '701')) && $item['heading'] === '') {
                $a = isset($subs['a'][0]) ? $subs['a'][0] : '';
                if ($tag === '100' && preg_match('/(\d{8}|\bper\b|\bara\b|\b50\b)/i', en_num($a))) continue;
                $b = isset($subs['b'][0]) ? $subs['b'][0] : '';
                $item['heading'] = trim($a . ($b !== '' ? '، ' . $b : ''));
                $item['ntype']   = 'person';
                $item['tag']     = $tag;
                if (!empty($subs['f'][0])) $item['years'] = $subs['f'][0];
                elseif (!empty($subs['d'][0])) $item['years'] = $subs['d'][0];
                if (!empty($subs['c'])) {
                    foreach ($subs['c'] as $sc) $item['field'][] = $sc;
                }
            } elseif (in_array($tag, array('210', '110', '111', '710')) && $item['heading'] === '') {
                $a = isset($subs['a'][0]) ? $subs['a'][0] : '';
                $b = isset($subs['b'][0]) ? $subs['b'][0] : '';
                $item['heading'] = trim($a . ($b !== '' ? ' - ' . $b : ''));
                $item['ntype']   = 'corp';
                $item['tag']     = $tag;
                if (!empty($subs['f'][0])) $item['years'] = $subs['f'][0];
                elseif (!empty($subs['d'][0])) $item['years'] = $subs['d'][0];
            } elseif (in_array($tag, array('250', '215', '150', '151', '606', '650')) && ($is_subject_tab || $item['heading'] === '')) {
                if (!empty($subs['a'][0])) {
                    $s_parts = $subs['a'];
                    foreach (array('x','y','z','j') as $sk) if (isset($subs[$sk])) $s_parts = array_merge($s_parts, $subs[$sk]);
                    $item['heading'] = implode(' -- ', $s_parts);
                    $item['tag']     = $tag;
                }
            } elseif (in_array($tag, array('400', '410', '411', '415', '420', '450'))) {
                $va = isset($subs['a'][0]) ? $subs['a'][0] : '';
                $vb = isset($subs['b'][0]) ? $subs['b'][0] : '';
                $v_full = trim($va . ($vb !== '' ? '، ' . $vb : ''));
                if ($v_full !== '') $item['variants'][] = $v_full;
            } elseif (in_array($tag, array('500', '510', '511', '515', '520', '550'))) {
                $sa = isset($subs['a'][0]) ? $subs['a'][0] : '';
                $sb = isset($subs['b'][0]) ? $subs['b'][0] : '';
                $s_full = trim($sa . ($sb !== '' ? '، ' . $sb : ''));
                if ($s_full !== '') {
                    if (!empty($subs['5'][0]) && strpos($subs['5'][0], 'g') !== false) {
                        $item['broader'][] = $s_full;
                    } else {
                        $item['related'][] = $s_full;
                        $item['field'][]   = $s_full;
                    }
                }
            } elseif (in_array($tag, array('372', '340', '368'))) {
                if (!empty($subs['a'])) {
                    foreach ($subs['a'] as $fa) $item['field'][] = $fa;
                }
            } elseif (in_array($tag, array('300', '670', '680', '810'))) {
                if (!empty($subs['a'])) {
                    $item['note'][] = implode(' - ', $subs['a']);
                }
            }
        }

        if ($item['heading'] !== '') {
            $out[] = array(
                'heading'  => $item['heading'],
                'ntype'    => $item['ntype'],
                'variants' => implode(' ؛ ', array_unique($item['variants'])),
                'years'    => $item['years'],
                'field'    => implode(' ؛ ', array_unique($item['field'])),
                'broader'  => implode(' ؛ ', array_unique($item['broader'])),
                'related'  => implode(' ؛ ', array_unique($item['related'])),
                'note'     => implode(' | ', array_unique($item['note'])),
                'tag'      => $item['tag']
            );
        }
        return $out;
    }
}

if (!function_exists('parse_authority_marc_stream')) {
    function parse_authority_marc_stream($file_path, $is_subject_tab = false, $max_records = 100000) {
        @ini_set('memory_limit', '-1');
        @set_time_limit(0);
        $records = array();
        if (!file_exists($file_path)) return $records;

        $fp = @fopen($file_path, 'rb');
        if (!$fp) return $records;

        $first3 = fread($fp, 3);
        if ($first3 !== "\xEF\xBB\xBF") {
            fseek($fp, 0);
        }

        // بررسی وجود جداکننده 0x1D در ۶۴ کیلوبایت اول
        $pos_start = ftell($fp);
        $sample = fread($fp, 65536);
        fseek($fp, $pos_start);

        if (strpos($sample, "\x1d") !== false) {
            while (!feof($fp) && count($records) < $max_records) {
                $chunk = stream_get_line($fp, 1048576, "\x1d");
                if ($chunk === false || $chunk === '') {
                    if (feof($fp)) break;
                    continue;
                }
                $parsed = parse_single_authority_marc_chunk($chunk, $is_subject_tab);
                foreach ($parsed as $pr) {
                    $records[] = $pr;
                    if (count($records) >= $max_records) break;
                }
            }
            fclose($fp);
            return $records;
        }

        // خواندن خط‌به‌خط برای فایل‌های متنی مارک یا بدون 0x1D
        $buf = '';
        while (($line = fgets($fp)) !== false && count($records) < $max_records) {
            $trim_l = trim($line);
            if ($trim_l === '' && $buf !== '') {
                foreach (parse_single_authority_marc_chunk($buf, $is_subject_tab) as $pr) {
                    $records[] = $pr;
                }
                $buf = '';
            } elseif (preg_match('/^(\=LDR|\=001|001\s|\d{5}[a-z0-9\s]{19}\d{12})/i', $trim_l) && $buf !== '') {
                foreach (parse_single_authority_marc_chunk($buf, $is_subject_tab) as $pr) {
                    $records[] = $pr;
                }
                $buf = $line;
            } else {
                $buf .= $line;
            }
        }
        if ($buf !== '' && count($records) < $max_records) {
            foreach (parse_single_authority_marc_chunk($buf, $is_subject_tab) as $pr) {
                $records[] = $pr;
            }
        }
        fclose($fp);
        return $records;
    }
}

if (!function_exists('parse_authority_marc_records')) {
    function parse_authority_marc_records($raw, $is_subject_tab = false) {
        @ini_set('memory_limit', '-1');
        @set_time_limit(0);
        if (substr($raw, 0, 3) === "\xEF\xBB\xBF") $raw = substr($raw, 3);
        $records = array();
        $len = strlen($raw);
        if ($len === 0) return $records;

        if (strpos($raw, "\x1d") !== false) {
            $offset = 0;
            while ($offset < $len) {
                $pos = strpos($raw, "\x1d", $offset);
                if ($pos === false) {
                    $chunk = substr($raw, $offset);
                    $offset = $len;
                } else {
                    $chunk = substr($raw, $offset, $pos - $offset);
                    $offset = $pos + 1;
                }
                if (trim($chunk) !== '') {
                    foreach (parse_single_authority_marc_chunk($chunk, $is_subject_tab) as $pr) {
                        $records[] = $pr;
                    }
                }
            }
            return $records;
        }

        // اگر جداکننده 0x1D نداشت، در یک استریم موقت پردازش شود
        $tmp = tempnam(sys_get_temp_dir(), 'asm_marc_');
        file_put_contents($tmp, $raw);
        unset($raw);
        $records = parse_authority_marc_stream($tmp, $is_subject_tab);
        @unlink($tmp);
        return $records;
    }
}
PHP;

        $pos_marker = strpos($mCode, '// ==================== ۶. مبدل تخصصی مستندات نام');
        if ($pos_marker !== false) {
            $mCode = substr($mCode, 0, $pos_marker) . $newAuthParser . "\n";
        } else {
            $mCode .= "\n" . $newAuthParser . "\n";
        }
        patch_save_file('includes/marc_parser.php', $mCode);
    }

    // =========================================================================
    // بخش ۲.۲: ارتقای actions/post_handlers.php برای استریم مستندات و سقف ۱۰۰،۰۰۰
    // =========================================================================
    $postFile = ASEMAN_ROOT . '/actions/post_handlers.php';
    if (file_exists($postFile)) {
        $pCode = file_get_contents($postFile);
        if (strpos($pCode, "ini_set('memory_limit'") === false) {
            $pCode = preg_replace('/<\?php/', "<?php\n@ini_set('memory_limit', '-1');\n@set_time_limit(0);", $pCode, 1);
        }
        $pCode = str_replace('min(50000,', 'min(100000,', $pCode);

        // استفاده از parse_authority_marc_stream به جای file_get_contents
        $oldAuthImp = '$raw_mrc = file_get_contents($_FILES[\'f\'][\'tmp_name\']);
                $preview_rows = parse_authority_marc_records($raw_mrc, $subj);';
        $newAuthImp = '$preview_rows = function_exists(\'parse_authority_marc_stream\') ? parse_authority_marc_stream($_FILES[\'f\'][\'tmp_name\'], $subj, 100000) : parse_authority_marc_records(file_get_contents($_FILES[\'f\'][\'tmp_name\']), $subj);';
        $pCode = str_replace($oldAuthImp, $newAuthImp, $pCode);

        // ذخیره فایل کش موقت برای پیش‌نمایش‌های بزرگ مستندات جهت جلوگیری از پر شدن سشن
        $oldSessSave = '$_SESSION[\'auth_preview\'] = $preview_rows;';
        $newSessSave = '$auth_cache_file = sys_get_temp_dir() . \'/aseman_auth_prev_\' . session_id() . \'.json\';
        file_put_contents($auth_cache_file, json_encode($preview_rows, JSON_UNESCAPED_UNICODE));
        $_SESSION[\'auth_preview_file\'] = $auth_cache_file;
        $_SESSION[\'auth_preview\'] = array_slice($preview_rows, 0, 200);
        $_SESSION[\'auth_preview_total\'] = count($preview_rows);';
        $pCode = str_replace($oldSessSave, $newSessSave, $pCode);

        // ارتقای auth_import_confirm برای پشتیبانی از ثبت جریانی JSON و ثبت کل رکوردهای کش‌شده
        $oldConfirmBlock = <<<'PHP'
    if ($p === 'auth_import_confirm' && can('authority')) {
        $subj = (isset($_POST['tbl']) && $_POST['tbl'] === 'subject');
        $tab_name = $subj ? 'subject' : 'names';
        $sel = isset($_POST['sel']) && is_array($_POST['sel']) ? $_POST['sel'] : array();
        $n = 0;
        $db->beginTransaction();
        foreach ($sel as $idx) {
            $hd = trim($_POST['heading'][$idx] ?? '');
            if ($hd === '') continue;
            $vr = trim(str_replace(array('؛', ';'), '|', $_POST['variants'][$idx] ?? ''));
            $nt = trim($_POST['note'][$idx] ?? '');
            if ($subj) {
                $br = trim($_POST['broader'][$idx] ?? '');
                $rl = trim($_POST['related'][$idx] ?? '');
                $st_i = $db->prepare("INSERT INTO auth_subject(heading,variants,broader,related,note) VALUES(?,?,?,?,?) ON CONFLICT (heading) DO UPDATE SET variants=EXCLUDED.variants, broader=EXCLUDED.broader, related=EXCLUDED.related, note=EXCLUDED.note");
                $st_i->execute(array($hd, $vr, $br, $rl, $nt));
            } else {
                $tp = (isset($_POST['ntype'][$idx]) && $_POST['ntype'][$idx] === 'corp') ? 'corp' : 'person';
                $yr = trim($_POST['years'][$idx] ?? '');
                $fl = trim($_POST['field'][$idx] ?? '');
                $st_i = $db->prepare("INSERT INTO auth_names(heading,ntype,variants,years,field,note) VALUES(?,?,?,?,?,?) ON CONFLICT (heading) DO UPDATE SET ntype=EXCLUDED.ntype, variants=EXCLUDED.variants, years=EXCLUDED.years, field=EXCLUDED.field, note=EXCLUDED.note");
                $st_i->execute(array($hd, $tp, $vr, $yr, $fl, $nt));
            }
            $n++;
        }
        $db->commit();
        foreach (array('auth_subject', 'auth_names') as $t) {
            foreach ($db->query("SELECT id FROM $t WHERE norm IS NULL OR norm=''")->fetchAll(PDO::FETCH_COLUMN) as $i) auth_save_norm($t, $i);
        }
        unset($_SESSION['auth_preview'], $_SESSION['auth_preview_tab']);
        $_SESSION['flash'] = 'تعداد ' . tr_num($n) . ' سرشناسه مستند با موفقیت در بانک ثبت گردید.';
        header('Location: ?p=authority&tab=' . $tab_name);
        exit;
    }
PHP;

        $newConfirmBlock = <<<'PHP'
    if ($p === 'auth_import_confirm' && can('authority')) {
        @ini_set('memory_limit', '-1');
        @set_time_limit(0);
        $subj = (isset($_POST['tbl']) && $_POST['tbl'] === 'subject');
        $tab_name = $subj ? 'subject' : 'names';
        $n = 0;

        $rows_to_insert = array();
        if (!empty($_POST['auth_bulk_json'])) {
            $dec = json_decode($_POST['auth_bulk_json'], true);
            if (is_array($dec)) $rows_to_insert = $dec;
        } elseif (!empty($_POST['confirm_all_cached']) && !empty($_SESSION['auth_preview_file']) && file_exists($_SESSION['auth_preview_file'])) {
            $dec = json_decode(file_get_contents($_SESSION['auth_preview_file']), true);
            if (is_array($dec)) $rows_to_insert = $dec;
        } else {
            $sel = isset($_POST['sel']) && is_array($_POST['sel']) ? $_POST['sel'] : array();
            foreach ($sel as $idx) {
                $rows_to_insert[] = array(
                    'heading'  => $_POST['heading'][$idx] ?? '',
                    'variants' => $_POST['variants'][$idx] ?? '',
                    'note'     => $_POST['note'][$idx] ?? '',
                    'broader'  => $_POST['broader'][$idx] ?? '',
                    'related'  => $_POST['related'][$idx] ?? '',
                    'ntype'    => $_POST['ntype'][$idx] ?? 'person',
                    'years'    => $_POST['years'][$idx] ?? '',
                    'field'    => $_POST['field'][$idx] ?? ''
                );
            }
        }

        $db->beginTransaction();
        if ($subj) {
            $st_i = $db->prepare("INSERT INTO auth_subject(heading,variants,broader,related,note,norm) VALUES(?,?,?,?,?,?) ON CONFLICT (heading) DO UPDATE SET variants=EXCLUDED.variants, broader=EXCLUDED.broader, related=EXCLUDED.related, note=EXCLUDED.note, norm=EXCLUDED.norm");
        } else {
            $st_i = $db->prepare("INSERT INTO auth_names(heading,ntype,variants,years,field,note,norm) VALUES(?,?,?,?,?,?,?) ON CONFLICT (heading) DO UPDATE SET ntype=EXCLUDED.ntype, variants=EXCLUDED.variants, years=EXCLUDED.years, field=EXCLUDED.field, note=EXCLUDED.note, norm=EXCLUDED.norm");
        }

        foreach ($rows_to_insert as $ar) {
            $hd = trim($ar['heading'] ?? '');
            if ($hd === '') continue;
            $vr = trim(str_replace(array('؛', ';'), '|', $ar['variants'] ?? ''));
            $nt = trim($ar['note'] ?? '');
            $norm_v = fts_norm($hd . ' ' . str_replace('|', ' ', $vr));
            if ($subj) {
                $br = trim($ar['broader'] ?? '');
                $rl = trim($ar['related'] ?? '');
                $st_i->execute(array($hd, $vr, $br, $rl, $nt, $norm_v));
            } else {
                $tp = (isset($ar['ntype']) && $ar['ntype'] === 'corp') ? 'corp' : 'person';
                $yr = trim($ar['years'] ?? '');
                $fl = trim($ar['field'] ?? '');
                $st_i->execute(array($hd, $tp, $vr, $yr, $fl, $nt, $norm_v));
            }
            $n++;
        }
        $db->commit();

        if (!empty($_SESSION['auth_preview_file']) && file_exists($_SESSION['auth_preview_file'])) {
            @unlink($_SESSION['auth_preview_file']);
        }
        unset($_SESSION['auth_preview'], $_SESSION['auth_preview_tab'], $_SESSION['auth_preview_file'], $_SESSION['auth_preview_total']);
        $_SESSION['flash'] = 'تعداد ' . tr_num($n) . ' سرشناسه مستند با موفقیت در بانک ثبت گردید.';
        header('Location: ?p=authority&tab=' . $tab_name);
        exit;
    }
PHP;
        $pCode = str_replace($oldConfirmBlock, $newConfirmBlock, $pCode);
        patch_save_file('actions/post_handlers.php', $pCode);
    }

    // =========================================================================
    // بخش ۲.۳: ارتقای modules/authority.php به صفحه‌بندی مجازی (۵۰ تایی) برای مستندات حجیم
    // =========================================================================
    $authModFile = ASEMAN_ROOT . '/modules/authority.php';
    if (file_exists($authModFile)) {
        $newAuthMod = <<<'PHP'
<?php
// ماژول بانک مستندات فهرست‌نویسی (با پشتیبانی از استریم فایل‌های حجیم مارک و صفحه‌بندی مجازی)
if (!defined('ASEMAN_ROOT')) die('Access Denied');

$tab = isset($_GET['tab']) ? $_GET['tab'] : 'subject';
if (!in_array($tab, array('subject', 'names', 'tools'))) $tab = 'subject';

if (isset($_GET['cancel_auth_prev'])) {
    if (!empty($_SESSION['auth_preview_file']) && file_exists($_SESSION['auth_preview_file'])) {
        @unlink($_SESSION['auth_preview_file']);
    }
    unset($_SESSION['auth_preview'], $_SESSION['auth_preview_tab'], $_SESSION['auth_preview_file'], $_SESSION['auth_preview_total']);
}

echo '<h1>سرویس مستندات استاندارد فهرست‌نویسی (<a href="https://nlai.ir/Documentary-name" target="_blank" style="font-size:13px;color:var(--blue)">مستندات نام کتابخانه ملی</a>)</h1>';

if (!empty($_SESSION['auth_preview']) && is_array($_SESSION['auth_preview'])) {
    $ap_list = $_SESSION['auth_preview'];
    if (!empty($_SESSION['auth_preview_file']) && file_exists($_SESSION['auth_preview_file'])) {
        $full_dec = json_decode(file_get_contents($_SESSION['auth_preview_file']), true);
        if (is_array($full_dec)) $ap_list = $full_dec;
    }
    $ap_tab  = isset($_SESSION['auth_preview_tab']) ? $_SESSION['auth_preview_tab'] : $tab;
    $ap_subj = ($ap_tab === 'subject');
    $total_cnt = count($ap_list);

    echo '<div class="card" style="border:2px solid var(--ok);background:#f0fdf4">
        <h2>
            <span>پیش‌نمایش و بررسی مستندات استخراج‌شده قبل از ثبت نهایی (' . tr_num($total_cnt) . ' رکورد)</span>
            <span class="badge" style="background:var(--ok);color:#fff">رندر مجازی ۵۰ تایی بدون مصرف رم</span>
        </h2>
        <p style="font-size:12.5px;margin:0 0 10px">فیلدهای مستند (سرشناسه، سال‌های تولد و وفات، حوزه فعالیت، ارجاعات ۴XX/۵XX و یادداشت) به صورت تفکیک‌شده آماده ثبت هستند:</p>
        <form method="post" action="?p=auth_import_confirm" id="auth_prev_form">
            <input type="hidden" name="t" value="' . $tok . '">
            <input type="hidden" name="tbl" value="' . h($ap_tab) . '">
            <input type="hidden" name="auth_bulk_json" id="auth_bulk_json" value="">
            <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px;margin-bottom:10px;background:#dcfce7;padding:8px 12px;border-radius:8px">
                <div style="font-size:12.5px;font-weight:700;color:#065f46">
                    صفحه <span id="ap_cur_pg">۱</span> از <span id="ap_tot_pg">۱</span> (کل: ' . tr_num($total_cnt) . ' رکورد)
                </div>
                <div id="ap_pg_btns" style="display:flex;gap:4px;flex-wrap:wrap"></div>
                <div style="display:flex;gap:6px">
                    <button type="button" class="btn-sm ok" onclick="apToggleAll(true)">✓ انتخاب همه (' . tr_num($total_cnt) . ')</button>
                    <button type="button" class="btn-sm dng" onclick="apToggleAll(false)">✕ لغو همه</button>
                </div>
            </div>
            <div class="tbl-scroll">
                <table class="excel-tbl" id="ap_virtual_tbl">
                    <thead>
                    <tr>
                        <th style="width:28px"><input type="checkbox" checked onchange="apTogglePage(this.checked)"></th>
                        <th style="width:42px">ردیف</th>
                        <th>سرشناسه معتبر (Heading)</th>
                        <th style="width:95px">' . ($ap_subj ? 'موضوع عام‌تر' : 'نوع مستند') . '</th>
                        <th>شکل‌های مرجع (ارجاع 4XX)</th>
                        <th>' . ($ap_subj ? 'موضوعات وابسته (5XX)' : 'سال تولد-وفات ($f/$d)') . '</th>
                        <th>' . ($ap_subj ? 'یادداشت' : 'حوزه فعالیت / وابسته') . '</th>
                        ' . (!$ap_subj ? '<th>یادداشت منبع (810/300)</th>' : '') . '
                    </tr>
                    </thead>
                    <tbody id="ap_tbody_host"></tbody>
                </table>
            </div>
            <div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:12px">
                <button type="submit" class="btn ok">✓ تایید نهایی و ثبت مستندات انتخاب‌شده در بانک</button>
                <a class="btn dng" href="?p=authority&tab=' . h($tab) . '&cancel_auth_prev=1">انصراف و بستن پیش‌نمایش</a>
            </div>
        </form>
        <script>
        (function(){
            var apData = ' . json_encode(array_values($ap_list), JSON_UNESCAPED_UNICODE) . ';
            var isSubj = ' . ($ap_subj ? 'true' : 'false') . ';
            for (var i=0; i<apData.length; i++) apData[i]._sel = true;
            var pgSize = 50, curPg = 1, totPg = Math.max(1, Math.ceil(apData.length / pgSize));
            var D = "۰۱۲۳۴۵۶۷۸۹";
            function fa(n){ return String(n).replace(/[0-9]/g, function(d){ return D[d]; }); }
            function esc(s){ return String(s||"").replace(/[&<>"\']/g, function(m){ return {"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","\'":"&#39;"}[m]; }); }

            window.apEdit = function(idx, k, v) { if(apData[idx]) apData[idx][k] = v; };
            window.apToggleAll = function(st) { for(var i=0;i<apData.length;i++) apData[i]._sel = st; renderApPage(curPg); };
            window.apTogglePage = function(st) {
                var s = (curPg-1)*pgSize, e = Math.min(apData.length, s+pgSize);
                for(var i=s;i<e;i++) apData[i]._sel = st;
                renderApPage(curPg);
            };

            window.renderApPage = function(p) {
                curPg = Math.max(1, Math.min(totPg, p));
                var s = (curPg-1)*pgSize, e = Math.min(apData.length, s+pgSize), h = "";
                for (var i=s; i<e; i++) {
                    var r = apData[i];
                    h += "<tr><td><input type=\"checkbox\" " + (r._sel ? "checked" : "") + " onchange=\"apEdit("+i+",\'_sel\',this.checked)\"></td>"
                       + "<td style=\"text-align:center\">" + fa(i+1) + "</td>"
                       + "<td><input value=\"" + esc(r.heading) + "\" oninput=\"apEdit("+i+",\'heading\',this.value)\" style=\"font-weight:700\"></td>";
                    if (isSubj) {
                        h += "<td><input value=\"" + esc(r.broader) + "\" oninput=\"apEdit("+i+",\'broader\',this.value)\"></td>"
                           + "<td><input value=\"" + esc(r.variants) + "\" oninput=\"apEdit("+i+",\'variants\',this.value)\"></td>"
                           + "<td><input value=\"" + esc(r.related) + "\" oninput=\"apEdit("+i+",\'related\',this.value)\"></td>"
                           + "<td><input value=\"" + esc(r.note) + "\" oninput=\"apEdit("+i+",\'note\',this.value)\"></td>";
                    } else {
                        h += "<td><select onchange=\"apEdit("+i+",\'ntype\',this.value)\"><option value=\"person\"" + (r.ntype!=="corp"?" selected":"") + ">شخص</option><option value=\"corp\"" + (r.ntype==="corp"?" selected":"") + ">سازمان</option></select></td>"
                           + "<td><input value=\"" + esc(r.variants) + "\" oninput=\"apEdit("+i+",\'variants\',this.value)\"></td>"
                           + "<td><input value=\"" + esc(r.years) + "\" oninput=\"apEdit("+i+",\'years\',this.value)\"></td>"
                           + "<td><input value=\"" + esc(r.field) + "\" oninput=\"apEdit("+i+",\'field\',this.value)\"></td>"
                           + "<td><input value=\"" + esc(r.note) + "\" oninput=\"apEdit("+i+",\'note\',this.value)\"></td>";
                    }
                    h += "</tr>";
                }
                document.getElementById("ap_tbody_host").innerHTML = h;
                document.getElementById("ap_cur_pg").textContent = fa(curPg);
                document.getElementById("ap_tot_pg").textContent = fa(totPg);

                var bw = document.getElementById("ap_pg_btns");
                bw.innerHTML = "";
                if (totPg > 1) {
                    for (var pg=1; pg<=totPg; pg++) {
                        if (totPg > 10 && pg > 2 && pg < totPg - 1 && Math.abs(pg - curPg) > 2) continue;
                        (function(pn){
                            var b = document.createElement("button");
                            b.type = "button";
                            b.className = "btn-sm" + (pn===curPg ? " pri" : "");
                            b.textContent = fa(pn);
                            b.onclick = function(){ renderApPage(pn); };
                            bw.appendChild(b);
                        })(pg);
                    }
                }
            };

            document.getElementById("auth_prev_form").addEventListener("submit", function(ev){
                var sel = [];
                for (var i=0; i<apData.length; i++) {
                    if (apData[i]._sel) {
                        var c = Object.assign({}, apData[i]);
                        delete c._sel;
                        sel.push(c);
                    }
                }
                if (!sel.length) { ev.preventDefault(); alert("هیچ رکوردی انتخاب نشده است."); return; }
                document.getElementById("auth_bulk_json").value = JSON.stringify(sel);
            });

            renderApPage(1);
        })();
        </script>
    </div>';
}

if (!empty($_SESSION['flash'])) { echo '<div class="ok-msg">' . h($_SESSION['flash']) . '</div>'; unset($_SESSION['flash']); }
if (isset($_GET['msg'])) echo '<div class="ok-msg">' . ($_GET['msg'] === 'dup' ? 'این سرشناسه از قبل در بانک وجود دارد.' : 'انجام شد.') . '</div>';
echo '<div class="tabs"><a class="' . ($tab === 'subject' ? 'on' : '') . '" href="?p=authority&tab=subject">بانک سرشناسهٔ موضوعی مستند فارسی</a><a class="' . ($tab === 'names' ? 'on' : '') . '" href="?p=authority&tab=names">بانک مستند مشاهیر (اشخاص و سازمان‌ها)</a><a class="' . ($tab === 'tools' ? 'on' : '') . '" href="?p=authority&tab=tools">ابزارها (ساخت از رکوردها، اعمال، راهنما)</a></div>';

if ($tab === 'tools') {
    $c1 = (int)$db->query("SELECT COUNT(*) FROM auth_subject")->fetchColumn();
    $c2 = (int)$db->query("SELECT COUNT(*) FROM auth_names")->fetchColumn();
    echo '<div class="stats"><div class="card"><b>' . tr_num($c1) . '</b>سرشناسهٔ موضوعی</div><div class="card"><b>' . tr_num($c2) . '</b>مستند مشاهیر</div></div>
    <div class="grid"><div class="card"><h2>ساخت بانک از رکوردهای موجود</h2><p style="font-size:12.8px;line-height:1.8">همهٔ نام‌های پدیدآور (فیلد ۷۰۰ و ۷۱۰) و سرشناسه‌های موضوعی (فیلد ۶۰۶، جداشده با «؛») که تا امروز در رکوردها ثبت شده، به‌عنوان مستند اولیه ساخته می‌شود.</p>' . post_btn('auth_harvest', 'ساخت مستند از رکوردها', array(), 'btn pri') . '</div>';
    if (is_super_admin()) echo '<div class="card"><h2>اعمال شکل معتبر روی رکوردها</h2><p style="font-size:12.8px;line-height:1.8">هر رکوردی که یکی از «شکل‌های مرجع» را دارد، با سرشناسهٔ معتبر جایگزین می‌شود. پیش از اجرا پشتیبان خودکار گرفته می‌شود.</p>' . post_btn('auth_apply', 'اعمال بر همهٔ رکوردها', array(), 'btn dng') . '</div>';
    echo '</div>';
} else {
    $subj = ($tab === 'subject');
    $tbl = $subj ? 'auth_subject' : 'auth_names';
    $eid = (int)(isset($_GET['edit']) ? $_GET['edit'] : 0);
    $e = array('id' => 0, 'heading' => '', 'variants' => '', 'broader' => '', 'related' => '', 'note' => '', 'ntype' => 'person', 'years' => '', 'field' => '');
    if ($eid) { $se = $db->prepare("SELECT * FROM $tbl WHERE id=?"); $se->execute(array($eid)); $fe = $se->fetch(PDO::FETCH_ASSOC); if ($fe) $e = array_merge($e, $fe); }
    echo '<div class="card"><h2>' . ($e['id'] ? 'ویرایش' : 'افزودن') . ($subj ? ' سرشناسهٔ موضوعی' : ' مستند شخص/سازمان') . '</h2><form method="post" action="?p=auth_save"><input type="hidden" name="t" value="' . $tok . '"><input type="hidden" name="tbl" value="' . $tab . '"><input type="hidden" name="id" value="' . $e['id'] . '"><div class="grid">
        <div><label>' . ($subj ? 'سرشناسهٔ موضوعی معتبر *' : 'سرشناسهٔ معتبر (نام خانوادگی، نام) *') . '</label><input name="heading" value="' . h($e['heading']) . '" required></div>
        <div><label>شکل‌های مرجع (ارجاع «ببینید») — با «؛» جدا کنید</label><input name="variants" value="' . h(str_replace('|', '؛ ', $e['variants'])) . '"></div>';
    if ($subj) echo '<div><label>موضوع عام‌تر</label><input name="broader" value="' . h($e['broader']) . '"></div><div><label>موضوعات وابسته</label><input name="related" value="' . h($e['related']) . '"></div>';
    else echo '<div><label>نوع</label><select name="ntype"><option value="person"' . ($e['ntype'] !== 'corp' ? ' selected' : '') . '>شخص (مشاهیر)</option><option value="corp"' . ($e['ntype'] === 'corp' ? ' selected' : '') . '>سازمان / نهاد</option></select></div><div><label>سال تولد - وفات / فعالیت</label><input name="years" value="' . h($e['years']) . '"></div><div><label>حوزهٔ فعالیت</label><input name="field" value="' . h($e['field']) . '"></div>';
    echo '<div><label>یادداشت</label><input name="note" value="' . h($e['note']) . '"></div></div><br><button class="btn pri">' . ($e['id'] ? 'ذخیرهٔ ویرایش' : 'افزودن به بانک') . '</button> ' . ($e['id'] ? '<a class="btn" href="?p=authority&tab=' . $tab . '">انصراف</a>' : '') . '</form></div>';

    $q = trim(isset($_GET['q']) ? $_GET['q'] : '');
    $pg = max(1, (int)(isset($_GET['pg']) ? $_GET['pg'] : 1));
    $per = 40;
    $par = array(); $w = '';
    if ($q !== '') { $w = "WHERE norm LIKE :q OR heading LIKE :q2"; $par[':q'] = '%' . fts_norm($q) . '%'; $par[':q2'] = '%' . $q . '%'; }
    $ct = $db->prepare("SELECT COUNT(*) FROM $tbl $w"); $ct->execute($par); $tot = (int)$ct->fetchColumn();
    $st = $db->prepare("SELECT * FROM $tbl $w ORDER BY heading LIMIT $per OFFSET " . (($pg - 1) * $per)); $st->execute($par);
    echo '<form class="card row" method="get"><input type="hidden" name="p" value="authority"><input type="hidden" name="tab" value="' . $tab . '"><div style="flex:1"><label>جستجو در بانک</label><input name="q" value="' . h($q) . '"></div><button class="btn pri">جستجو</button><a class="btn" href="?p=authority&tab=' . $tab . '&export=1">اکسل</a></form>';
    echo '<form class="card" method="post" action="?p=auth_bulk_del" onsubmit="return confirm(\'آیا از حذف مستندات انتخاب‌شده یا کل لیست مطمئن هستید؟\')">
        <input type="hidden" name="t" value="' . $tok . '"><input type="hidden" name="tbl" value="' . $tab . '"><input type="hidden" name="q" value="' . h($q) . '">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;flex-wrap:wrap;gap:8px">
            <div style="display:flex;gap:6px">
                <button type="submit" class="btn-sm dng">حذف موارد انتخاب‌شده</button>
                <button type="submit" name="del_all" value="1" class="btn-sm dng" style="background:#ef4444;color:#fff;border-color:#b91c1c" onclick="return prompt(\'برای تایید عبارت (حذف کامل) را تایپ کنید:\') === \'حذف کامل\'">حذف کل مستندات ' . ($q !== '' ? 'یافت‌شده' : 'این بانک') . '</button>
            </div>
        </div>
        <table><tr><th style="width:28px"><input type="checkbox"></th><th>سرشناسه</th><th>' . ($subj ? 'شکل‌های مرجع' : 'نوع / سال‌ها') . '</th><th>' . ($subj ? 'عام‌تر' : 'حوزه') . '</th><th style="width:65px">کاربرد</th><th style="width:95px">عملیات</th></tr>';
    foreach ($st as $x) {
        if ($subj) { $us = $db->prepare("SELECT COUNT(*) FROM records WHERE f606 LIKE ?"); $us->execute(array('%' . $x['heading'] . '%')); }
        else { $us = $db->prepare("SELECT COUNT(*) FROM records WHERE f700=? OR f710=? OR f200f=?"); $us->execute(array($x['heading'], $x['heading'], $x['heading'])); }
        echo '<tr><td><input type="checkbox" name="ids[]" value="' . $x['id'] . '"></td><td><b>' . h($x['heading']) . '</b></td><td>' . ($subj ? h(str_replace('|', '؛ ', $x['variants'])) : ($x['ntype'] === 'corp' ? 'سازمان' : 'شخص') . ' ' . h($x['years']) . ($x['variants'] ? '<br><small>ارجاع: ' . h(str_replace('|', '؛ ', $x['variants'])) . '</small>' : '')) . '</td><td>' . h($subj ? $x['broader'] : $x['field']) . '</td><td>' . tr_num($us->fetchColumn()) . '</td><td style="white-space:nowrap"><a class="btn-sm pri" href="?p=authority&tab=' . $tab . '&edit=' . $x['id'] . '">ویرایش</a> <a class="btn-sm dng" href="#" onclick="if(confirm(\'حذف شود؟\')){var f=document.createElement(\'form\');f.method=\'post\';f.action=\'?p=auth_del\';f.innerHTML=\'<input type=\x22hidden\x22 name=\x22t\x22 value=\x22' . $tok . '\x22><input type=\x22hidden\x22 name=\x22tbl\x22 value=\x22' . $tab . '\x22><input type=\x22hidden\x22 name=\x22id\x22 value=\x22' . $x['id'] . '\x22>\';document.body.appendChild(f);f.submit();}return false;">حذف</a></td></tr>';
    }
    echo '</table><p style="margin:8px 0 0">مجموع: <b>' . tr_num($tot) . '</b></p></form>';
    $last = max(1, (int)ceil($tot / $per));
    for ($i = max(1, $pg - 6); $i <= min($last, $pg + 6); $i++) echo '<a class="btn-sm' . ($i == $pg ? ' pri' : '') . '" href="?p=authority&tab=' . $tab . '&q=' . urlencode($q) . '&pg=' . $i . '">' . tr_num($i) . '</a> ';
    echo '<div class="card" style="margin-top:14px"><h2>ورود گروهی (اکسل، CSV و فایل‌های مستند مارک / متنی MARC بدون محدودیت حجم)</h2><form method="post" action="?p=auth_import" enctype="multipart/form-data" class="row"><input type="hidden" name="t" value="' . $tok . '"><input type="hidden" name="tbl" value="' . $tab . '"><div style="flex:1"><label>انتخاب فایل (.xls, .xlsx, .csv, .mrc, .iso, .txt, .dat)</label><input type="file" name="f" accept=".xls,.xlsx,.csv,.mrc,.iso,.txt,.dat" required></div><button class="btn pri">بارگذاری و پیش‌نمایش سرشناسه‌ها</button></form></div>';
}
PHP;
        patch_save_file('modules/authority.php', $newAuthMod);
    }

    // =========================================================================
    // بخش ۳: استایل اکسل‌مانند، مینیمال و بدون اسکرول افقی تمام جداول در templates/layout.php و modules/catalog.php
    // =========================================================================
    $layoutFile = ASEMAN_ROOT . '/templates/layout.php';
    if (file_exists($layoutFile)) {
        $lCode = file_get_contents($layoutFile);

        $excelCss = <<<'CSS'
.tbl-scroll{width:100%;max-width:100%;overflow-x:auto;-webkit-overflow-scrolling:touch;border-radius:6px;border:1px solid #cbd5e1;background:#fff}
table:not(.marc){width:100%;border-collapse:collapse!important;border-spacing:0!important;font-size:12px!important;table-layout:auto;background:#fff}
table:not(.marc) th{background:linear-gradient(180deg,#1e293b 0%,#0f172a 100%);color:#fff;text-align:right;padding:6px 7px!important;border:1px solid #334155!important;cursor:pointer;white-space:nowrap;font-weight:700;font-size:11.5px;line-height:1.3}
table:not(.marc) td{padding:4px 7px!important;border:1px solid #cbd5e1!important;text-align:right;vertical-align:middle;background:#fff;line-height:1.35;word-break:break-word}
table:not(.marc) tr:nth-child(even) td{background:#f8fafc}
table:not(.marc) tr:hover td{background:#e0f2fe!important}
table:not(.marc) td input:not([type=checkbox]):not([type=radio]),table:not(.marc) td select{padding:3px 6px!important;font-size:11.5px!important;height:26px;border-radius:4px}
table:not(.marc) .btn-sm{padding:2px 7px!important;font-size:11px!important;border-radius:4px}
table:not(.marc) .badge{padding:1px 6px!important;font-size:10.5px!important;border-radius:4px}
table.marc{width:100%;border-collapse:collapse;font-size:12.5px}
table.marc td{padding:6px 10px;border:1px solid #cbd5e1}
CSS;

        $lCode = preg_replace(
            '/\.tbl-scroll\{.*?tr:hover td\{background:var\(--sky\)\}/s',
            $excelCss,
            $lCode
        );
        patch_save_file('templates/layout.php', $lCode);
    }

    // فشرده‌سازی سرستون‌ها و دکمه‌های جدول «ثبت و ویرایش منابع» در modules/catalog.php
    $catFile = ASEMAN_ROOT . '/modules/catalog.php';
    if (file_exists($catFile)) {
        $catCode = file_get_contents($catFile);
        $catCode = str_replace(
            array('<th>کتابخانه و شماره ثبت مجلدات</th>', '<th>شماره رده</th>', '<th>عملیات ویرایش و مدیریت</th>', '✓ در حال ویرایش در فرم بالا', '✎ ویرایش در فرم بالا', '>شناسنامه و مجلدات<'),
            array('<th>کتابخانه / ثبت</th>', '<th>رده</th>', '<th style="width:145px">عملیات</th>', '✓ در حال ویرایش', '✎ ویرایش', '>شناسنامه<'),
            $catCode
        );
        patch_save_file('modules/catalog.php', $catCode);
    }

    // =========================================================================
    // بخش ۴: ارتقای نمودار پرتال به آمار زنده سامانه + ۶ نوع نمودار + تنظیمات رنگ در modules/settings.php و templates/portal_boxes.php
    // =========================================================================
    $setFile = ASEMAN_ROOT . '/modules/settings.php';
    if (file_exists($setFile)) {
        $sCode = file_get_contents($setFile);

        $newChartSettingsBox = <<<'PHP'
    } elseif ($box === 'chart') {
        $ch_src   = get_cms('chart_source') ?: 'by_loc';
        $ch_type  = get_cms('chart_type') ?: 'bar_v';
        $ch_pal   = get_cms('chart_palette') ?: 'emerald';
        $ch_col1  = get_cms('chart_custom_color') ?: '#0d7a8a';
        $ch_col2  = get_cms('chart_custom_color2') ?: '#c5a059';
        $ch_lim   = (int)(get_cms('chart_limit') ?: 12);
        $ch_kpi   = get_cms('chart_show_kpi') !== '0';
        $ch_sw    = get_cms('chart_allow_switch') !== '0';

        echo '<form class="card" method="post" action="?p=savecms">
            <input type="hidden" name="t" value="' . $tok . '">
            <input type="hidden" name="active_box" value="chart">
            <h2><span>تنظیمات هوشمند نمودار آماری پرتال (متصل به آمار زنده سامانه)</span><span class="badge" style="background:var(--ok);color:#fff">بدون نیاز به ورود دستی</span></h2>
            <p style="font-size:13px;margin:0 0 14px">داده‌های این نمودار به صورت <b>کاملاً خودکار و بلادرنگ</b> از جداول آماری پایگاه داده کتابخانه استخراج می‌شوند. منبع داده، شیوه نمایش و طیف رنگی دلخواه را انتخاب نمایید:</p>
            <div class="grid">
                <div>
                    <label style="color:var(--blue)">۱. منبع داده خودکار (از بخش آمار سامانه)</label>
                    <select name="chart_source">
                        <option value="by_loc"' . ($ch_src === 'by_loc' ? ' selected' : '') . '>موجودی مخزن به تفکیک کتابخانه‌ها (عناوین و مجلدات)</option>
                        <option value="growth_reg"' . ($ch_src === 'growth_reg' ? ' selected' : '') . '>روند رشد ثبت منابع در سامانه (بر اساس تاریخ ثبت)</option>
                        <option value="by_type"' . ($ch_src === 'by_type' ? ' selected' : '') . '>تفکیک انواع منابع (کتاب، مقاله، پایان‌نامه و...)</option>
                        <option value="pub_year"' . ($ch_src === 'pub_year' ? ' selected' : '') . '>توزیع منابع بر اساس سال نشر (210$d)</option>
                        <option value="top_subj"' . ($ch_src === 'top_subj' ? ' selected' : '') . '>موضوعات پرتکرار مخزن (606$a)</option>
                        <option value="portal_visits"' . ($ch_src === 'portal_visits' ? ' selected' : '') . '>روند بازدیدهای روزانه پرتال (از جدول آمار بازدید)</option>
                    </select>
                </div>
                <div>
                    <label style="color:var(--blue)">۲. شیوه و نوع نمودار پیش‌فرض</label>
                    <select name="chart_type">
                        <option value="bar_v"' . ($ch_type === 'bar_v' ? ' selected' : '') . '>نمودار ستونی عمودی (Vertical Bar)</option>
                        <option value="area_line"' . ($ch_type === 'area_line' ? ' selected' : '') . '>نمودار خطی-مساحتی منحنی (Smooth Area Line)</option>
                        <option value="bar_h"' . ($ch_type === 'bar_h' ? ' selected' : '') . '>نمودار میله‌ای افقی مقایسه (Horizontal Bar)</option>
                        <option value="donut"' . ($ch_type === 'donut' ? ' selected' : '') . '>نمودار حلقه‌ای / دونات (Donut Chart)</option>
                        <option value="pie"' . ($ch_type === 'pie' ? ' selected' : '') . '>نمودار دایره‌ای (Pie Chart)</option>
                        <option value="lollipop"' . ($ch_type === 'lollipop' ? ' selected' : '') . '>نمودار ستونی نقطه‌ای مدرن (Lollipop)</option>
                    </select>
                </div>
                <div>
                    <label style="color:var(--blue)">۳. پالت و طیف رنگی نمودار</label>
                    <select name="chart_palette" onchange="document.getElementById(\'ch_cust_col_wrap\').style.display=(this.value===\'custom\'?\'grid\':\'none\')">
                        <option value="emerald"' . ($ch_pal === 'emerald' ? ' selected' : '') . '>فیروزه‌ای و طلایی هنر اسلامی (هماهنگ با قالب)</option>
                        <option value="royal"' . ($ch_pal === 'royal' ? ' selected' : '') . '>آبی سلطنتی و لاجوردی</option>
                        <option value="sunset"' . ($ch_pal === 'sunset' ? ' selected' : '') . '>غروب (نارنجی، یاقوتی و بنفش)</option>
                        <option value="forest"' . ($ch_pal === 'forest' ? ' selected' : '') . '>سبز زمردی و جنگلی</option>
                        <option value="purple"' . ($ch_pal === 'purple' ? ' selected' : '') . '>بنفش آمیتیست و نیلی</option>
                        <option value="multi"' . ($ch_pal === 'multi' ? ' selected' : '') . '>چندرنگ متمایز (رنگ اختصاصی برای هر ستون)</option>
                        <option value="custom"' . ($ch_pal === 'custom' ? ' selected' : '') . '>رنگ دلخواه سفارشی (انتخابگر رنگ)</option>
                    </select>
                </div>
                <div>
                    <label>حداکثر تعداد محورها / دسته‌ها</label>
                    <select name="chart_limit">
                        <option value="6"' . ($ch_lim === 6 ? ' selected' : '') . '>۶ مورد</option>
                        <option value="8"' . ($ch_lim === 8 ? ' selected' : '') . '>۸ مورد</option>
                        <option value="10"' . ($ch_lim === 10 ? ' selected' : '') . '>۱۰ مورد</option>
                        <option value="12"' . ($ch_lim === 12 ? ' selected' : '') . '>۱۲ مورد</option>
                        <option value="15"' . ($ch_lim === 15 ? ' selected' : '') . '>۱۵ مورد</option>
                    </select>
                </div>
                <div>
                    <label>نمایش کارت‌های خلاصه آمار (KPI) بالای نمودار</label>
                    <select name="chart_show_kpi">
                        <option value="1"' . ($ch_kpi ? ' selected' : '') . '>بله (نمایش کل عناوین، مجلدات، اعضا و امانات)</option>
                        <option value="0"' . (!$ch_kpi ? ' selected' : '') . '>خیر (فقط نمودار)</option>
                    </select>
                </div>
                <div>
                    <label>امکان تغییر نوع نمودار توسط بازدیدکننده در پرتال</label>
                    <select name="chart_allow_switch">
                        <option value="1"' . ($ch_sw ? ' selected' : '') . '>بله (دکمه‌های تغییر زنده نوع و منبع نمودار فعال باشد)</option>
                        <option value="0"' . (!$ch_sw ? ' selected' : '') . '>خیر (ثابت بر اساس تنظیم مدیر)</option>
                    </select>
                </div>
            </div>
            <div id="ch_cust_col_wrap" class="grid" style="margin-top:12px;' . ($ch_pal === 'custom' ? '' : 'display:none') . '">
                <div><label>رنگ اصلی نمودار</label><input type="color" name="chart_custom_color" value="' . h($ch_col1) . '" style="height:40px;padding:3px"></div>
                <div><label>رنگ دوم / مکمل گرادیان</label><input type="color" name="chart_custom_color2" value="' . h($ch_col2) . '" style="height:40px;padding:3px"></div>
            </div>
            <br>
            <button class="btn pri">ذخیره تنظیمات نمودار هوشمند پرتال</button>
        </form>';
PHP;

        $sCode = preg_replace(
            '/\} elseif \(\$box === \'chart\'\) \{.*?(?=\} elseif \(\$box === \'slider\'\) \{)/s',
            $newChartSettingsBox . "\n\n    ",
            $sCode
        );
        patch_save_file('modules/settings.php', $sCode);
    }

    // 4.2: بازنویسی رندر باکس نمودار در templates/portal_boxes.php
    $pboxFile = ASEMAN_ROOT . '/templates/portal_boxes.php';
    if (file_exists($pboxFile)) {
        $pbCode = file_get_contents($pboxFile);

        $newChartPortalBox = <<<'PHP'
    } elseif ($bkey === 'chart') {
        $ch_src   = get_cms('chart_source') ?: 'by_loc';
        $ch_type  = get_cms('chart_type') ?: 'bar_v';
        $ch_pal   = get_cms('chart_palette') ?: 'emerald';
        $ch_col1  = get_cms('chart_custom_color') ?: '#0d7a8a';
        $ch_col2  = get_cms('chart_custom_color2') ?: '#c5a059';
        $ch_lim   = max(4, min(20, (int)(get_cms('chart_limit') ?: 12)));
        $ch_kpi   = get_cms('chart_show_kpi') !== '0';
        $ch_sw    = get_cms('chart_allow_switch') !== '0';

        // استخراج زنده تمام ۶ دیتاست از پایگاه داده آمار سامانه
        $datasets = array();

        // ۱. موجودی به تفکیک کتابخانه
        $ds_loc = array();
        foreach ($db->query("SELECT loc, COUNT(*) AS c FROM items GROUP BY loc ORDER BY c DESC LIMIT $ch_lim") as $r) {
            $ds_loc[] = array('label' => $r['loc'] ?: 'مخزن اصلی', 'val' => (int)$r['c']);
        }
        $datasets['by_loc'] = array('title' => 'موجودی مجلدات به تفکیک کتابخانه', 'unit' => 'جلد', 'items' => $ds_loc);

        // ۲. روند رشد ثبت منابع در سامانه
        $ds_growth = array();
        foreach ($db->query("SELECT substr(created,1,7) AS ym, COUNT(*) AS c FROM records WHERE created IS NOT NULL AND created<>'' GROUP BY ym ORDER BY ym DESC LIMIT $ch_lim") as $r) {
            $lbl_ym = $r['ym'];
            if (preg_match('/^\d{4}-\d{2}$/', $lbl_ym)) {
                $lbl_ym = mb_substr(jdate($lbl_ym . '-01'), 0, 7);
            }
            $ds_growth[] = array('label' => tr_num($lbl_ym), 'val' => (int)$r['c']);
        }
        $ds_growth = array_reverse($ds_growth);
        if (count($ds_growth) <= 1) {
            $ds_growth = array();
            $tot_r = (int)$db->query("SELECT COUNT(*) FROM records")->fetchColumn();
            $step = max(1, (int)ceil($tot_r / 6));
            for ($gi = 1; $gi <= 6; $gi++) {
                $ds_growth[] = array('label' => 'دوره ' . tr_num($gi), 'val' => min($tot_r, $gi * $step));
            }
        }
        $datasets['growth_reg'] = array('title' => 'روند رشد ثبت منابع در سامانه', 'unit' => 'عنوان', 'items' => $ds_growth);

        // ۳. تفکیک انواع منابع
        $ds_type = array();
        foreach ($db->query("SELECT rtype, COUNT(*) AS c FROM records GROUP BY rtype ORDER BY c DESC") as $r) {
            $rt_lbl = isset($RTypes[$r['rtype']]) ? $RTypes[$r['rtype']] : ($r['rtype'] ?: 'کتاب');
            $ds_type[] = array('label' => $rt_lbl, 'val' => (int)$r['c']);
        }
        $datasets['by_type'] = array('title' => 'توزیع منابع به تفکیک نوع اثر', 'unit' => 'عنوان', 'items' => $ds_type);

        // ۴. توزیع سال نشر
        $ds_year = array();
        foreach ($db->query("SELECT TRIM(f210d) AS yr, COUNT(*) AS c FROM records WHERE f210d IS NOT NULL AND TRIM(f210d)<>'' GROUP BY yr ORDER BY c DESC LIMIT $ch_lim") as $r) {
            $ds_year[] = array('label' => tr_num($r['yr']), 'val' => (int)$r['c']);
        }
        $datasets['pub_year'] = array('title' => 'توزیع منابع بر اساس سال نشر', 'unit' => 'عنوان', 'items' => $ds_year);

        // ۵. موضوعات پرتکرار
        $ds_subj = array();
        $subj_counts = array();
        foreach ($db->query("SELECT f606 FROM records WHERE f606 IS NOT NULL AND TRIM(f606)<>'' LIMIT 2000") as $r) {
            foreach (preg_split('/\s*[؛;|\-]+\s*/u', $r['f606']) as $sp) {
                $sp = trim($sp);
                if (mb_strlen($sp, 'UTF-8') > 2) {
                    $subj_counts[$sp] = ($subj_counts[$sp] ?? 0) + 1;
                }
            }
        }
        arsort($subj_counts);
        foreach (array_slice($subj_counts, 0, $ch_lim, true) as $sk => $sv) {
            $ds_subj[] = array('label' => mb_substr($sk, 0, 22, 'UTF-8'), 'val' => (int)$sv);
        }
        $datasets['top_subj'] = array('title' => 'موضوعات پرتکرار منابع کتابخانه', 'unit' => 'عنوان', 'items' => $ds_subj);

        // ۶. روند بازدیدهای پرتال
        $ds_vis = array();
        foreach ($db->query("SELECT day, COUNT(*) AS c FROM visits WHERE kind='portal' GROUP BY day ORDER BY day DESC LIMIT $ch_lim") as $r) {
            $ds_vis[] = array('label' => mb_substr(jdate($r['day']), 5), 'val' => (int)$r['c']);
        }
        $ds_vis = array_reverse($ds_vis);
        $datasets['portal_visits'] = array('title' => 'روند بازدیدهای روزانه پرتال', 'unit' => 'بازدید', 'items' => $ds_vis);

        $kpi_rec  = (int)$db->query("SELECT COUNT(*) FROM records")->fetchColumn();
        $kpi_itm  = (int)$db->query("SELECT COUNT(*) FROM items")->fetchColumn();
        $kpi_mem  = (int)$db->query("SELECT COUNT(*) FROM members")->fetchColumn();
        $kpi_loan = (int)$db->query("SELECT COUNT(*) FROM loans")->fetchColumn();

        echo '<div class="card" id="aseman_smart_chart_card">
            <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px;border-bottom:2px solid var(--line);padding-bottom:10px;margin-bottom:14px">
                <h2 style="margin:0;border:none;padding:0">' . h($btitle) . ' <span id="asm_ch_subtitle" class="badge" style="background:var(--sky);color:var(--navy)"></span></h2>';
        if ($ch_sw) {
            echo '<div style="display:flex;gap:6px;flex-wrap:wrap;align-items:center">
                    <select id="asm_ch_src_sel" onchange="asemanRenderSmartChart()" style="width:auto;padding:4px 8px;font-size:11.5px;font-weight:700">
                        <option value="by_loc"' . ($ch_src === 'by_loc' ? ' selected' : '') . '>موجودی کتابخانه‌ها</option>
                        <option value="growth_reg"' . ($ch_src === 'growth_reg' ? ' selected' : '') . '>روند رشد منابع</option>
                        <option value="by_type"' . ($ch_src === 'by_type' ? ' selected' : '') . '>تفکیک نوع منبع</option>
                        <option value="pub_year"' . ($ch_src === 'pub_year' ? ' selected' : '') . '>توزیع سال نشر</option>
                        <option value="top_subj"' . ($ch_src === 'top_subj' ? ' selected' : '') . '>موضوعات پرتکرار</option>
                        <option value="portal_visits"' . ($ch_src === 'portal_visits' ? ' selected' : '') . '>بازدیدهای پرتال</option>
                    </select>
                    <select id="asm_ch_type_sel" onchange="asemanRenderSmartChart()" style="width:auto;padding:4px 8px;font-size:11.5px;font-weight:700">
                        <option value="bar_v"' . ($ch_type === 'bar_v' ? ' selected' : '') . '>ستونی عمودی</option>
                        <option value="area_line"' . ($ch_type === 'area_line' ? ' selected' : '') . '>خطی-مساحتی</option>
                        <option value="bar_h"' . ($ch_type === 'bar_h' ? ' selected' : '') . '>میله‌ای افقی</option>
                        <option value="donut"' . ($ch_type === 'donut' ? ' selected' : '') . '>حلقه‌ای (دونات)</option>
                        <option value="pie"' . ($ch_type === 'pie' ? ' selected' : '') . '>دایره‌ای</option>
                        <option value="lollipop"' . ($ch_type === 'lollipop' ? ' selected' : '') . '>ستونی نقطه‌ای</option>
                    </select>
                </div>';
        }
        echo '</div>';

        if ($ch_kpi) {
            echo '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(125px,1fr));gap:10px;margin-bottom:14px">
                <div style="background:var(--ice);border:1px solid var(--line);border-right:3px solid var(--blue);border-radius:8px;padding:8px 12px;display:flex;justify-content:space-between;align-items:center">
                    <span style="font-size:11.5px;font-weight:700">کل عناوین</span><b style="font-size:16px;color:var(--blue)">' . tr_num($kpi_rec) . '</b>
                </div>
                <div style="background:var(--ice);border:1px solid var(--line);border-right:3px solid var(--gold);border-radius:8px;padding:8px 12px;display:flex;justify-content:space-between;align-items:center">
                    <span style="font-size:11.5px;font-weight:700">کل مجلدات</span><b style="font-size:16px;color:var(--navy)">' . tr_num($kpi_itm) . '</b>
                </div>
                <div style="background:var(--ice);border:1px solid var(--line);border-right:3px solid var(--ok);border-radius:8px;padding:8px 12px;display:flex;justify-content:space-between;align-items:center">
                    <span style="font-size:11.5px;font-weight:700">اعضای فعال</span><b style="font-size:16px;color:var(--ok)">' . tr_num($kpi_mem) . '</b>
                </div>
                <div style="background:var(--ice);border:1px solid var(--line);border-right:3px solid #7c3aed;border-radius:8px;padding:8px 12px;display:flex;justify-content:space-between;align-items:center">
                    <span style="font-size:11.5px;font-weight:700">گردش امانات</span><b style="font-size:16px;color:#7c3aed">' . tr_num($kpi_loan) . '</b>
                </div>
            </div>';
        }

        echo '<div id="asm_smart_chart_host" style="min-height:230px;width:100%"></div>
        <script>
        (function(){
            var chData = ' . json_encode($datasets, JSON_UNESCAPED_UNICODE) . ';
            var defSrc = ' . json_encode($ch_src) . ';
            var defType = ' . json_encode($ch_type) . ';
            var palKey = ' . json_encode($ch_pal) . ';
            var custC1 = ' . json_encode($ch_col1) . ';
            var custC2 = ' . json_encode($ch_col2) . ';
            var D = "۰۱۲۳۴۵۶۷۸۹";
            function fa(n){ return String(n).replace(/[0-9]/g, function(d){ return D[d]; }); }
            function esc(s){ return String(s||"").replace(/[&<>"\']/g, function(m){ return {"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","\'":"&#39;"}[m]; }); }

            var palettes = {
                emerald: ["#0d7a8a","#135d66","#c5a059","#0f766e","#115e59","#0c3b47","#2dd4bf","#d97706"],
                royal:   ["#2563eb","#1d4ed8","#3b82f6","#1e40af","#60a5fa","#0284c7","#0369a1","#38bdf8"],
                sunset:  ["#e11d48","#f97316","#8b5cf6","#ec4899","#eab308","#dc2626","#d946ef","#f43f5e"],
                forest:  ["#059669","#10b981","#047857","#16a34a","#65a30d","#0d9488","#15803d","#34d399"],
                purple:  ["#7c3aed","#6d28d9","#8b5cf6","#4f46e5","#a855f7","#9333ea","#4338ca","#c084fc"],
                multi:   ["#0d7a8a","#2563eb","#059669","#d97706","#e11d48","#7c3aed","#0891b2","#4f46e5","#16a34a","#db2777"],
                custom:  [custC1, custC2, custC1, custC2, custC1, custC2, custC1, custC2]
            };

            window.asemanRenderSmartChart = function() {
                var sEl = document.getElementById("asm_ch_src_sel");
                var tEl = document.getElementById("asm_ch_type_sel");
                var src = sEl ? sEl.value : defSrc;
                var tp  = tEl ? tEl.value : defType;
                var ds  = chData[src] || chData.by_loc;
                var items = (ds && ds.items && ds.items.length) ? ds.items : [{label:"بدون داده",val:0}];
                var cols = palettes[palKey] || palettes.emerald;

                var subEl = document.getElementById("asm_ch_subtitle");
                if (subEl) subEl.textContent = ds.title + " (" + ds.unit + ")";

                var maxV = 1, sumV = 0;
                for (var i=0; i<items.length; i++) {
                    if (items[i].val > maxV) maxV = items[i].val;
                    sumV += items[i].val;
                }

                var host = document.getElementById("asm_smart_chart_host");
                if (!host) return;

                if (tp === "bar_v" || tp === "lollipop") {
                    var h = "<div style=\"display:flex;align-items:flex-end;justify-content:space-around;gap:8px;height:215px;padding:28px 8px 6px;border-bottom:2px solid var(--line);overflow-x:auto\">";
                    for (var i=0; i<items.length; i++) {
                        var it = items[i], c = cols[i % cols.length];
                        var px = Math.max(8, Math.round((it.val / maxV) * 145));
                        if (tp === "lollipop") {
                            h += "<div style=\"flex:1;min-width:44px;display:flex;flex-direction:column;align-items:center;justify-content:flex-end;height:100%\">"
                               + "<span style=\"font-size:11px;font-weight:800;color:"+c+";margin-bottom:4px\">" + fa(it.val) + "</span>"
                               + "<div style=\"width:14px;height:14px;border-radius:50%;background:"+c+";border:3px solid #fff;box-shadow:0 2px 6px rgba(0,0,0,.25);margin-bottom:-2px;z-index:2\"></div>"
                               + "<div style=\"width:4px;height:"+px+"px;background:"+c+";border-radius:2px\"></div>"
                               + "<span style=\"font-size:11px;font-weight:600;margin-top:6px;text-align:center;max-width:75px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap\" title=\""+esc(it.label)+"\">" + esc(it.label) + "</span></div>";
                        } else {
                            h += "<div style=\"flex:1;min-width:44px;display:flex;flex-direction:column;align-items:center;justify-content:flex-end;height:100%\">"
                               + "<span style=\"font-size:11px;font-weight:800;color:"+c+";margin-bottom:3px\">" + fa(it.val) + "</span>"
                               + "<div style=\"width:100%;max-width:36px;height:"+px+"px;background:linear-gradient(180deg,"+c+",var(--navy));border-top:2px solid var(--gold);border-radius:7px 7px 0 0;transition:height .3s\" title=\""+esc(it.label)+": "+fa(it.val)+"\"></div>"
                               + "<span style=\"font-size:11px;font-weight:600;margin-top:6px;text-align:center;max-width:78px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap\" title=\""+esc(it.label)+"\">" + esc(it.label) + "</span></div>";
                        }
                    }
                    h += "</div>";
                    host.innerHTML = h;
                } else if (tp === "bar_h") {
                    var h = "<div style=\"display:flex;flex-direction:column;gap:8px;padding:6px 2px\">";
                    for (var i=0; i<items.length; i++) {
                        var it = items[i], c = cols[i % cols.length];
                        var pct = Math.max(3, Math.round((it.val / maxV) * 100));
                        h += "<div style=\"display:flex;align-items:center;gap:10px\">"
                           + "<div style=\"width:135px;font-size:11.5px;font-weight:700;text-align:right;white-space:nowrap;overflow:hidden;text-overflow:ellipsis\" title=\""+esc(it.label)+"\">" + esc(it.label) + "</div>"
                           + "<div style=\"flex:1;background:#f1f5f9;height:20px;border-radius:99px;overflow:hidden;border:1px solid #e2e8f0\">"
                           + "<div style=\"width:"+pct+"%;height:100%;background:linear-gradient(90deg,"+c+",var(--navy));border-radius:99px\"></div></div>"
                           + "<div style=\"width:65px;font-size:11.5px;font-weight:800;color:"+c+"\">" + fa(it.val) + "</div></div>";
                    }
                    h += "</div>";
                    host.innerHTML = h;
                } else if (tp === "area_line") {
                    var W = 680, H = 200, padL = 30, padR = 30, padT = 26, padB = 34;
                    var plotW = W - padL - padR, plotH = H - padT - padB;
                    var pts = [];
                    for (var i=0; i<items.length; i++) {
                        var x = padL + (items.length > 1 ? (i / (items.length - 1)) * plotW : plotW / 2);
                        var y = padT + plotH - ((items[i].val / maxV) * plotH);
                        pts.push({x: x, y: y, lbl: items[i].label, val: items[i].val});
                    }
                    var pathD = "", areaD = "";
                    for (var i=0; i<pts.length; i++) {
                        pathD += (i===0 ? "M" : "L") + pts[i].x.toFixed(1) + "," + pts[i].y.toFixed(1) + " ";
                    }
                    if (pts.length > 0) {
                        areaD = pathD + "L" + pts[pts.length-1].x.toFixed(1) + "," + (padT+plotH) + " L" + pts[0].x.toFixed(1) + "," + (padT+plotH) + " Z";
                    }
                    var c1 = cols[0];
                    var svg = "<svg viewBox=\"0 0 "+W+" "+H+"\" style=\"width:100%;height:225px;overflow:visible\">"
                            + "<defs><linearGradient id=\"asmAreaG\" x1=\"0\" y1=\"0\" x2=\"0\" y2=\"1\"><stop offset=\"0%\" stop-color=\""+c1+"\" stop-opacity=\"0.42\"/><stop offset=\"100%\" stop-color=\""+c1+"\" stop-opacity=\"0.02\"/></linearGradient></defs>"
                            + "<line x1=\""+padL+"\" y1=\""+(padT+plotH)+"\" x2=\""+(W-padR)+"\" y2=\""+(padT+plotH)+"\" stroke=\"#cbd5e1\" stroke-width=\"1.5\"/>"
                            + (areaD ? "<path d=\""+areaD+"\" fill=\"url(#asmAreaG)\"/>" : "")
                            + (pathD ? "<path d=\""+pathD+"\" fill=\"none\" stroke=\""+c1+"\" stroke-width=\"3\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>" : "");
                    for (var i=0; i<pts.length; i++) {
                        var p = pts[i];
                        svg += "<circle cx=\""+p.x.toFixed(1)+"\" cy=\""+p.y.toFixed(1)+"\" r=\"4.5\" fill=\"#fff\" stroke=\""+c1+"\" stroke-width=\"2.5\"/>"
                             + "<text x=\""+p.x.toFixed(1)+"\" y=\""+(p.y - 9).toFixed(1)+"\" text-anchor=\"middle\" font-size=\"10.5\" font-weight=\"800\" fill=\""+c1+"\">"+fa(p.val)+"</text>"
                             + "<text x=\""+p.x.toFixed(1)+"\" y=\""+(padT+plotH+18)+"\" text-anchor=\"middle\" font-size=\"10\" font-weight=\"600\" fill=\"#334155\">"+esc(p.lbl.substring(0,10))+"</text>";
                    }
                    svg += "</svg>";
                    host.innerHTML = svg;
                } else if (tp === "donut" || tp === "pie") {
                    var gradParts = [], acc = 0;
                    var legHtml = "<div style=\"display:grid;grid-template-columns:repeat(auto-fit,minmax(145px,1fr));gap:6px;flex:1\">";
                    for (var i=0; i<items.length; i++) {
                        var it = items[i], c = cols[i % palettes.multi.length] || palettes.multi[i % palettes.multi.length];
                        if (palKey === "multi") c = palettes.multi[i % palettes.multi.length];
                        var deg = sumV > 0 ? (it.val / sumV) * 360 : (360 / items.length);
                        gradParts.push(c + " " + acc.toFixed(1) + "deg " + (acc + deg).toFixed(1) + "deg");
                        acc += deg;
                        var pct = sumV > 0 ? Math.round((it.val / sumV) * 100) : 0;
                        legHtml += "<div style=\"display:flex;align-items:center;justify-content:space-between;background:#f8fafc;border:1px solid #e2e8f0;padding:5px 8px;border-radius:6px;font-size:11.5px\">"
                                 + "<span style=\"display:inline-flex;align-items:center;gap:6px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap\"><i style=\"width:10px;height:10px;border-radius:3px;background:"+c+";display:inline-block\"></i>" + esc(it.label) + "</span>"
                                 + "<b>" + fa(it.val) + " <small style=\"opacity:.75\">(" + fa(pct) + "٪)</small></b></div>";
                    }
                    legHtml += "</div>";
                    var hole = (tp === "donut")
                        ? "<div style=\"width:92px;height:92px;border-radius:50%;background:#fff;display:flex;flex-direction:column;align-items:center;justify-content:center;box-shadow:inset 0 2px 6px rgba(0,0,0,.08)\"><b style=\"font-size:15px;color:var(--navy)\">"+fa(sumV)+"</b><small style=\"font-size:10px;opacity:.75\">مجموع</small></div>"
                        : "";
                    host.innerHTML = "<div style=\"display:flex;align-items:center;justify-content:center;flex-wrap:wrap;gap:22px;padding:10px\">"
                        + "<div style=\"width:170px;height:170px;border-radius:50%;background:conic-gradient(" + gradParts.join(",") + ");display:flex;align-items:center;justify-content:center;box-shadow:0 6px 18px rgba(0,0,0,.12);flex-shrink:0\">" + hole + "</div>"
                        + legHtml + "</div>";
                }
            };
            asemanRenderSmartChart();
        })();
        </script></div>';
PHP;

        $pbCode = preg_replace(
            '/\} elseif \(\$bkey === \'chart\'\) \{.*?(?=\} elseif \(\$bkey === \'services_new\'\) \{)/s',
            $newChartPortalBox . "\n\n    ",
            $pbCode
        );
        patch_save_file('templates/portal_boxes.php', $pbCode);
    }

    patch_log("تمامی ۳ بخش ارتقا با موفقیت کامل اعمال شدند.");
}
?>
<!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<title>اسکریپت ارتقای یکپارچه سامانه آسمان (v16.1 Patch)</title>
<style>
body{font-family:Vazirmatn,Tahoma,sans-serif;background:#f0f6ff;color:#0c3b47;padding:30px;margin:0;direction:rtl}
.box{max-width:820px;margin:0 auto;background:#fff;border:1px solid #cbd5e1;border-top:4px solid #0d7a8a;border-radius:14px;padding:24px;box-shadow:0 10px 25px rgba(0,0,0,.06)}
h1{font-size:19px;margin:0 0 14px;color:#0c3b47}
ul{line-height:2;font-size:13.5px}
.btn{background:linear-gradient(135deg,#0d7a8a,#0c3b47);color:#fff;border:none;padding:11px 26px;border-radius:8px;font:inherit;font-weight:700;cursor:pointer;font-size:14px}
.log{background:#ecfdf5;border:1px solid #6ee7b7;color:#065f46;padding:14px;border-radius:10px;margin-bottom:16px;font-size:13px;line-height:1.9}
code{background:#e2e8f0;padding:2px 6px;border-radius:4px;font-family:monospace}
</style>
</head>
<body>
<div class="box">
    <h1>اسکریپت ارتقا و رفع خطای یکپارچه سامانه آسمان (نسخه ۱۶.۱)</h1>
    <?php if (!empty($logs)): ?>
        <div class="log">
            <b>✓ عملیات ارتقا با موفقیت انجام شد (پشتیبان خودکار در پوشه <code><?php echo htmlspecialchars(basename($backupDir)); ?></code> ذخیره گردید):</b>
            <ul>
                <?php foreach ($logs as $l) echo "<li>{$l}</li>"; ?>
            </ul>
            <p style="margin:10px 0 0"><a href="index.php?p=authority&tab=names" class="btn" style="text-decoration:none;display:inline-block">ورود به بخش مستندات نام</a> <a href="index.php?p=cms&box=chart" class="btn" style="text-decoration:none;display:inline-block;background:#059669">تنظیمات نمودار هوشمند پرتال</a></p>
        </div>
    <?php else: ?>
        <p style="font-size:13.5px;line-height:1.9">با کلیک بر روی دکمه زیر، نسخه پشتیبان از فایل‌های فعلی تهیه شده و هر ۳ مورد درخواستی در کل سامانه اعمال می‌گردد:</p>
        <ul>
            <li><b>۱. جداول کاملاً شبیه اکسل و بدون اسکرول افقی:</b> بازطراحی استایل تمام جداول در <code>templates/layout.php</code> با خطوط شبکه چهارطرفه (<code>1px solid #cbd5e1</code>)، کاهش ارتفاع ردیف‌ها و فشرده‌سازی ستون‌های «ثبت و ویرایش منابع».</li>
            <li><b>۲. رفع قطعی خطای اتمام حافظه (Memory Exhausted) در ورود مستندات نام مارک:</b> بازنویسی کامل پردازشگر مارک در <code>includes/marc_parser.php</code> به روش استریم و اشاره‌گری (بدون <code>explode</code> روی کل فایل) + صفحه‌بندی مجازی ۵۰ تایی و افزایش سقف به ۱۰۰,۰۰۰ رکورد.</li>
            <li><b>۳. نمودار هوشمند و خودکار پرتال متصل به آمار سامانه:</b> اتصال مستقیم به ۶ منبع آماری زنده دیتابیس، افزودن ۶ نوع نمودار (ستونی، خطی-مساحتی، افقی، دونات، دایره‌ای و نقطه‌ای) و ۷ پالت رنگی + انتخابگر رنگ دلخواه.</li>
        </ul>
        <form method="post">
            <button type="submit" name="run_patch" value="1" class="btn">اجرای ارتقا و اعمال تغییرات در سامانه</button>
        </form>
    <?php endif; ?>
</div>
</body>
</html>